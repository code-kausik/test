package androidx.versionedparcelable;

import android.os.Parcelable;
import java.lang.reflect.InvocationTargetException;

/* renamed from: androidx.versionedparcelable.a */
public abstract class C0164a {
    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo819a(int i);

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo821a(Parcelable parcelable);

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo825a(String str);

    /* renamed from: a */
    public void mo827a(boolean z, boolean z2) {
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public abstract void mo828a(byte[] bArr);

    /* renamed from: a */
    public boolean mo830a() {
        return false;
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract void mo835b();

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract boolean mo836b(int i);

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public abstract C0164a mo838c();

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public abstract void mo839c(int i);

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public abstract int mo840d();

    /* access modifiers changed from: protected */
    /* renamed from: e */
    public abstract String mo841e();

    /* access modifiers changed from: protected */
    /* renamed from: f */
    public abstract byte[] mo842f();

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public abstract <T extends Parcelable> T mo843g();

    /* renamed from: a */
    public void mo829a(byte[] bArr, int i) {
        mo839c(i);
        mo828a(bArr);
    }

    /* renamed from: a */
    public void mo820a(int i, int i2) {
        mo839c(i2);
        mo819a(i);
    }

    /* renamed from: a */
    public void mo826a(String str, int i) {
        mo839c(i);
        mo825a(str);
    }

    /* renamed from: a */
    public void mo822a(Parcelable parcelable, int i) {
        mo839c(i);
        mo821a(parcelable);
    }

    /* renamed from: b */
    public int mo831b(int i, int i2) {
        if (!mo836b(i2)) {
            return i;
        }
        return mo840d();
    }

    /* renamed from: b */
    public String mo834b(String str, int i) {
        if (!mo836b(i)) {
            return str;
        }
        return mo841e();
    }

    /* renamed from: b */
    public byte[] mo837b(byte[] bArr, int i) {
        if (!mo836b(i)) {
            return bArr;
        }
        return mo842f();
    }

    /* renamed from: b */
    public <T extends Parcelable> T mo832b(T t, int i) {
        if (!mo836b(i)) {
            return t;
        }
        return mo843g();
    }

    /* renamed from: a */
    public void mo824a(C0166c cVar, int i) {
        mo839c(i);
        mo823a(cVar);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo823a(C0166c cVar) {
        if (cVar == null) {
            mo825a((String) null);
            return;
        }
        m832b(cVar);
        C0164a c = mo838c();
        m831a(cVar, c);
        c.mo835b();
    }

    /* renamed from: b */
    private void m832b(C0166c cVar) {
        try {
            mo825a(m830a((Class<? extends C0166c>) cVar.getClass()).getName());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(cVar.getClass().getSimpleName() + " does not have a Parcelizer", e);
        }
    }

    /* renamed from: b */
    public <T extends C0166c> T mo833b(T t, int i) {
        if (!mo836b(i)) {
            return t;
        }
        return mo844h();
    }

    /* access modifiers changed from: protected */
    /* renamed from: h */
    public <T extends C0166c> T mo844h() {
        String e = mo841e();
        if (e == null) {
            return null;
        }
        return m829a(e, mo838c());
    }

    /* renamed from: a */
    protected static <T extends C0166c> T m829a(String str, C0164a aVar) {
        try {
            return (C0166c) Class.forName(str, true, C0164a.class.getClassLoader()).getDeclaredMethod("read", new Class[]{C0164a.class}).invoke((Object) null, new Object[]{aVar});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    /* renamed from: a */
    protected static <T extends C0166c> void m831a(T t, C0164a aVar) {
        try {
            m833c(t).getDeclaredMethod("write", new Class[]{t.getClass(), C0164a.class}).invoke((Object) null, new Object[]{t, aVar});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    /* renamed from: c */
    private static <T extends C0166c> Class m833c(T t) throws ClassNotFoundException {
        return m830a((Class<? extends C0166c>) t.getClass());
    }

    /* renamed from: a */
    private static Class m830a(Class<? extends C0166c> cls) throws ClassNotFoundException {
        return Class.forName(String.format("%s.%sParcelizer", new Object[]{cls.getPackage().getName(), cls.getSimpleName()}), false, cls.getClassLoader());
    }
}
