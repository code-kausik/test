package androidx.versionedparcelable;

public abstract class CustomVersionedParcelable implements C0166c {
    /* renamed from: a */
    public void mo607a(boolean z) {
    }

    /* renamed from: c */
    public void mo609c() {
    }
}
