package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseIntArray;
import org.apache.cordova.BuildConfig;

/* renamed from: androidx.versionedparcelable.b */
class C0165b extends C0164a {

    /* renamed from: a */
    private final SparseIntArray f498a;

    /* renamed from: b */
    private final Parcel f499b;

    /* renamed from: c */
    private final int f500c;

    /* renamed from: d */
    private final int f501d;

    /* renamed from: e */
    private final String f502e;

    /* renamed from: f */
    private int f503f;

    /* renamed from: g */
    private int f504g;

    C0165b(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), BuildConfig.FLAVOR);
    }

    C0165b(Parcel parcel, int i, int i2, String str) {
        this.f498a = new SparseIntArray();
        this.f503f = -1;
        this.f504g = 0;
        this.f499b = parcel;
        this.f500c = i;
        this.f501d = i2;
        this.f504g = this.f500c;
        this.f502e = str;
    }

    /* renamed from: d */
    private int m860d(int i) {
        while (this.f504g < this.f501d) {
            this.f499b.setDataPosition(this.f504g);
            int readInt = this.f499b.readInt();
            int readInt2 = this.f499b.readInt();
            this.f504g += readInt;
            if (readInt2 == i) {
                return this.f499b.dataPosition();
            }
        }
        return -1;
    }

    /* renamed from: b */
    public boolean mo836b(int i) {
        int d = m860d(i);
        if (d == -1) {
            return false;
        }
        this.f499b.setDataPosition(d);
        return true;
    }

    /* renamed from: c */
    public void mo839c(int i) {
        mo835b();
        this.f503f = i;
        this.f498a.put(i, this.f499b.dataPosition());
        mo819a(0);
        mo819a(i);
    }

    /* renamed from: b */
    public void mo835b() {
        if (this.f503f >= 0) {
            int i = this.f498a.get(this.f503f);
            int dataPosition = this.f499b.dataPosition();
            this.f499b.setDataPosition(i);
            this.f499b.writeInt(dataPosition - i);
            this.f499b.setDataPosition(dataPosition);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public C0164a mo838c() {
        Parcel parcel = this.f499b;
        int dataPosition = this.f499b.dataPosition();
        int i = this.f504g == this.f500c ? this.f501d : this.f504g;
        return new C0165b(parcel, dataPosition, i, this.f502e + "  ");
    }

    /* renamed from: a */
    public void mo828a(byte[] bArr) {
        if (bArr != null) {
            this.f499b.writeInt(bArr.length);
            this.f499b.writeByteArray(bArr);
            return;
        }
        this.f499b.writeInt(-1);
    }

    /* renamed from: a */
    public void mo819a(int i) {
        this.f499b.writeInt(i);
    }

    /* renamed from: a */
    public void mo825a(String str) {
        this.f499b.writeString(str);
    }

    /* renamed from: a */
    public void mo821a(Parcelable parcelable) {
        this.f499b.writeParcelable(parcelable, 0);
    }

    /* renamed from: d */
    public int mo840d() {
        return this.f499b.readInt();
    }

    /* renamed from: e */
    public String mo841e() {
        return this.f499b.readString();
    }

    /* renamed from: f */
    public byte[] mo842f() {
        int readInt = this.f499b.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f499b.readByteArray(bArr);
        return bArr;
    }

    /* renamed from: g */
    public <T extends Parcelable> T mo843g() {
        return this.f499b.readParcelable(getClass().getClassLoader());
    }
}
