package androidx.versionedparcelable;

/* renamed from: androidx.versionedparcelable.c */
public interface C0166c {
}
