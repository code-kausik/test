package androidx.media;

import android.support.p001v4.media.AudioAttributesCompat;
import androidx.versionedparcelable.C0164a;
import androidx.versionedparcelable.C0166c;

public final class AudioAttributesCompatParcelizer {
    public static AudioAttributesCompat read(C0164a aVar) {
        AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
        audioAttributesCompat.mImpl = (C0128a) aVar.mo833b(audioAttributesCompat.mImpl, 1);
        return audioAttributesCompat;
    }

    public static void write(AudioAttributesCompat audioAttributesCompat, C0164a aVar) {
        aVar.mo827a(false, false);
        aVar.mo824a((C0166c) audioAttributesCompat.mImpl, 1);
    }
}
