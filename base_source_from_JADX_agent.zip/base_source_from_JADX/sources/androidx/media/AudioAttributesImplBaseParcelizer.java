package androidx.media;

import androidx.versionedparcelable.C0164a;

public final class AudioAttributesImplBaseParcelizer {
    public static C0130c read(C0164a aVar) {
        C0130c cVar = new C0130c();
        cVar.mUsage = aVar.mo831b(cVar.mUsage, 1);
        cVar.mContentType = aVar.mo831b(cVar.mContentType, 2);
        cVar.mFlags = aVar.mo831b(cVar.mFlags, 3);
        cVar.mLegacyStream = aVar.mo831b(cVar.mLegacyStream, 4);
        return cVar;
    }

    public static void write(C0130c cVar, C0164a aVar) {
        aVar.mo827a(false, false);
        aVar.mo820a(cVar.mUsage, 1);
        aVar.mo820a(cVar.mContentType, 2);
        aVar.mo820a(cVar.mFlags, 3);
        aVar.mo820a(cVar.mLegacyStream, 4);
    }
}
