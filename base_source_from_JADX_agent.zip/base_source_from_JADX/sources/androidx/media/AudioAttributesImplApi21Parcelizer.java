package androidx.media;

import android.media.AudioAttributes;
import android.os.Parcelable;
import androidx.versionedparcelable.C0164a;

public final class AudioAttributesImplApi21Parcelizer {
    public static C0129b read(C0164a aVar) {
        C0129b bVar = new C0129b();
        bVar.mAudioAttributes = (AudioAttributes) aVar.mo832b(bVar.mAudioAttributes, 1);
        bVar.mLegacyStreamType = aVar.mo831b(bVar.mLegacyStreamType, 2);
        return bVar;
    }

    public static void write(C0129b bVar, C0164a aVar) {
        aVar.mo827a(false, false);
        aVar.mo822a((Parcelable) bVar.mAudioAttributes, 1);
        aVar.mo820a(bVar.mLegacyStreamType, 2);
    }
}
