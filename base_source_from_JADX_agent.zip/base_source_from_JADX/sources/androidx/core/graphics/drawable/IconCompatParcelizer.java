package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import android.support.p001v4.graphics.drawable.IconCompat;
import androidx.versionedparcelable.C0164a;

public class IconCompatParcelizer {
    public static IconCompat read(C0164a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f394a = aVar.mo831b(iconCompat.f394a, 1);
        iconCompat.f396c = aVar.mo837b(iconCompat.f396c, 2);
        iconCompat.f397d = aVar.mo832b(iconCompat.f397d, 3);
        iconCompat.f398e = aVar.mo831b(iconCompat.f398e, 4);
        iconCompat.f399f = aVar.mo831b(iconCompat.f399f, 5);
        iconCompat.f400g = (ColorStateList) aVar.mo832b(iconCompat.f400g, 6);
        iconCompat.f402j = aVar.mo834b(iconCompat.f402j, 7);
        iconCompat.mo609c();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, C0164a aVar) {
        aVar.mo827a(true, true);
        iconCompat.mo607a(aVar.mo830a());
        aVar.mo820a(iconCompat.f394a, 1);
        aVar.mo829a(iconCompat.f396c, 2);
        aVar.mo822a(iconCompat.f397d, 3);
        aVar.mo820a(iconCompat.f398e, 4);
        aVar.mo820a(iconCompat.f399f, 5);
        aVar.mo822a((Parcelable) iconCompat.f400g, 6);
        aVar.mo826a(iconCompat.f402j, 7);
    }
}
