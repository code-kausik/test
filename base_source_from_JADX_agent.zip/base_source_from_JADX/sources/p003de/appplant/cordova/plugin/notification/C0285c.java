package p003de.appplant.cordova.plugin.notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONObject;

/* renamed from: de.appplant.cordova.plugin.notification.c */
public abstract class C0285c extends BroadcastReceiver {
    /* renamed from: a */
    public abstract C0290h mo3338a(C0288f fVar);

    /* renamed from: a */
    public abstract void mo3339a(C0290h hVar);

    public void onReceive(Context context, Intent intent) {
        for (JSONObject fVar : C0289g.m1255a(context).mo3376e()) {
            mo3339a(mo3338a(new C0288f(context, fVar)));
        }
    }
}
