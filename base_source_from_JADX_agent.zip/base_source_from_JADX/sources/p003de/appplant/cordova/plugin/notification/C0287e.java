package p003de.appplant.cordova.plugin.notification;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.StrictMode;
import android.util.Log;
import com.google.devtools.build.android.desugar.runtime.ThrowableExtension;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.UUID;
import org.apache.cordova.BuildConfig;

/* renamed from: de.appplant.cordova.plugin.notification.e */
class C0287e {

    /* renamed from: a */
    private final Context f817a;

    private C0287e(Context context) {
        this.f817a = context;
    }

    /* renamed from: a */
    static C0287e m1233a(Context context) {
        return new C0287e(context);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public Uri mo3350a(String str) {
        if (str == null || str.isEmpty()) {
            return Uri.EMPTY;
        }
        if (str.equalsIgnoreCase("res://platform_default")) {
            return RingtoneManager.getDefaultUri(2);
        }
        return mo3351b(str);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public Uri mo3351b(String str) {
        if (str.startsWith("res:")) {
            return m1239g(str);
        }
        if (str.startsWith("file:///")) {
            return m1237e(str);
        }
        if (str.startsWith("file://")) {
            return m1238f(str);
        }
        if (str.startsWith("http")) {
            return m1240h(str);
        }
        return Uri.EMPTY;
    }

    /* renamed from: e */
    private Uri m1237e(String str) {
        File file = new File(str.replaceFirst("file://", BuildConfig.FLAVOR));
        if (file.exists()) {
            return Uri.fromFile(file);
        }
        Log.e("Asset", "File not found: " + file.getAbsolutePath());
        return Uri.EMPTY;
    }

    /* renamed from: f */
    private Uri m1238f(String str) {
        String replaceFirst = str.replaceFirst("file:/", "www");
        File j = m1242j(replaceFirst.substring(replaceFirst.lastIndexOf(47) + 1));
        if (j == null) {
            Log.e("Asset", "Missing external cache dir");
            return Uri.EMPTY;
        }
        try {
            AssetManager assets = this.f817a.getAssets();
            FileOutputStream fileOutputStream = new FileOutputStream(j);
            m1235a(assets.open(replaceFirst), (OutputStream) fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            return Uri.fromFile(j);
        } catch (Exception e) {
            Log.e("Asset", "File not found: assets/" + replaceFirst);
            ThrowableExtension.printStackTrace(e);
            return Uri.EMPTY;
        }
    }

    /* renamed from: g */
    private Uri m1239g(String str) {
        String replaceFirst = str.replaceFirst("res://", BuildConfig.FLAVOR);
        int c = mo3352c(replaceFirst);
        File a = m1234a();
        if (c == 0) {
            Log.e("Asset", "File not found: " + replaceFirst);
            return Uri.EMPTY;
        } else if (a == null) {
            Log.e("Asset", "Missing external cache dir");
            return Uri.EMPTY;
        } else {
            try {
                Resources resources = this.f817a.getResources();
                FileOutputStream fileOutputStream = new FileOutputStream(a);
                m1235a(resources.openRawResource(c), (OutputStream) fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
                return Uri.fromFile(a);
            } catch (Exception e) {
                ThrowableExtension.printStackTrace(e);
                return Uri.EMPTY;
            }
        }
    }

    /* renamed from: h */
    private Uri m1240h(String str) {
        File a = m1234a();
        if (a == null) {
            Log.e("Asset", "Missing external cache dir");
            return Uri.EMPTY;
        }
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());
            httpURLConnection.setRequestProperty("Connection", "close");
            httpURLConnection.setConnectTimeout(5000);
            httpURLConnection.connect();
            InputStream inputStream = httpURLConnection.getInputStream();
            FileOutputStream fileOutputStream = new FileOutputStream(a);
            m1235a(inputStream, (OutputStream) fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            return Uri.fromFile(a);
        } catch (MalformedURLException e) {
            Log.e("Asset", "Incorrect URL");
            ThrowableExtension.printStackTrace(e);
            return Uri.EMPTY;
        } catch (FileNotFoundException e2) {
            Log.e("Asset", "Failed to create new File from HTTP Content");
            ThrowableExtension.printStackTrace(e2);
            return Uri.EMPTY;
        } catch (IOException e3) {
            Log.e("Asset", "No Input can be created from http Stream");
            ThrowableExtension.printStackTrace(e3);
            return Uri.EMPTY;
        }
    }

    /* renamed from: a */
    private void m1235a(InputStream inputStream, OutputStream outputStream) throws IOException {
        byte[] bArr = new byte[1024];
        while (true) {
            int read = inputStream.read(bArr);
            if (read != -1) {
                outputStream.write(bArr, 0, read);
            } else {
                return;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public int mo3352c(String str) {
        int a = mo3348a(m1236b(), str);
        return a == 0 ? mo3348a("android", str) : a;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public int mo3348a(String str, String str2) {
        String i = m1241i(str2);
        try {
            return ((Integer) Class.forName(str + ".R$drawable").getDeclaredField(i).get(Integer.class)).intValue();
        } catch (Exception unused) {
            return 0;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public Bitmap mo3353d(String str) {
        Resources resources = this.f817a.getResources();
        int a = mo3348a(m1236b(), str);
        if (a == 0) {
            a = mo3348a("android", str);
        }
        if (a == 0) {
            a = 17301673;
        }
        return BitmapFactory.decodeResource(resources, a);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public Bitmap mo3349a(Uri uri) throws IOException {
        return BitmapFactory.decodeStream(this.f817a.getContentResolver().openInputStream(uri));
    }

    /* renamed from: i */
    private String m1241i(String str) {
        String substring = str.contains("/") ? str.substring(str.lastIndexOf(47) + 1) : str;
        return str.contains(".") ? substring.substring(0, substring.lastIndexOf(46)) : substring;
    }

    /* renamed from: a */
    private File m1234a() {
        return m1242j(UUID.randomUUID().toString());
    }

    /* renamed from: j */
    private File m1242j(String str) {
        File externalCacheDir = this.f817a.getExternalCacheDir();
        if (externalCacheDir == null) {
            Log.e("Asset", "Missing external cache dir");
            return null;
        }
        String str2 = externalCacheDir.toString() + "/localnotification";
        new File(str2).mkdir();
        return new File(str2, str);
    }

    /* renamed from: b */
    private String m1236b() {
        return this.f817a.getPackageName();
    }
}
