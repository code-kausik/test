package p003de.appplant.cordova.plugin.notification;

/* renamed from: de.appplant.cordova.plugin.notification.ClickActivity */
public class ClickActivity extends C0284b {
    /* renamed from: a */
    public void mo3332a(C0290h hVar) {
        mo3343a();
        if (hVar.mo3380c()) {
            hVar.mo3385h();
        } else {
            hVar.mo3386i();
        }
    }

    /* renamed from: a */
    public C0290h mo3331a(C0288f fVar) {
        return fVar.mo3355a();
    }
}
