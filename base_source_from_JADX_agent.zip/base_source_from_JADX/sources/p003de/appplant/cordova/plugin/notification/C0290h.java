package p003de.appplant.cordova.plugin.notification;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.p001v4.app.C0110u;
import com.google.devtools.build.android.desugar.runtime.ThrowableExtension;
import java.util.Date;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: de.appplant.cordova.plugin.notification.h */
public class C0290h {

    /* renamed from: a */
    private static Class<?> f824a = TriggerReceiver.class;

    /* renamed from: b */
    private final Context f825b;

    /* renamed from: c */
    private final C0292i f826c;

    /* renamed from: d */
    private final C0110u.C0113c f827d;

    /* renamed from: e */
    private Class<?> f828e = f824a;

    /* renamed from: de.appplant.cordova.plugin.notification.h$a */
    public enum C0291a {
        ALL,
        SCHEDULED,
        TRIGGERED
    }

    protected C0290h(Context context, C0292i iVar, C0110u.C0113c cVar, Class<?> cls) {
        this.f825b = context;
        this.f826c = iVar;
        this.f827d = cVar;
        this.f828e = cls == null ? f824a : cls;
    }

    /* renamed from: a */
    public C0292i mo3377a() {
        return this.f826c;
    }

    /* renamed from: b */
    public int mo3379b() {
        return this.f826c.mo3397h().intValue();
    }

    /* renamed from: c */
    public boolean mo3380c() {
        return mo3377a().mo3393d() > 0;
    }

    /* renamed from: d */
    public boolean mo3381d() {
        return new Date().after(this.f826c.mo3399j());
    }

    /* renamed from: e */
    public boolean mo3382e() {
        return mo3380c() || !mo3381d();
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public boolean mo3378a(boolean z) {
        boolean optBoolean = this.f826c.mo3391b().optBoolean("updated", false);
        if (!z) {
            this.f826c.mo3391b().remove("updated");
        }
        return optBoolean;
    }

    /* renamed from: f */
    public C0291a mo3383f() {
        return mo3382e() ? C0291a.SCHEDULED : C0291a.TRIGGERED;
    }

    /* renamed from: g */
    public void mo3384g() {
        long k = this.f826c.mo3400k();
        m1280l();
        PendingIntent broadcast = PendingIntent.getBroadcast(this.f825b, 0, new Intent(this.f825b, this.f828e).setAction(this.f826c.mo3398i()).putExtra("NOTIFICATION_OPTIONS", this.f826c.toString()), 268435456);
        if (mo3380c()) {
            m1284p().setRepeating(0, k, this.f826c.mo3393d(), broadcast);
        } else {
            m1284p().set(0, k, broadcast);
        }
    }

    /* renamed from: h */
    public void mo3385h() {
        if (!mo3380c() && mo3381d()) {
            m1281m();
        }
        if (!mo3380c()) {
            m1283o().cancel(mo3379b());
        }
    }

    /* renamed from: i */
    public void mo3386i() {
        m1284p().cancel(PendingIntent.getBroadcast(this.f825b, 0, new Intent(this.f825b, this.f828e).setAction(this.f826c.mo3398i()), 0));
        m1283o().cancel(this.f826c.mo3397h().intValue());
        m1281m();
    }

    /* renamed from: j */
    public void mo3387j() {
        m1279k();
    }

    /* renamed from: k */
    private void m1279k() {
        int intValue = mo3377a().mo3397h().intValue();
        if (Build.VERSION.SDK_INT <= 15) {
            m1283o().notify(intValue, this.f827d.mo576b());
        } else {
            m1283o().notify(intValue, this.f827d.mo581c());
        }
    }

    public String toString() {
        JSONObject b = this.f826c.mo3391b();
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject = new JSONObject(b.toString());
        } catch (JSONException e) {
            ThrowableExtension.printStackTrace(e);
        }
        jSONObject.remove("firstAt");
        jSONObject.remove("updated");
        jSONObject.remove("soundUri");
        jSONObject.remove("iconUri");
        return jSONObject.toString();
    }

    /* renamed from: l */
    private void m1280l() {
        SharedPreferences.Editor edit = m1282n().edit();
        edit.putString(this.f826c.mo3398i(), this.f826c.toString());
        if (Build.VERSION.SDK_INT < 9) {
            edit.commit();
        } else {
            edit.apply();
        }
    }

    /* renamed from: m */
    private void m1281m() {
        SharedPreferences.Editor edit = m1282n().edit();
        edit.remove(this.f826c.mo3398i());
        if (Build.VERSION.SDK_INT < 9) {
            edit.commit();
        } else {
            edit.apply();
        }
    }

    /* renamed from: n */
    private SharedPreferences m1282n() {
        return this.f825b.getSharedPreferences("LocalNotification", 0);
    }

    /* renamed from: o */
    private NotificationManager m1283o() {
        return (NotificationManager) this.f825b.getSystemService("notification");
    }

    /* renamed from: p */
    private AlarmManager m1284p() {
        return (AlarmManager) this.f825b.getSystemService("alarm");
    }

    /* renamed from: a */
    public static void m1278a(Class<?> cls) {
        f824a = cls;
    }
}
