package p003de.appplant.cordova.plugin.notification;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import com.google.devtools.build.android.desugar.runtime.ThrowableExtension;
import java.util.Date;
import org.apache.cordova.BuildConfig;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: de.appplant.cordova.plugin.notification.i */
public class C0292i {

    /* renamed from: a */
    private JSONObject f833a = new JSONObject();

    /* renamed from: b */
    private long f834b = 0;

    /* renamed from: c */
    private final Context f835c;

    /* renamed from: d */
    private final C0287e f836d;

    public C0292i(Context context) {
        this.f835c = context;
        this.f836d = C0287e.m1233a(context);
    }

    /* renamed from: a */
    public C0292i mo3390a(JSONObject jSONObject) {
        this.f833a = jSONObject;
        m1296s();
        m1297t();
        return this;
    }

    /* renamed from: s */
    private void m1296s() {
        String lowerCase = this.f833a.optString("every").toLowerCase();
        if (lowerCase.isEmpty()) {
            this.f834b = 0;
        } else if (lowerCase.equals("second")) {
            this.f834b = 1000;
        } else if (lowerCase.equals("minute")) {
            this.f834b = 60000;
        } else if (lowerCase.equals("hour")) {
            this.f834b = 3600000;
        } else if (lowerCase.equals("day")) {
            this.f834b = 86400000;
        } else if (lowerCase.equals("week")) {
            this.f834b = 604800000;
        } else if (lowerCase.equals("month")) {
            this.f834b = 2678400000L;
        } else if (lowerCase.equals("quarter")) {
            this.f834b = 7884000000L;
        } else if (lowerCase.equals("year")) {
            this.f834b = 31536000000L;
        } else {
            try {
                this.f834b = (long) (Integer.parseInt(lowerCase) * 60000);
            } catch (Exception e) {
                ThrowableExtension.printStackTrace(e);
            }
        }
    }

    /* renamed from: t */
    private void m1297t() {
        if (!this.f833a.has("iconUri") || this.f833a.optBoolean("updated")) {
            Uri b = this.f836d.mo3351b(this.f833a.optString("icon", "icon"));
            Uri a = this.f836d.mo3350a(this.f833a.optString("sound", (String) null));
            try {
                this.f833a.put("iconUri", b.toString());
                this.f833a.put("soundUri", a.toString());
            } catch (JSONException e) {
                ThrowableExtension.printStackTrace(e);
            }
        }
    }

    /* renamed from: a */
    public Context mo3389a() {
        return this.f835c;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public JSONObject mo3391b() {
        return this.f833a;
    }

    /* renamed from: c */
    public String mo3392c() {
        return this.f833a.optString("text", BuildConfig.FLAVOR);
    }

    /* renamed from: d */
    public long mo3393d() {
        return this.f834b;
    }

    /* renamed from: e */
    public int mo3394e() {
        return this.f833a.optInt("badge", 0);
    }

    /* renamed from: f */
    public Boolean mo3395f() {
        return Boolean.valueOf(this.f833a.optBoolean("ongoing", false));
    }

    /* renamed from: g */
    public Boolean mo3396g() {
        return Boolean.valueOf(this.f833a.optBoolean("autoClear", false));
    }

    /* renamed from: h */
    public Integer mo3397h() {
        return Integer.valueOf(this.f833a.optInt("id", 0));
    }

    /* renamed from: i */
    public String mo3398i() {
        return mo3397h().toString();
    }

    /* renamed from: j */
    public Date mo3399j() {
        return new Date(mo3400k());
    }

    /* renamed from: k */
    public long mo3400k() {
        return this.f833a.optLong("at", 0) * 1000;
    }

    /* renamed from: l */
    public String mo3401l() {
        String optString = this.f833a.optString("title", BuildConfig.FLAVOR);
        return optString.isEmpty() ? this.f835c.getApplicationInfo().loadLabel(this.f835c.getPackageManager()).toString() : optString;
    }

    /* renamed from: m */
    public int mo3402m() {
        String optString = this.f833a.optString("led", (String) null);
        if (optString == null) {
            return 4;
        }
        return Integer.parseInt(optString, 16) - 16777216;
    }

    /* renamed from: n */
    public int mo3403n() {
        String optString = this.f833a.optString("color", (String) null);
        if (optString == null) {
            return 0;
        }
        return Integer.parseInt(optString, 16) - 16777216;
    }

    /* renamed from: o */
    public Uri mo3404o() {
        try {
            return Uri.parse(this.f833a.optString("soundUri"));
        } catch (Exception e) {
            ThrowableExtension.printStackTrace(e);
            return null;
        }
    }

    /* renamed from: p */
    public Bitmap mo3405p() {
        try {
            return this.f836d.mo3349a(Uri.parse(this.f833a.optString("iconUri")));
        } catch (Exception e) {
            ThrowableExtension.printStackTrace(e);
            return this.f836d.mo3353d("icon");
        }
    }

    /* renamed from: q */
    public int mo3406q() {
        int c = this.f836d.mo3352c(this.f833a.optString("icon", BuildConfig.FLAVOR));
        if (c == 0) {
            c = mo3407r();
        }
        if (c == 0) {
            return 17301598;
        }
        return c;
    }

    /* renamed from: r */
    public int mo3407r() {
        return this.f836d.mo3352c(this.f833a.optString("smallIcon", BuildConfig.FLAVOR));
    }

    public String toString() {
        return this.f833a.toString();
    }
}
