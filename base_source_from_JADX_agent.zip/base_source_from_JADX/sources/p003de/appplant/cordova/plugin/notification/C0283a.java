package p003de.appplant.cordova.plugin.notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.google.devtools.build.android.desugar.runtime.ThrowableExtension;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: de.appplant.cordova.plugin.notification.a */
public abstract class C0283a extends BroadcastReceiver {
    /* renamed from: a */
    public abstract void mo3330a(C0290h hVar);

    public void onReceive(Context context, Intent intent) {
        try {
            mo3330a(new C0288f(context, new JSONObject(intent.getExtras().getString("NOTIFICATION_OPTIONS"))).mo3355a());
        } catch (JSONException e) {
            ThrowableExtension.printStackTrace(e);
        }
    }
}
