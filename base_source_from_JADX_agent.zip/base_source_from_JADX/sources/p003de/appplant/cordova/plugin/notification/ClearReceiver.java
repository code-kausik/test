package p003de.appplant.cordova.plugin.notification;

/* renamed from: de.appplant.cordova.plugin.notification.ClearReceiver */
public class ClearReceiver extends C0283a {
    /* renamed from: a */
    public void mo3330a(C0290h hVar) {
        hVar.mo3385h();
    }
}
