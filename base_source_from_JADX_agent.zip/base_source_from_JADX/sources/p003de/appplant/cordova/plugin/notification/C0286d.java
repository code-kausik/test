package p003de.appplant.cordova.plugin.notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.google.devtools.build.android.desugar.runtime.ThrowableExtension;
import java.util.Calendar;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: de.appplant.cordova.plugin.notification.d */
public abstract class C0286d extends BroadcastReceiver {
    /* renamed from: a */
    public abstract C0290h mo3340a(C0288f fVar);

    /* renamed from: a */
    public abstract void mo3341a(C0290h hVar, boolean z);

    public void onReceive(Context context, Intent intent) {
        try {
            C0292i a = new C0292i(context).mo3390a(new JSONObject(intent.getExtras().getString("NOTIFICATION_OPTIONS")));
            if (a != null && !m1230a(a).booleanValue()) {
                C0290h a2 = mo3340a(new C0288f(a));
                mo3341a(a2, a2.mo3378a(false));
            }
        } catch (JSONException e) {
            ThrowableExtension.printStackTrace(e);
        }
    }

    /* renamed from: a */
    private Boolean m1230a(C0292i iVar) {
        C0290h a = new C0288f(iVar).mo3355a();
        boolean z = false;
        if (!a.mo3380c()) {
            return false;
        }
        Calendar instance = Calendar.getInstance();
        Calendar instance2 = Calendar.getInstance();
        instance2.setTime(a.mo3377a().mo3399j());
        int i = instance2.get(11);
        int i2 = instance2.get(12);
        int i3 = instance.get(11);
        int i4 = instance.get(12);
        if (!(i3 == i || i4 == i2)) {
            z = true;
        }
        return Boolean.valueOf(z);
    }
}
