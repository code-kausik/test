package p003de.appplant.cordova.plugin.notification;

import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import com.google.devtools.build.android.desugar.runtime.ThrowableExtension;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;
import p003de.appplant.cordova.plugin.notification.C0290h;

/* renamed from: de.appplant.cordova.plugin.notification.g */
public class C0289g {

    /* renamed from: a */
    private Context f823a;

    private C0289g(Context context) {
        this.f823a = context;
    }

    /* renamed from: a */
    public static C0289g m1255a(Context context) {
        return new C0289g(context);
    }

    /* renamed from: a */
    public C0290h mo3361a(JSONObject jSONObject, Class<?> cls) {
        return mo3360a(new C0292i(this.f823a).mo3390a(jSONObject), cls);
    }

    /* renamed from: a */
    public C0290h mo3360a(C0292i iVar, Class<?> cls) {
        C0290h a = new C0288f(iVar).mo3354a(cls).mo3355a();
        a.mo3384g();
        return a;
    }

    /* renamed from: a */
    public C0290h mo3359a(int i, JSONObject jSONObject, Class<?> cls) {
        C0290h d = mo3374d(i);
        if (d == null) {
            return null;
        }
        d.mo3386i();
        JSONObject a = m1256a(d.mo3377a().mo3391b(), jSONObject);
        try {
            a.put("updated", true);
        } catch (JSONException unused) {
        }
        return mo3361a(a, cls);
    }

    /* renamed from: a */
    public C0290h mo3358a(int i) {
        C0290h d = mo3374d(i);
        if (d != null) {
            d.mo3385h();
        }
        return d;
    }

    /* renamed from: b */
    public C0290h mo3367b(int i) {
        C0290h d = mo3374d(i);
        if (d != null) {
            d.mo3386i();
        }
        return d;
    }

    /* renamed from: a */
    public void mo3365a() {
        for (C0290h h : mo3375d()) {
            h.mo3385h();
        }
        m1258g().cancelAll();
    }

    /* renamed from: b */
    public void mo3370b() {
        for (C0290h i : mo3375d()) {
            i.mo3386i();
        }
        m1258g().cancelAll();
    }

    /* renamed from: c */
    public List<Integer> mo3371c() {
        Set<String> keySet = m1257f().getAll().keySet();
        ArrayList arrayList = new ArrayList();
        for (String parseInt : keySet) {
            try {
                arrayList.add(Integer.valueOf(Integer.parseInt(parseInt)));
            } catch (NumberFormatException e) {
                ThrowableExtension.printStackTrace(e);
            }
        }
        return arrayList;
    }

    /* renamed from: a */
    public List<Integer> mo3362a(C0290h.C0291a aVar) {
        List<C0290h> d = mo3375d();
        ArrayList arrayList = new ArrayList();
        for (C0290h next : d) {
            if (next.mo3383f() == aVar) {
                arrayList.add(Integer.valueOf(next.mo3379b()));
            }
        }
        return arrayList;
    }

    /* renamed from: a */
    public List<C0290h> mo3364a(List<Integer> list) {
        ArrayList arrayList = new ArrayList();
        for (Integer intValue : list) {
            C0290h d = mo3374d(intValue.intValue());
            if (d != null) {
                arrayList.add(d);
            }
        }
        return arrayList;
    }

    /* renamed from: d */
    public List<C0290h> mo3375d() {
        return mo3364a(mo3371c());
    }

    /* renamed from: b */
    public List<C0290h> mo3368b(C0290h.C0291a aVar) {
        List<C0290h> d = mo3375d();
        ArrayList arrayList = new ArrayList();
        if (aVar == C0290h.C0291a.ALL) {
            return d;
        }
        for (C0290h next : d) {
            if (next.mo3383f() == aVar) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    /* renamed from: c */
    public boolean mo3373c(int i) {
        return mo3374d(i) != null;
    }

    /* renamed from: a */
    public boolean mo3366a(int i, C0290h.C0291a aVar) {
        C0290h d = mo3374d(i);
        return d != null && d.mo3383f() == aVar;
    }

    /* renamed from: e */
    public List<JSONObject> mo3376e() {
        return mo3369b(mo3371c());
    }

    /* renamed from: b */
    public List<JSONObject> mo3369b(List<Integer> list) {
        ArrayList arrayList = new ArrayList();
        for (Integer intValue : list) {
            C0290h d = mo3374d(intValue.intValue());
            if (d != null) {
                arrayList.add(d.mo3377a().mo3391b());
            }
        }
        return arrayList;
    }

    /* renamed from: c */
    public List<JSONObject> mo3372c(C0290h.C0291a aVar) {
        ArrayList arrayList = new ArrayList();
        for (C0290h a : mo3368b(aVar)) {
            arrayList.add(a.mo3377a().mo3391b());
        }
        return arrayList;
    }

    /* renamed from: a */
    public List<JSONObject> mo3363a(C0290h.C0291a aVar, List<Integer> list) {
        if (aVar == C0290h.C0291a.ALL) {
            return mo3369b(list);
        }
        ArrayList arrayList = new ArrayList();
        for (C0290h next : mo3364a(list)) {
            if (next.mo3383f() == aVar) {
                arrayList.add(next.mo3377a().mo3391b());
            }
        }
        return arrayList;
    }

    /* renamed from: d */
    public C0290h mo3374d(int i) {
        Map<String, ?> all = m1257f().getAll();
        String num = Integer.toString(i);
        if (!all.containsKey(num)) {
            return null;
        }
        try {
            return new C0288f(this.f823a, new JSONObject(all.get(num).toString())).mo3355a();
        } catch (JSONException e) {
            ThrowableExtension.printStackTrace(e);
            return null;
        }
    }

    /* renamed from: a */
    private JSONObject m1256a(JSONObject jSONObject, JSONObject jSONObject2) {
        Iterator<String> keys = jSONObject2.keys();
        while (keys.hasNext()) {
            try {
                String next = keys.next();
                jSONObject.put(next, jSONObject2.opt(next));
            } catch (JSONException e) {
                ThrowableExtension.printStackTrace(e);
            }
        }
        return jSONObject;
    }

    /* renamed from: f */
    private SharedPreferences m1257f() {
        return this.f823a.getSharedPreferences("LocalNotification", 0);
    }

    /* renamed from: g */
    private NotificationManager m1258g() {
        return (NotificationManager) this.f823a.getSystemService("notification");
    }
}
