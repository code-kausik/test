package p003de.appplant.cordova.plugin.notification;

/* renamed from: de.appplant.cordova.plugin.notification.TriggerReceiver */
public class TriggerReceiver extends C0286d {
    /* renamed from: a */
    public void mo3341a(C0290h hVar, boolean z) {
        hVar.mo3387j();
    }

    /* renamed from: a */
    public C0290h mo3340a(C0288f fVar) {
        return fVar.mo3355a();
    }
}
