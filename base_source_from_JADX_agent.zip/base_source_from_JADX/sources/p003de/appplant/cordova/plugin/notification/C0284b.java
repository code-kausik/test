package p003de.appplant.cordova.plugin.notification;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.google.devtools.build.android.desugar.runtime.ThrowableExtension;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: de.appplant.cordova.plugin.notification.b */
public abstract class C0284b extends Activity {
    /* renamed from: a */
    public abstract C0290h mo3331a(C0288f fVar);

    /* renamed from: a */
    public abstract void mo3332a(C0290h hVar);

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Bundle extras = getIntent().getExtras();
        try {
            mo3332a(mo3331a(new C0288f(getApplicationContext(), new JSONObject(extras.getString("NOTIFICATION_OPTIONS")))));
        } catch (JSONException e) {
            ThrowableExtension.printStackTrace(e);
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        finish();
    }

    /* renamed from: a */
    public void mo3343a() {
        Context applicationContext = getApplicationContext();
        Intent launchIntentForPackage = applicationContext.getPackageManager().getLaunchIntentForPackage(applicationContext.getPackageName());
        launchIntentForPackage.addFlags(537001984);
        applicationContext.startActivity(launchIntentForPackage);
    }
}
