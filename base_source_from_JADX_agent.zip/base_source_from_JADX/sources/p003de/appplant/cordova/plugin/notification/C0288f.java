package p003de.appplant.cordova.plugin.notification;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.p001v4.app.C0110u;
import java.util.Random;
import org.json.JSONObject;

/* renamed from: de.appplant.cordova.plugin.notification.f */
public class C0288f {

    /* renamed from: a */
    private final Context f818a;

    /* renamed from: b */
    private final C0292i f819b;

    /* renamed from: c */
    private Class<?> f820c;

    /* renamed from: d */
    private Class<?> f821d = ClearReceiver.class;

    /* renamed from: e */
    private Class<?> f822e = ClickActivity.class;

    public C0288f(Context context, JSONObject jSONObject) {
        this.f818a = context;
        this.f819b = new C0292i(context).mo3390a(jSONObject);
    }

    public C0288f(C0292i iVar) {
        this.f818a = iVar.mo3389a();
        this.f819b = iVar;
    }

    /* renamed from: a */
    public C0288f mo3354a(Class<?> cls) {
        this.f820c = cls;
        return this;
    }

    /* renamed from: b */
    public C0288f mo3356b(Class<?> cls) {
        this.f821d = cls;
        return this;
    }

    /* renamed from: c */
    public C0288f mo3357c(Class<?> cls) {
        this.f822e = cls;
        return this;
    }

    /* renamed from: a */
    public C0290h mo3355a() {
        Uri o = this.f819b.mo3404o();
        int r = this.f819b.mo3407r();
        C0110u.C0113c a = new C0110u.C0113c(this.f818a).mo582c(0).mo574a((CharSequence) this.f819b.mo3401l()).mo579b((CharSequence) this.f819b.mo3392c()).mo577b(this.f819b.mo3394e()).mo583c((CharSequence) this.f819b.mo3392c()).mo580b(this.f819b.mo3396g().booleanValue()).mo575a(this.f819b.mo3395f().booleanValue()).mo585e(this.f819b.mo3403n()).mo569a(this.f819b.mo3402m(), 100, 100);
        if (o != null) {
            a.mo572a(o);
        }
        if (r == 0) {
            a.mo568a(this.f819b.mo3406q());
        } else {
            a.mo568a(this.f819b.mo3407r());
            a.mo571a(this.f819b.mo3405p());
        }
        m1249a(a);
        m1250b(a);
        return new C0290h(this.f818a, this.f819b, a, this.f820c);
    }

    /* renamed from: a */
    private void m1249a(C0110u.C0113c cVar) {
        if (this.f821d != null) {
            cVar.mo578b(PendingIntent.getBroadcast(this.f818a, 0, new Intent(this.f818a, this.f821d).setAction(this.f819b.mo3398i()).putExtra("NOTIFICATION_OPTIONS", this.f819b.toString()), 134217728));
        }
    }

    /* renamed from: b */
    private void m1250b(C0110u.C0113c cVar) {
        if (this.f822e != null) {
            Intent flags = new Intent(this.f818a, this.f822e).putExtra("NOTIFICATION_OPTIONS", this.f819b.toString()).setFlags(1073741824);
            cVar.mo570a(PendingIntent.getActivity(this.f818a, new Random().nextInt(), flags, 134217728));
        }
    }
}
