package p003de.appplant.cordova.plugin.localnotification;

import p003de.appplant.cordova.plugin.notification.C0288f;
import p003de.appplant.cordova.plugin.notification.C0290h;
import p003de.appplant.cordova.plugin.notification.TriggerReceiver;

/* renamed from: de.appplant.cordova.plugin.localnotification.ClickActivity */
public class ClickActivity extends p003de.appplant.cordova.plugin.notification.ClickActivity {
    /* renamed from: a */
    public void mo3332a(C0290h hVar) {
        LocalNotification.m1177a("click", hVar);
        super.mo3332a(hVar);
        if (!hVar.mo3377a().mo3395f().booleanValue()) {
            LocalNotification.m1177a(hVar.mo3380c() ? "clear" : "cancel", hVar);
        }
    }

    /* renamed from: a */
    public C0290h mo3331a(C0288f fVar) {
        return fVar.mo3354a((Class<?>) TriggerReceiver.class).mo3355a();
    }
}
