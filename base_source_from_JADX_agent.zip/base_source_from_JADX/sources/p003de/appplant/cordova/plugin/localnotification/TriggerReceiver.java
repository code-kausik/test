package p003de.appplant.cordova.plugin.localnotification;

import p003de.appplant.cordova.plugin.notification.C0288f;
import p003de.appplant.cordova.plugin.notification.C0290h;

/* renamed from: de.appplant.cordova.plugin.localnotification.TriggerReceiver */
public class TriggerReceiver extends p003de.appplant.cordova.plugin.notification.TriggerReceiver {
    /* renamed from: a */
    public void mo3341a(C0290h hVar, boolean z) {
        super.mo3341a(hVar, z);
        if (!z) {
            LocalNotification.m1177a("trigger", hVar);
        }
    }

    /* renamed from: a */
    public C0290h mo3340a(C0288f fVar) {
        return fVar.mo3354a((Class<?>) TriggerReceiver.class).mo3357c(ClickActivity.class).mo3356b((Class<?>) ClearReceiver.class).mo3355a();
    }
}
