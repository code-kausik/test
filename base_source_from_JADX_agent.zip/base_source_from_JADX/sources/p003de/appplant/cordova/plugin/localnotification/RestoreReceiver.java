package p003de.appplant.cordova.plugin.localnotification;

import p003de.appplant.cordova.plugin.notification.C0285c;
import p003de.appplant.cordova.plugin.notification.C0288f;
import p003de.appplant.cordova.plugin.notification.C0290h;

/* renamed from: de.appplant.cordova.plugin.localnotification.RestoreReceiver */
public class RestoreReceiver extends C0285c {
    /* renamed from: a */
    public void mo3339a(C0290h hVar) {
        if (hVar.mo3382e()) {
            hVar.mo3384g();
        } else {
            hVar.mo3386i();
        }
    }

    /* renamed from: a */
    public C0290h mo3338a(C0288f fVar) {
        return fVar.mo3354a((Class<?>) TriggerReceiver.class).mo3356b((Class<?>) ClearReceiver.class).mo3357c(ClickActivity.class).mo3355a();
    }
}
