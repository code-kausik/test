package p003de.appplant.cordova.plugin.localnotification;

import p003de.appplant.cordova.plugin.notification.C0290h;

/* renamed from: de.appplant.cordova.plugin.localnotification.ClearReceiver */
public class ClearReceiver extends p003de.appplant.cordova.plugin.notification.ClearReceiver {
    /* renamed from: a */
    public void mo3330a(C0290h hVar) {
        super.mo3330a(hVar);
        LocalNotification.m1177a("clear", hVar);
    }
}
