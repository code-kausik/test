package p003de.appplant.cordova.plugin.localnotification;

import android.content.Context;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import p003de.appplant.cordova.plugin.notification.C0289g;
import p003de.appplant.cordova.plugin.notification.C0290h;

/* renamed from: de.appplant.cordova.plugin.localnotification.LocalNotification */
public class LocalNotification extends CordovaPlugin {

    /* renamed from: a */
    protected static Boolean f808a = true;
    /* access modifiers changed from: private */

    /* renamed from: b */
    public static CordovaWebView f809b;

    /* renamed from: c */
    private static Boolean f810c = false;

    /* renamed from: d */
    private static ArrayList<String> f811d = new ArrayList<>();

    public void initialize(CordovaInterface cordovaInterface, CordovaWebView cordovaWebView) {
        f809b = this.webView;
    }

    public void onPause(boolean z) {
        super.onPause(z);
        f808a = true;
    }

    public void onResume(boolean z) {
        super.onResume(z);
        f808a = false;
        m1211f();
    }

    public void onDestroy() {
        f810c = false;
        f808a = true;
    }

    public boolean execute(final String str, final JSONArray jSONArray, final CallbackContext callbackContext) throws JSONException {
        C0290h.m1278a((Class<?>) TriggerReceiver.class);
        this.f1020cordova.getThreadPool().execute(new Runnable() {
            public void run() {
                if (str.equals("schedule")) {
                    LocalNotification.this.m1179a(jSONArray);
                    callbackContext.success();
                } else if (str.equals("update")) {
                    LocalNotification.this.m1191b(jSONArray);
                    callbackContext.success();
                } else if (str.equals("cancel")) {
                    LocalNotification.this.m1200c(jSONArray);
                    callbackContext.success();
                } else if (str.equals("cancelAll")) {
                    LocalNotification.this.m1202d();
                    callbackContext.success();
                } else if (str.equals("clear")) {
                    LocalNotification.this.m1205d(jSONArray);
                    callbackContext.success();
                } else if (str.equals("clearAll")) {
                    LocalNotification.this.m1208e();
                    callbackContext.success();
                } else if (str.equals("isPresent")) {
                    LocalNotification.this.m1169a(jSONArray.optInt(0), callbackContext);
                } else if (str.equals("isScheduled")) {
                    LocalNotification.this.m1183b(jSONArray.optInt(0), callbackContext);
                } else if (str.equals("isTriggered")) {
                    LocalNotification.this.m1194c(jSONArray.optInt(0), callbackContext);
                } else if (str.equals("getAllIds")) {
                    LocalNotification.this.m1178a(callbackContext);
                } else if (str.equals("getScheduledIds")) {
                    LocalNotification.this.m1190b(callbackContext);
                } else if (str.equals("getTriggeredIds")) {
                    LocalNotification.this.m1199c(callbackContext);
                } else if (str.equals("getSingle")) {
                    LocalNotification.this.m1181a(jSONArray, callbackContext);
                } else if (str.equals("getSingleScheduled")) {
                    LocalNotification.this.m1192b(jSONArray, callbackContext);
                } else if (str.equals("getSingleTriggered")) {
                    LocalNotification.this.m1201c(jSONArray, callbackContext);
                } else if (str.equals("getAll")) {
                    LocalNotification.this.m1206d(jSONArray, callbackContext);
                } else if (str.equals("getScheduled")) {
                    LocalNotification.this.m1210e(jSONArray, callbackContext);
                } else if (str.equals("getTriggered")) {
                    LocalNotification.this.m1213f(jSONArray, callbackContext);
                } else if (str.equals("deviceready")) {
                    LocalNotification.m1211f();
                }
            }
        });
        return true;
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m1179a(JSONArray jSONArray) {
        for (int i = 0; i < jSONArray.length(); i++) {
            m1177a("schedule", m1214g().mo3361a(jSONArray.optJSONObject(i), (Class<?>) TriggerReceiver.class));
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: b */
    public void m1191b(JSONArray jSONArray) {
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject optJSONObject = jSONArray.optJSONObject(i);
            C0290h a = m1214g().mo3359a(optJSONObject.optInt("id", 0), optJSONObject, TriggerReceiver.class);
            if (a != null) {
                m1177a("update", a);
            }
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: c */
    public void m1200c(JSONArray jSONArray) {
        for (int i = 0; i < jSONArray.length(); i++) {
            C0290h b = m1214g().mo3367b(jSONArray.optInt(i, 0));
            if (b != null) {
                m1177a("cancel", b);
            }
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: d */
    public void m1202d() {
        m1214g().mo3370b();
        m1175a("cancelall");
    }

    /* access modifiers changed from: private */
    /* renamed from: d */
    public void m1205d(JSONArray jSONArray) {
        for (int i = 0; i < jSONArray.length(); i++) {
            C0290h a = m1214g().mo3358a(jSONArray.optInt(i, 0));
            if (a != null) {
                m1177a("clear", a);
            }
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: e */
    public void m1208e() {
        m1214g().mo3365a();
        m1175a("clearall");
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m1169a(int i, CallbackContext callbackContext) {
        callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, m1214g().mo3373c(i)));
    }

    /* access modifiers changed from: private */
    /* renamed from: b */
    public void m1183b(int i, CallbackContext callbackContext) {
        callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, m1214g().mo3366a(i, C0290h.C0291a.SCHEDULED)));
    }

    /* access modifiers changed from: private */
    /* renamed from: c */
    public void m1194c(int i, CallbackContext callbackContext) {
        callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, m1214g().mo3366a(i, C0290h.C0291a.TRIGGERED)));
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m1178a(CallbackContext callbackContext) {
        callbackContext.success(new JSONArray(m1214g().mo3371c()));
    }

    /* access modifiers changed from: private */
    /* renamed from: b */
    public void m1190b(CallbackContext callbackContext) {
        callbackContext.success(new JSONArray(m1214g().mo3362a(C0290h.C0291a.SCHEDULED)));
    }

    /* access modifiers changed from: private */
    /* renamed from: c */
    public void m1199c(CallbackContext callbackContext) {
        callbackContext.success(new JSONArray(m1214g().mo3362a(C0290h.C0291a.TRIGGERED)));
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m1181a(JSONArray jSONArray, CallbackContext callbackContext) {
        m1176a(jSONArray.optString(0), C0290h.C0291a.ALL, callbackContext);
    }

    /* access modifiers changed from: private */
    /* renamed from: b */
    public void m1192b(JSONArray jSONArray, CallbackContext callbackContext) {
        m1176a(jSONArray.optString(0), C0290h.C0291a.SCHEDULED, callbackContext);
    }

    /* access modifiers changed from: private */
    /* renamed from: c */
    public void m1201c(JSONArray jSONArray, CallbackContext callbackContext) {
        m1176a(jSONArray.optString(0), C0290h.C0291a.TRIGGERED, callbackContext);
    }

    /* access modifiers changed from: private */
    /* renamed from: d */
    public void m1206d(JSONArray jSONArray, CallbackContext callbackContext) {
        m1180a(jSONArray, C0290h.C0291a.ALL, callbackContext);
    }

    /* access modifiers changed from: private */
    /* renamed from: e */
    public void m1210e(JSONArray jSONArray, CallbackContext callbackContext) {
        m1180a(jSONArray, C0290h.C0291a.SCHEDULED, callbackContext);
    }

    /* access modifiers changed from: private */
    /* renamed from: f */
    public void m1213f(JSONArray jSONArray, CallbackContext callbackContext) {
        m1180a(jSONArray, C0290h.C0291a.TRIGGERED, callbackContext);
    }

    /* renamed from: a */
    private void m1176a(String str, C0290h.C0291a aVar, CallbackContext callbackContext) {
        PluginResult pluginResult;
        List<JSONObject> a = m1214g().mo3363a(aVar, m1207e(new JSONArray().put(str)));
        if (a.isEmpty()) {
            pluginResult = new PluginResult(PluginResult.Status.NO_RESULT);
        } else {
            pluginResult = new PluginResult(PluginResult.Status.OK, a.get(0));
        }
        callbackContext.sendPluginResult(pluginResult);
    }

    /* renamed from: a */
    private void m1180a(JSONArray jSONArray, C0290h.C0291a aVar, CallbackContext callbackContext) {
        List<JSONObject> list;
        if (jSONArray.length() == 0) {
            list = m1214g().mo3372c(aVar);
        } else {
            list = m1214g().mo3363a(aVar, m1207e(jSONArray));
        }
        callbackContext.success(new JSONArray(list));
    }

    /* access modifiers changed from: private */
    /* renamed from: f */
    public static synchronized void m1211f() {
        synchronized (LocalNotification.class) {
            f808a = false;
            f810c = true;
            Iterator<String> it = f811d.iterator();
            while (it.hasNext()) {
                m1189b(it.next());
            }
            f811d.clear();
        }
    }

    /* renamed from: a */
    private void m1175a(String str) {
        m1177a(str, (C0290h) null);
    }

    /* renamed from: a */
    static void m1177a(String str, C0290h hVar) {
        String str2 = "\"" + m1168a() + "\"";
        if (hVar != null) {
            str2 = hVar.toString() + "," + str2;
        }
        m1189b("cordova.plugins.notification.local.core.fireEvent(\"" + str + "\"," + str2 + ")");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(6:8|9|10|11|12|13) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:12:0x0035 */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static synchronized void m1189b(final java.lang.String r7) {
        /*
            java.lang.Class<de.appplant.cordova.plugin.localnotification.LocalNotification> r0 = p003de.appplant.cordova.plugin.localnotification.LocalNotification.class
            monitor-enter(r0)
            java.lang.Boolean r1 = f810c     // Catch:{ all -> 0x0042 }
            boolean r1 = r1.booleanValue()     // Catch:{ all -> 0x0042 }
            if (r1 != 0) goto L_0x0012
            java.util.ArrayList<java.lang.String> r1 = f811d     // Catch:{ all -> 0x0042 }
            r1.add(r7)     // Catch:{ all -> 0x0042 }
            monitor-exit(r0)
            return
        L_0x0012:
            de.appplant.cordova.plugin.localnotification.LocalNotification$2 r1 = new de.appplant.cordova.plugin.localnotification.LocalNotification$2     // Catch:{ all -> 0x0042 }
            r1.<init>(r7)     // Catch:{ all -> 0x0042 }
            org.apache.cordova.CordovaWebView r7 = f809b     // Catch:{ Exception -> 0x0035 }
            java.lang.Class r7 = r7.getClass()     // Catch:{ Exception -> 0x0035 }
            java.lang.String r2 = "post"
            r3 = 1
            java.lang.Class[] r4 = new java.lang.Class[r3]     // Catch:{ Exception -> 0x0035 }
            java.lang.Class<java.lang.Runnable> r5 = java.lang.Runnable.class
            r6 = 0
            r4[r6] = r5     // Catch:{ Exception -> 0x0035 }
            java.lang.reflect.Method r7 = r7.getMethod(r2, r4)     // Catch:{ Exception -> 0x0035 }
            org.apache.cordova.CordovaWebView r2 = f809b     // Catch:{ Exception -> 0x0035 }
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x0035 }
            r3[r6] = r1     // Catch:{ Exception -> 0x0035 }
            r7.invoke(r2, r3)     // Catch:{ Exception -> 0x0035 }
            goto L_0x0040
        L_0x0035:
            org.apache.cordova.CordovaWebView r7 = f809b     // Catch:{ all -> 0x0042 }
            android.content.Context r7 = r7.getContext()     // Catch:{ all -> 0x0042 }
            android.app.Activity r7 = (android.app.Activity) r7     // Catch:{ all -> 0x0042 }
            r7.runOnUiThread(r1)     // Catch:{ all -> 0x0042 }
        L_0x0040:
            monitor-exit(r0)
            return
        L_0x0042:
            r7 = move-exception
            monitor-exit(r0)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: p003de.appplant.cordova.plugin.localnotification.LocalNotification.m1189b(java.lang.String):void");
    }

    /* renamed from: e */
    private List<Integer> m1207e(JSONArray jSONArray) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(Integer.valueOf(jSONArray.optInt(i)));
        }
        return arrayList;
    }

    /* renamed from: a */
    static String m1168a() {
        return f808a.booleanValue() ? "background" : "foreground";
    }

    /* renamed from: g */
    private C0289g m1214g() {
        return C0289g.m1255a((Context) this.f1020cordova.getActivity());
    }
}
