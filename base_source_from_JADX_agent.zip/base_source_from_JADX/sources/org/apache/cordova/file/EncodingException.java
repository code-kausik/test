package org.apache.cordova.file;

public class EncodingException extends Exception {
    public EncodingException(String str) {
        super(str);
    }
}
