package org.apache.cordova.file;

public class InvalidModificationException extends Exception {
    public InvalidModificationException(String str) {
        super(str);
    }
}
