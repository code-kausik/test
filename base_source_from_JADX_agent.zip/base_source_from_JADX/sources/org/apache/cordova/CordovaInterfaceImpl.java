package org.apache.cordova;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.cordova.PluginResult;
import org.json.JSONException;
import org.json.JSONObject;

public class CordovaInterfaceImpl implements CordovaInterface {
    private static final String TAG = "CordovaInterfaceImpl";
    protected Activity activity;
    protected CordovaPlugin activityResultCallback;
    protected int activityResultRequestCode;
    protected boolean activityWasDestroyed;
    protected String initCallbackService;
    protected CordovaPlugin permissionResultCallback;
    protected PluginManager pluginManager;
    protected Bundle savedPluginState;
    protected ActivityResultHolder savedResult;
    protected ExecutorService threadPool;

    public CordovaInterfaceImpl(Activity activity2) {
        this(activity2, Executors.newCachedThreadPool());
    }

    public CordovaInterfaceImpl(Activity activity2, ExecutorService executorService) {
        this.activityWasDestroyed = false;
        this.activity = activity2;
        this.threadPool = executorService;
    }

    public void startActivityForResult(CordovaPlugin cordovaPlugin, Intent intent, int i) {
        setActivityResultCallback(cordovaPlugin);
        try {
            this.activity.startActivityForResult(intent, i);
        } catch (RuntimeException e) {
            this.activityResultCallback = null;
            throw e;
        }
    }

    public void setActivityResultCallback(CordovaPlugin cordovaPlugin) {
        if (this.activityResultCallback != null) {
            this.activityResultCallback.onActivityResult(this.activityResultRequestCode, 0, (Intent) null);
        }
        this.activityResultCallback = cordovaPlugin;
    }

    public Activity getActivity() {
        return this.activity;
    }

    public Object onMessage(String str, Object obj) {
        if (!"exit".equals(str)) {
            return null;
        }
        this.activity.finish();
        return null;
    }

    public ExecutorService getThreadPool() {
        return this.threadPool;
    }

    public void onCordovaInit(PluginManager pluginManager2) {
        CoreAndroid coreAndroid;
        this.pluginManager = pluginManager2;
        if (this.savedResult != null) {
            onActivityResult(this.savedResult.requestCode, this.savedResult.resultCode, this.savedResult.intent);
        } else if (this.activityWasDestroyed) {
            this.activityWasDestroyed = false;
            if (pluginManager2 != null && (coreAndroid = (CoreAndroid) pluginManager2.getPlugin(CoreAndroid.PLUGIN_NAME)) != null) {
                JSONObject jSONObject = new JSONObject();
                try {
                    jSONObject.put("action", "resume");
                } catch (JSONException e) {
                    LOG.m1449e(TAG, "Failed to create event message", (Throwable) e);
                }
                coreAndroid.sendResumeEvent(new PluginResult(PluginResult.Status.OK, jSONObject));
            }
        }
    }

    public boolean onActivityResult(int i, int i2, Intent intent) {
        CordovaPlugin cordovaPlugin = this.activityResultCallback;
        if (cordovaPlugin == null && this.initCallbackService != null) {
            this.savedResult = new ActivityResultHolder(i, i2, intent);
            if (!(this.pluginManager == null || (cordovaPlugin = this.pluginManager.getPlugin(this.initCallbackService)) == null)) {
                cordovaPlugin.onRestoreStateForActivityResult(this.savedPluginState.getBundle(cordovaPlugin.getServiceName()), new ResumeCallback(cordovaPlugin.getServiceName(), this.pluginManager));
            }
        }
        this.activityResultCallback = null;
        if (cordovaPlugin != null) {
            Log.d(TAG, "Sending activity result to plugin");
            this.initCallbackService = null;
            this.savedResult = null;
            cordovaPlugin.onActivityResult(i, i2, intent);
            return true;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Got an activity result, but no plugin was registered to receive it");
        sb.append(this.savedResult != null ? " yet!" : ".");
        Log.w(TAG, sb.toString());
        return false;
    }

    public void setActivityResultRequestCode(int i) {
        this.activityResultRequestCode = i;
    }

    public void onSaveInstanceState(Bundle bundle) {
        if (this.activityResultCallback != null) {
            bundle.putString("callbackService", this.activityResultCallback.getServiceName());
        }
        if (this.pluginManager != null) {
            bundle.putBundle("plugin", this.pluginManager.onSaveInstanceState());
        }
    }

    public void restoreInstanceState(Bundle bundle) {
        this.initCallbackService = bundle.getString("callbackService");
        this.savedPluginState = bundle.getBundle("plugin");
        this.activityWasDestroyed = true;
    }

    private static class ActivityResultHolder {
        /* access modifiers changed from: private */
        public Intent intent;
        /* access modifiers changed from: private */
        public int requestCode;
        /* access modifiers changed from: private */
        public int resultCode;

        public ActivityResultHolder(int i, int i2, Intent intent2) {
            this.requestCode = i;
            this.resultCode = i2;
            this.intent = intent2;
        }
    }

    public void onRequestPermissionResult(int i, String[] strArr, int[] iArr) throws JSONException {
        if (this.permissionResultCallback != null) {
            this.permissionResultCallback.onRequestPermissionResult(i, strArr, iArr);
            this.permissionResultCallback = null;
        }
    }

    public void requestPermission(CordovaPlugin cordovaPlugin, int i, String str) {
        this.permissionResultCallback = cordovaPlugin;
        getActivity().requestPermissions(new String[]{str}, i);
    }

    public void requestPermissions(CordovaPlugin cordovaPlugin, int i, String[] strArr) {
        this.permissionResultCallback = cordovaPlugin;
        getActivity().requestPermissions(strArr, i);
    }

    public boolean hasPermission(String str) {
        if (Build.VERSION.SDK_INT < 23 || this.activity.checkSelfPermission(str) == 0) {
            return true;
        }
        return false;
    }
}
