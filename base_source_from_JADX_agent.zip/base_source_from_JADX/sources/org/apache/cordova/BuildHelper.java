package org.apache.cordova;

import android.content.Context;
import com.google.devtools.build.android.desugar.runtime.ThrowableExtension;

public class BuildHelper {
    private static String TAG = "BuildHelper";

    public static Object getBuildConfigValue(Context context, String str) {
        try {
            return Class.forName(context.getPackageName() + ".BuildConfig").getField(str).get((Object) null);
        } catch (ClassNotFoundException e) {
            LOG.m1445d(TAG, "Unable to get the BuildConfig, is this built with ANT?");
            ThrowableExtension.printStackTrace(e);
            return null;
        } catch (NoSuchFieldException unused) {
            String str2 = TAG;
            LOG.m1445d(str2, str + " is not a valid field. Check your build.gradle");
            return null;
        } catch (IllegalAccessException e2) {
            LOG.m1445d(TAG, "Illegal Access Exception: Let's print a stack trace.");
            ThrowableExtension.printStackTrace(e2);
            return null;
        }
    }
}
