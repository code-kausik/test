package org.apache.cordova.statusbar;

import android.graphics.Color;
import android.os.Build;
import android.util.Log;
import android.view.Window;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaArgs;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.json.JSONException;

public class StatusBar extends CordovaPlugin {
    private static final String TAG = "StatusBar";

    public void initialize(final CordovaInterface cordovaInterface, CordovaWebView cordovaWebView) {
        Log.v(TAG, "StatusBar: initialization");
        super.initialize(cordovaInterface, cordovaWebView);
        this.f1020cordova.getActivity().runOnUiThread(new Runnable() {
            public void run() {
                cordovaInterface.getActivity().getWindow().clearFlags(2048);
                StatusBar.this.setStatusBarBackgroundColor(StatusBar.this.preferences.getString("StatusBarBackgroundColor", "#000000"));
            }
        });
    }

    public boolean execute(String str, final CordovaArgs cordovaArgs, CallbackContext callbackContext) throws JSONException {
        Log.v(TAG, "Executing action: " + str);
        final Window window = this.f1020cordova.getActivity().getWindow();
        boolean z = false;
        if ("_ready".equals(str)) {
            if ((window.getAttributes().flags & 1024) == 0) {
                z = true;
            }
            callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.OK, z));
            return true;
        } else if ("show".equals(str)) {
            this.f1020cordova.getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    if (Build.VERSION.SDK_INT >= 19) {
                        window.getDecorView().setSystemUiVisibility(window.getDecorView().getSystemUiVisibility() & -1025 & -5);
                        return;
                    }
                    window.clearFlags(1024);
                }
            });
            return true;
        } else if ("hide".equals(str)) {
            this.f1020cordova.getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    if (Build.VERSION.SDK_INT >= 19) {
                        window.getDecorView().setSystemUiVisibility(window.getDecorView().getSystemUiVisibility() | 1024 | 4);
                        return;
                    }
                    window.addFlags(1024);
                }
            });
            return true;
        } else if (!"backgroundColorByHexString".equals(str)) {
            return false;
        } else {
            this.f1020cordova.getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        StatusBar.this.setStatusBarBackgroundColor(cordovaArgs.getString(0));
                    } catch (JSONException unused) {
                        Log.e(StatusBar.TAG, "Invalid hexString argument, use f.i. '#777777'");
                    }
                }
            });
            return true;
        }
    }

    /* access modifiers changed from: private */
    public void setStatusBarBackgroundColor(String str) {
        if (Build.VERSION.SDK_INT >= 21 && str != null && !str.isEmpty()) {
            Window window = this.f1020cordova.getActivity().getWindow();
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            try {
                window.getClass().getDeclaredMethod("setStatusBarColor", new Class[]{Integer.TYPE}).invoke(window, new Object[]{Integer.valueOf(Color.parseColor(str))});
            } catch (IllegalArgumentException unused) {
                Log.e(TAG, "Invalid hexString argument, use f.i. '#999999'");
            } catch (Exception unused2) {
                Log.w(TAG, "Method window.setStatusBarColor not found for SDK level " + Build.VERSION.SDK_INT);
            }
        }
    }
}
