package android.arch.lifecycle;

import android.arch.lifecycle.C0012c;
import java.util.Map;

public abstract class LiveData<T> {
    /* access modifiers changed from: private */

    /* renamed from: b */
    public static final Object f8b = new Object();
    /* access modifiers changed from: private */

    /* renamed from: a */
    public final Object f9a = new Object();

    /* renamed from: c */
    private C0293e<C0024k<T>, LiveData<T>.C0000a> f10c = new C0293e<>();
    /* access modifiers changed from: private */

    /* renamed from: d */
    public int f11d = 0;

    /* renamed from: e */
    private volatile Object f12e = f8b;
    /* access modifiers changed from: private */

    /* renamed from: f */
    public volatile Object f13f = f8b;

    /* renamed from: g */
    private int f14g = -1;

    /* renamed from: h */
    private boolean f15h;

    /* renamed from: i */
    private boolean f16i;

    /* renamed from: j */
    private final Runnable f17j = new Runnable() {
        public void run() {
            Object b;
            synchronized (LiveData.this.f9a) {
                b = LiveData.this.f13f;
                Object unused = LiveData.this.f13f = LiveData.f8b;
            }
            LiveData.this.mo23a(b);
        }
    };

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public void mo24b() {
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public void mo25c() {
    }

    /* renamed from: a */
    private void m31a(LiveData<T>.C0000a aVar) {
        if (aVar.f22d) {
            if (!aVar.mo28a()) {
                aVar.mo31a(false);
            } else if (aVar.f23e < this.f14g) {
                aVar.f23e = this.f14g;
                aVar.f21c.mo48a(this.f12e);
            }
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: b */
    public void m35b(LiveData<T>.C0000a aVar) {
        if (this.f15h) {
            this.f16i = true;
            return;
        }
        this.f15h = true;
        do {
            this.f16i = false;
            if (aVar == null) {
                C0293e<K, V>.C0280d c = this.f10c.mo3412c();
                while (c.hasNext()) {
                    m31a((LiveData<T>.C0000a) (C0007a) ((Map.Entry) c.next()).getValue());
                    if (this.f16i) {
                        break;
                    }
                }
            } else {
                m31a(aVar);
                aVar = null;
            }
        } while (this.f16i);
        this.f15h = false;
    }

    /* renamed from: a */
    public void mo21a(C0016e eVar, C0024k<T> kVar) {
        if (eVar.getLifecycle().mo39a() != C0012c.C0014b.DESTROYED) {
            LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(eVar, kVar);
            C0007a a = this.f10c.mo3326a(kVar, lifecycleBoundObserver);
            if (a != null && !a.mo29a(eVar)) {
                throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
            } else if (a == null) {
                eVar.getLifecycle().mo40a(lifecycleBoundObserver);
            }
        }
    }

    /* renamed from: a */
    public void mo22a(C0024k<T> kVar) {
        m33a("removeObserver");
        C0007a b = this.f10c.mo3327b(kVar);
        if (b != null) {
            b.mo30b();
            b.mo31a(false);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo23a(T t) {
        m33a("setValue");
        this.f14g++;
        this.f12e = t;
        m35b((LiveData<T>.C0000a) null);
    }

    /* renamed from: a */
    public T mo20a() {
        T t = this.f12e;
        if (t != f8b) {
            return t;
        }
        return null;
    }

    /* renamed from: d */
    public boolean mo26d() {
        return this.f11d > 0;
    }

    class LifecycleBoundObserver extends LiveData<T>.C0000a implements GenericLifecycleObserver {

        /* renamed from: a */
        final C0016e f19a;

        LifecycleBoundObserver(C0016e eVar, C0024k<T> kVar) {
            super(kVar);
            this.f19a = eVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public boolean mo28a() {
            return this.f19a.getLifecycle().mo39a().mo42a(C0012c.C0014b.STARTED);
        }

        /* renamed from: a */
        public void mo13a(C0016e eVar, C0012c.C0013a aVar) {
            if (this.f19a.getLifecycle().mo39a() == C0012c.C0014b.DESTROYED) {
                LiveData.this.mo22a(this.f21c);
            } else {
                mo31a(mo28a());
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public boolean mo29a(C0016e eVar) {
            return this.f19a == eVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo30b() {
            this.f19a.getLifecycle().mo41b(this);
        }
    }

    /* renamed from: android.arch.lifecycle.LiveData$a */
    private abstract class C0007a {

        /* renamed from: c */
        final C0024k<T> f21c;

        /* renamed from: d */
        boolean f22d;

        /* renamed from: e */
        int f23e = -1;

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public abstract boolean mo28a();

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public boolean mo29a(C0016e eVar) {
            return false;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo30b() {
        }

        C0007a(C0024k<T> kVar) {
            this.f21c = kVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo31a(boolean z) {
            if (z != this.f22d) {
                this.f22d = z;
                int i = 1;
                boolean z2 = LiveData.this.f11d == 0;
                LiveData liveData = LiveData.this;
                int c = liveData.f11d;
                if (!this.f22d) {
                    i = -1;
                }
                int unused = liveData.f11d = c + i;
                if (z2 && this.f22d) {
                    LiveData.this.mo24b();
                }
                if (LiveData.this.f11d == 0 && !this.f22d) {
                    LiveData.this.mo25c();
                }
                if (this.f22d) {
                    LiveData.this.m35b((LiveData<T>.C0000a) this);
                }
            }
        }
    }

    /* renamed from: a */
    private static void m33a(String str) {
        if (!C0000a.m0a().mo3b()) {
            throw new IllegalStateException("Cannot invoke " + str + " on a background" + " thread");
        }
    }
}
