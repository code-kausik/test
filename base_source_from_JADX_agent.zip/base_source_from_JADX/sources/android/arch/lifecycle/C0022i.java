package android.arch.lifecycle;

import java.util.HashMap;
import java.util.Map;

/* renamed from: android.arch.lifecycle.i */
public class C0022i {

    /* renamed from: a */
    private Map<String, Integer> f54a = new HashMap();
}
