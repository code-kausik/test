package android.arch.lifecycle;

import android.arch.lifecycle.C0012c;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: android.arch.lifecycle.a */
class C0008a {

    /* renamed from: a */
    static C0008a f28a = new C0008a();

    /* renamed from: b */
    private final Map<Class, C0009a> f29b = new HashMap();

    /* renamed from: c */
    private final Map<Class, Boolean> f30c = new HashMap();

    C0008a() {
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public boolean mo32a(Class cls) {
        if (this.f30c.containsKey(cls)) {
            return this.f30c.get(cls).booleanValue();
        }
        Method[] c = m57c(cls);
        for (Method annotation : c) {
            if (((C0025l) annotation.getAnnotation(C0025l.class)) != null) {
                m55a(cls, c);
                return true;
            }
        }
        this.f30c.put(cls, false);
        return false;
    }

    /* renamed from: c */
    private Method[] m57c(Class cls) {
        try {
            return cls.getDeclaredMethods();
        } catch (NoClassDefFoundError e) {
            throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public C0009a mo33b(Class cls) {
        C0009a aVar = this.f29b.get(cls);
        if (aVar != null) {
            return aVar;
        }
        return m55a(cls, (Method[]) null);
    }

    /* renamed from: a */
    private void m56a(Map<C0010b, C0012c.C0013a> map, C0010b bVar, C0012c.C0013a aVar, Class cls) {
        C0012c.C0013a aVar2 = map.get(bVar);
        if (aVar2 != null && aVar != aVar2) {
            Method method = bVar.f34b;
            throw new IllegalArgumentException("Method " + method.getName() + " in " + cls.getName() + " already declared with different @OnLifecycleEvent value: previous value " + aVar2 + ", new value " + aVar);
        } else if (aVar2 == null) {
            map.put(bVar, aVar);
        }
    }

    /* renamed from: a */
    private C0009a m55a(Class cls, Method[] methodArr) {
        int i;
        C0009a b;
        Class superclass = cls.getSuperclass();
        HashMap hashMap = new HashMap();
        if (!(superclass == null || (b = mo33b(superclass)) == null)) {
            hashMap.putAll(b.f32b);
        }
        for (Class b2 : cls.getInterfaces()) {
            for (Map.Entry next : mo33b(b2).f32b.entrySet()) {
                m56a(hashMap, (C0010b) next.getKey(), (C0012c.C0013a) next.getValue(), cls);
            }
        }
        if (methodArr == null) {
            methodArr = m57c(cls);
        }
        boolean z = false;
        for (Method method : methodArr) {
            C0025l lVar = (C0025l) method.getAnnotation(C0025l.class);
            if (lVar != null) {
                Class[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i = 0;
                } else if (!parameterTypes[0].isAssignableFrom(C0016e.class)) {
                    throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                } else {
                    i = 1;
                }
                C0012c.C0013a a = lVar.mo49a();
                if (parameterTypes.length > 1) {
                    if (!parameterTypes[1].isAssignableFrom(C0012c.C0013a.class)) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    } else if (a != C0012c.C0013a.ON_ANY) {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    } else {
                        i = 2;
                    }
                }
                if (parameterTypes.length > 2) {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
                m56a(hashMap, new C0010b(i, method), a, cls);
                z = true;
            }
        }
        C0009a aVar = new C0009a(hashMap);
        this.f29b.put(cls, aVar);
        this.f30c.put(cls, Boolean.valueOf(z));
        return aVar;
    }

    /* renamed from: android.arch.lifecycle.a$a */
    static class C0009a {

        /* renamed from: a */
        final Map<C0012c.C0013a, List<C0010b>> f31a = new HashMap();

        /* renamed from: b */
        final Map<C0010b, C0012c.C0013a> f32b;

        C0009a(Map<C0010b, C0012c.C0013a> map) {
            this.f32b = map;
            for (Map.Entry next : map.entrySet()) {
                C0012c.C0013a aVar = (C0012c.C0013a) next.getValue();
                List list = this.f31a.get(aVar);
                if (list == null) {
                    list = new ArrayList();
                    this.f31a.put(aVar, list);
                }
                list.add(next.getKey());
            }
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo34a(C0016e eVar, C0012c.C0013a aVar, Object obj) {
            m60a(this.f31a.get(aVar), eVar, aVar, obj);
            m60a(this.f31a.get(C0012c.C0013a.ON_ANY), eVar, aVar, obj);
        }

        /* renamed from: a */
        private static void m60a(List<C0010b> list, C0016e eVar, C0012c.C0013a aVar, Object obj) {
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    list.get(size).mo35a(eVar, aVar, obj);
                }
            }
        }
    }

    /* renamed from: android.arch.lifecycle.a$b */
    static class C0010b {

        /* renamed from: a */
        final int f33a;

        /* renamed from: b */
        final Method f34b;

        C0010b(int i, Method method) {
            this.f33a = i;
            this.f34b = method;
            this.f34b.setAccessible(true);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo35a(C0016e eVar, C0012c.C0013a aVar, Object obj) {
            try {
                switch (this.f33a) {
                    case 0:
                        this.f34b.invoke(obj, new Object[0]);
                        return;
                    case 1:
                        this.f34b.invoke(obj, new Object[]{eVar});
                        return;
                    case 2:
                        this.f34b.invoke(obj, new Object[]{eVar, aVar});
                        return;
                    default:
                        return;
                }
            } catch (InvocationTargetException e) {
                throw new RuntimeException("Failed to call observer method", e.getCause());
            } catch (IllegalAccessException e2) {
                throw new RuntimeException(e2);
            }
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            C0010b bVar = (C0010b) obj;
            if (this.f33a != bVar.f33a || !this.f34b.getName().equals(bVar.f34b.getName())) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return (31 * this.f33a) + this.f34b.getName().hashCode();
        }
    }
}
