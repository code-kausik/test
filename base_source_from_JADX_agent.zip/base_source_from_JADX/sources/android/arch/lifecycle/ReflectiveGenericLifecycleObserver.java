package android.arch.lifecycle;

import android.arch.lifecycle.C0008a;
import android.arch.lifecycle.C0012c;

class ReflectiveGenericLifecycleObserver implements GenericLifecycleObserver {

    /* renamed from: a */
    private final Object f25a;

    /* renamed from: b */
    private final C0008a.C0009a f26b = C0008a.f28a.mo33b(this.f25a.getClass());

    ReflectiveGenericLifecycleObserver(Object obj) {
        this.f25a = obj;
    }

    /* renamed from: a */
    public void mo13a(C0016e eVar, C0012c.C0013a aVar) {
        this.f26b.mo34a(eVar, aVar, this.f25a);
    }
}
