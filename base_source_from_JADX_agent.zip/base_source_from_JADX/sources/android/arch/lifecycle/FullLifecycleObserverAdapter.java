package android.arch.lifecycle;

import android.arch.lifecycle.C0012c;

class FullLifecycleObserverAdapter implements GenericLifecycleObserver {

    /* renamed from: a */
    private final FullLifecycleObserver f6a;

    FullLifecycleObserverAdapter(FullLifecycleObserver fullLifecycleObserver) {
        this.f6a = fullLifecycleObserver;
    }

    /* renamed from: a */
    public void mo13a(C0016e eVar, C0012c.C0013a aVar) {
        switch (aVar) {
            case ON_CREATE:
                this.f6a.mo14a(eVar);
                return;
            case ON_START:
                this.f6a.mo15b(eVar);
                return;
            case ON_RESUME:
                this.f6a.mo16c(eVar);
                return;
            case ON_PAUSE:
                this.f6a.mo17d(eVar);
                return;
            case ON_STOP:
                this.f6a.mo18e(eVar);
                return;
            case ON_DESTROY:
                this.f6a.mo19f(eVar);
                return;
            case ON_ANY:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
            default:
                return;
        }
    }
}
