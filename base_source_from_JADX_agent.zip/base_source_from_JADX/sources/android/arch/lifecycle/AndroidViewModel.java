package android.arch.lifecycle;

public class AndroidViewModel extends C0028n {
}
