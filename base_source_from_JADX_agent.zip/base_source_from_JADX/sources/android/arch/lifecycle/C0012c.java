package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.c */
public abstract class C0012c {

    /* renamed from: android.arch.lifecycle.c$a */
    public enum C0013a {
        ON_CREATE,
        ON_START,
        ON_RESUME,
        ON_PAUSE,
        ON_STOP,
        ON_DESTROY,
        ON_ANY
    }

    /* renamed from: a */
    public abstract C0014b mo39a();

    /* renamed from: a */
    public abstract void mo40a(C0015d dVar);

    /* renamed from: b */
    public abstract void mo41b(C0015d dVar);

    /* renamed from: android.arch.lifecycle.c$b */
    public enum C0014b {
        DESTROYED,
        INITIALIZED,
        CREATED,
        STARTED,
        RESUMED;

        /* renamed from: a */
        public boolean mo42a(C0014b bVar) {
            return compareTo(bVar) >= 0;
        }
    }
}
