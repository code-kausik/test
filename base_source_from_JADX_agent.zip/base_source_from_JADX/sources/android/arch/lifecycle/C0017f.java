package android.arch.lifecycle;

import android.arch.lifecycle.C0012c;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/* renamed from: android.arch.lifecycle.f */
public class C0017f extends C0012c {

    /* renamed from: a */
    private C0280d<C0015d, C0019a> f41a = new C0280d<>();

    /* renamed from: b */
    private C0012c.C0014b f42b;

    /* renamed from: c */
    private final WeakReference<C0016e> f43c;

    /* renamed from: d */
    private int f44d = 0;

    /* renamed from: e */
    private boolean f45e = false;

    /* renamed from: f */
    private boolean f46f = false;

    /* renamed from: g */
    private ArrayList<C0012c.C0014b> f47g = new ArrayList<>();

    public C0017f(C0016e eVar) {
        this.f43c = new WeakReference<>(eVar);
        this.f42b = C0012c.C0014b.INITIALIZED;
    }

    /* renamed from: a */
    public void mo45a(C0012c.C0014b bVar) {
        m71b(bVar);
    }

    /* renamed from: a */
    public void mo44a(C0012c.C0013a aVar) {
        m71b(m70b(aVar));
    }

    /* renamed from: b */
    private void m71b(C0012c.C0014b bVar) {
        if (this.f42b != bVar) {
            this.f42b = bVar;
            if (this.f45e || this.f44d != 0) {
                this.f46f = true;
                return;
            }
            this.f45e = true;
            m78d();
            this.f45e = false;
        }
    }

    /* renamed from: b */
    private boolean m73b() {
        if (this.f41a.mo3409a() == 0) {
            return true;
        }
        C0012c.C0014b bVar = this.f41a.mo3413d().getValue().f50a;
        C0012c.C0014b bVar2 = this.f41a.mo3414e().getValue().f50a;
        if (bVar == bVar2 && this.f42b == bVar2) {
            return true;
        }
        return false;
    }

    /* renamed from: c */
    private C0012c.C0014b m74c(C0015d dVar) {
        Map.Entry<C0015d, C0019a> d = this.f41a.mo3329d(dVar);
        C0012c.C0014b bVar = null;
        C0012c.C0014b bVar2 = d != null ? d.getValue().f50a : null;
        if (!this.f47g.isEmpty()) {
            bVar = this.f47g.get(this.f47g.size() - 1);
        }
        return m68a(m68a(this.f42b, bVar2), bVar);
    }

    /* renamed from: a */
    public void mo40a(C0015d dVar) {
        C0016e eVar;
        C0019a aVar = new C0019a(dVar, this.f42b == C0012c.C0014b.DESTROYED ? C0012c.C0014b.DESTROYED : C0012c.C0014b.INITIALIZED);
        if (this.f41a.mo3326a(dVar, aVar) == null && (eVar = (C0016e) this.f43c.get()) != null) {
            boolean z = this.f44d != 0 || this.f45e;
            C0012c.C0014b c = m74c(dVar);
            this.f44d++;
            while (aVar.f50a.compareTo(c) < 0 && this.f41a.mo3328c(dVar)) {
                m76c(aVar.f50a);
                aVar.mo46a(eVar, m79e(aVar.f50a));
                m75c();
                c = m74c(dVar);
            }
            if (!z) {
                m78d();
            }
            this.f44d--;
        }
    }

    /* renamed from: c */
    private void m75c() {
        this.f47g.remove(this.f47g.size() - 1);
    }

    /* renamed from: c */
    private void m76c(C0012c.C0014b bVar) {
        this.f47g.add(bVar);
    }

    /* renamed from: b */
    public void mo41b(C0015d dVar) {
        this.f41a.mo3327b(dVar);
    }

    /* renamed from: a */
    public C0012c.C0014b mo39a() {
        return this.f42b;
    }

    /* renamed from: b */
    static C0012c.C0014b m70b(C0012c.C0013a aVar) {
        switch (aVar) {
            case ON_CREATE:
            case ON_STOP:
                return C0012c.C0014b.CREATED;
            case ON_START:
            case ON_PAUSE:
                return C0012c.C0014b.STARTED;
            case ON_RESUME:
                return C0012c.C0014b.RESUMED;
            case ON_DESTROY:
                return C0012c.C0014b.DESTROYED;
            default:
                throw new IllegalArgumentException("Unexpected event value " + aVar);
        }
    }

    /* renamed from: d */
    private static C0012c.C0013a m77d(C0012c.C0014b bVar) {
        switch (bVar) {
            case INITIALIZED:
                throw new IllegalArgumentException();
            case CREATED:
                return C0012c.C0013a.ON_DESTROY;
            case STARTED:
                return C0012c.C0013a.ON_STOP;
            case RESUMED:
                return C0012c.C0013a.ON_PAUSE;
            case DESTROYED:
                throw new IllegalArgumentException();
            default:
                throw new IllegalArgumentException("Unexpected state value " + bVar);
        }
    }

    /* renamed from: e */
    private static C0012c.C0013a m79e(C0012c.C0014b bVar) {
        switch (bVar) {
            case INITIALIZED:
            case DESTROYED:
                return C0012c.C0013a.ON_CREATE;
            case CREATED:
                return C0012c.C0013a.ON_START;
            case STARTED:
                return C0012c.C0013a.ON_RESUME;
            case RESUMED:
                throw new IllegalArgumentException();
            default:
                throw new IllegalArgumentException("Unexpected state value " + bVar);
        }
    }

    /* renamed from: a */
    private void m69a(C0016e eVar) {
        C0293e<K, V>.C0280d c = this.f41a.mo3412c();
        while (c.hasNext() && !this.f46f) {
            Map.Entry entry = (Map.Entry) c.next();
            C0019a aVar = (C0019a) entry.getValue();
            while (aVar.f50a.compareTo(this.f42b) < 0 && !this.f46f && this.f41a.mo3328c(entry.getKey())) {
                m76c(aVar.f50a);
                aVar.mo46a(eVar, m79e(aVar.f50a));
                m75c();
            }
        }
    }

    /* renamed from: b */
    private void m72b(C0016e eVar) {
        Iterator<Map.Entry<C0015d, C0019a>> b = this.f41a.mo3411b();
        while (b.hasNext() && !this.f46f) {
            Map.Entry next = b.next();
            C0019a aVar = (C0019a) next.getValue();
            while (aVar.f50a.compareTo(this.f42b) > 0 && !this.f46f && this.f41a.mo3328c(next.getKey())) {
                C0012c.C0013a d = m77d(aVar.f50a);
                m76c(m70b(d));
                aVar.mo46a(eVar, d);
                m75c();
            }
        }
    }

    /* renamed from: d */
    private void m78d() {
        C0016e eVar = (C0016e) this.f43c.get();
        if (eVar == null) {
            Log.w("LifecycleRegistry", "LifecycleOwner is garbage collected, you shouldn't try dispatch new events from it.");
            return;
        }
        while (!m73b()) {
            this.f46f = false;
            if (this.f42b.compareTo(this.f41a.mo3413d().getValue().f50a) < 0) {
                m72b(eVar);
            }
            Map.Entry<C0015d, C0019a> e = this.f41a.mo3414e();
            if (!this.f46f && e != null && this.f42b.compareTo(e.getValue().f50a) > 0) {
                m69a(eVar);
            }
        }
        this.f46f = false;
    }

    /* renamed from: a */
    static C0012c.C0014b m68a(C0012c.C0014b bVar, C0012c.C0014b bVar2) {
        return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
    }

    /* renamed from: android.arch.lifecycle.f$a */
    static class C0019a {

        /* renamed from: a */
        C0012c.C0014b f50a;

        /* renamed from: b */
        GenericLifecycleObserver f51b;

        C0019a(C0015d dVar, C0012c.C0014b bVar) {
            this.f51b = C0021h.m87a((Object) dVar);
            this.f50a = bVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo46a(C0016e eVar, C0012c.C0013a aVar) {
            C0012c.C0014b b = C0017f.m70b(aVar);
            this.f50a = C0017f.m68a(this.f50a, b);
            this.f51b.mo13a(eVar, aVar);
            this.f50a = b;
        }
    }
}
