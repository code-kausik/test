package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.o */
public class C0029o {

    /* renamed from: a */
    private final C0030a f56a;

    /* renamed from: b */
    private final C0031p f57b;

    /* renamed from: android.arch.lifecycle.o$a */
    public interface C0030a {
        /* renamed from: a */
        <T extends C0028n> T mo62a(Class<T> cls);
    }

    public C0029o(C0031p pVar, C0030a aVar) {
        this.f56a = aVar;
        this.f57b = pVar;
    }

    /* renamed from: a */
    public <T extends C0028n> T mo60a(Class<T> cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        return mo61a("android.arch.lifecycle.ViewModelProvider.DefaultKey:" + canonicalName, cls);
    }

    /* renamed from: a */
    public <T extends C0028n> T mo61a(String str, Class<T> cls) {
        T a = this.f57b.mo63a(str);
        if (cls.isInstance(a)) {
            return a;
        }
        T a2 = this.f56a.mo62a(cls);
        this.f57b.mo65a(str, a2);
        return a2;
    }
}
