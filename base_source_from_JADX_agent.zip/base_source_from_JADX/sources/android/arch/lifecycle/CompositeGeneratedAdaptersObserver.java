package android.arch.lifecycle;

import android.arch.lifecycle.C0012c;

public class CompositeGeneratedAdaptersObserver implements GenericLifecycleObserver {

    /* renamed from: a */
    private final C0011b[] f5a;

    CompositeGeneratedAdaptersObserver(C0011b[] bVarArr) {
        this.f5a = bVarArr;
    }

    /* renamed from: a */
    public void mo13a(C0016e eVar, C0012c.C0013a aVar) {
        C0022i iVar = new C0022i();
        for (C0011b a : this.f5a) {
            a.mo38a(eVar, aVar, false, iVar);
        }
        for (C0011b a2 : this.f5a) {
            a2.mo38a(eVar, aVar, true, iVar);
        }
    }
}
