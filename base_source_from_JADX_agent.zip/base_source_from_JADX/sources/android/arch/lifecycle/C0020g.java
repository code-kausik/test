package android.arch.lifecycle;

@Deprecated
/* renamed from: android.arch.lifecycle.g */
public interface C0020g extends C0016e {
    /* renamed from: a */
    C0017f mo47a();
}
