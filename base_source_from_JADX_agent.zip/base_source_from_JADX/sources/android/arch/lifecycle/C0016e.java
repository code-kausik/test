package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.e */
public interface C0016e {
    C0012c getLifecycle();
}
