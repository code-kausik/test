package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.k */
public interface C0024k<T> {
    /* renamed from: a */
    void mo48a(T t);
}
