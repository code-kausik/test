package android.arch.lifecycle;

import java.util.HashMap;

/* renamed from: android.arch.lifecycle.p */
public class C0031p {

    /* renamed from: a */
    private final HashMap<String, C0028n> f58a = new HashMap<>();

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public final void mo65a(String str, C0028n nVar) {
        C0028n put = this.f58a.put(str, nVar);
        if (put != null) {
            put.mo59a();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public final C0028n mo63a(String str) {
        return this.f58a.get(str);
    }

    /* renamed from: a */
    public final void mo64a() {
        for (C0028n a : this.f58a.values()) {
            a.mo59a();
        }
        this.f58a.clear();
    }
}
