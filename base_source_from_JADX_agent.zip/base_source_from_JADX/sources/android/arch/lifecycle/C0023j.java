package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.j */
public class C0023j<T> extends LiveData<T> {
    /* renamed from: a */
    public void mo23a(T t) {
        super.mo23a(t);
    }
}
