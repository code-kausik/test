package android.arch.lifecycle;

import android.arch.lifecycle.C0012c;

public interface GenericLifecycleObserver extends C0015d {
    /* renamed from: a */
    void mo13a(C0016e eVar, C0012c.C0013a aVar);
}
