package android.arch.lifecycle;

interface FullLifecycleObserver extends C0015d {
    /* renamed from: a */
    void mo14a(C0016e eVar);

    /* renamed from: b */
    void mo15b(C0016e eVar);

    /* renamed from: c */
    void mo16c(C0016e eVar);

    /* renamed from: d */
    void mo17d(C0016e eVar);

    /* renamed from: e */
    void mo18e(C0016e eVar);

    /* renamed from: f */
    void mo19f(C0016e eVar);
}
