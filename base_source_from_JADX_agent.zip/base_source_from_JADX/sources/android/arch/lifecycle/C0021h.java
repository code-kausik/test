package android.arch.lifecycle;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.cordova.BuildConfig;

/* renamed from: android.arch.lifecycle.h */
public class C0021h {

    /* renamed from: a */
    private static Map<Class, Integer> f52a = new HashMap();

    /* renamed from: b */
    private static Map<Class, List<Constructor<? extends C0011b>>> f53b = new HashMap();

    /* renamed from: a */
    static GenericLifecycleObserver m87a(Object obj) {
        if (obj instanceof FullLifecycleObserver) {
            return new FullLifecycleObserverAdapter((FullLifecycleObserver) obj);
        }
        if (obj instanceof GenericLifecycleObserver) {
            return (GenericLifecycleObserver) obj;
        }
        Class<?> cls = obj.getClass();
        if (m91b(cls) != 2) {
            return new ReflectiveGenericLifecycleObserver(obj);
        }
        List list = f53b.get(cls);
        if (list.size() == 1) {
            return new SingleGeneratedAdapterObserver(m88a((Constructor) list.get(0), obj));
        }
        C0011b[] bVarArr = new C0011b[list.size()];
        for (int i = 0; i < list.size(); i++) {
            bVarArr[i] = m88a((Constructor) list.get(i), obj);
        }
        return new CompositeGeneratedAdaptersObserver(bVarArr);
    }

    /* renamed from: a */
    private static C0011b m88a(Constructor<? extends C0011b> constructor, Object obj) {
        try {
            return (C0011b) constructor.newInstance(new Object[]{obj});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e2) {
            throw new RuntimeException(e2);
        } catch (InvocationTargetException e3) {
            throw new RuntimeException(e3);
        }
    }

    /* renamed from: a */
    private static Constructor<? extends C0011b> m90a(Class<?> cls) {
        try {
            Package packageR = cls.getPackage();
            String canonicalName = cls.getCanonicalName();
            String name = packageR != null ? packageR.getName() : BuildConfig.FLAVOR;
            if (!name.isEmpty()) {
                canonicalName = canonicalName.substring(name.length() + 1);
            }
            String a = m89a(canonicalName);
            if (!name.isEmpty()) {
                a = name + "." + a;
            }
            Constructor<?> declaredConstructor = Class.forName(a).getDeclaredConstructor(new Class[]{cls});
            if (!declaredConstructor.isAccessible()) {
                declaredConstructor.setAccessible(true);
            }
            return declaredConstructor;
        } catch (ClassNotFoundException unused) {
            return null;
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    /* renamed from: b */
    private static int m91b(Class<?> cls) {
        if (f52a.containsKey(cls)) {
            return f52a.get(cls).intValue();
        }
        int c = m92c(cls);
        f52a.put(cls, Integer.valueOf(c));
        return c;
    }

    /* renamed from: c */
    private static int m92c(Class<?> cls) {
        if (cls.getCanonicalName() == null) {
            return 1;
        }
        Constructor<? extends C0011b> a = m90a(cls);
        if (a != null) {
            f53b.put(cls, Collections.singletonList(a));
            return 2;
        } else if (C0008a.f28a.mo32a(cls)) {
            return 1;
        } else {
            Class<? super Object> superclass = cls.getSuperclass();
            ArrayList arrayList = null;
            if (m93d(superclass)) {
                if (m91b(superclass) == 1) {
                    return 1;
                }
                arrayList = new ArrayList(f53b.get(superclass));
            }
            for (Class cls2 : cls.getInterfaces()) {
                if (m93d(cls2)) {
                    if (m91b(cls2) == 1) {
                        return 1;
                    }
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.addAll(f53b.get(cls2));
                }
            }
            if (arrayList == null) {
                return 1;
            }
            f53b.put(cls, arrayList);
            return 2;
        }
    }

    /* renamed from: d */
    private static boolean m93d(Class<?> cls) {
        return cls != null && C0015d.class.isAssignableFrom(cls);
    }

    /* renamed from: a */
    public static String m89a(String str) {
        return str.replace(".", "_") + "_LifecycleAdapter";
    }
}
