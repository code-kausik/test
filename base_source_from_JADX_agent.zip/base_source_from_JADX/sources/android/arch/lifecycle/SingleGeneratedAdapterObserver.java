package android.arch.lifecycle;

import android.arch.lifecycle.C0012c;

public class SingleGeneratedAdapterObserver implements GenericLifecycleObserver {

    /* renamed from: a */
    private final C0011b f27a;

    SingleGeneratedAdapterObserver(C0011b bVar) {
        this.f27a = bVar;
    }

    /* renamed from: a */
    public void mo13a(C0016e eVar, C0012c.C0013a aVar) {
        this.f27a.mo38a(eVar, aVar, false, (C0022i) null);
        this.f27a.mo38a(eVar, aVar, true, (C0022i) null);
    }
}
