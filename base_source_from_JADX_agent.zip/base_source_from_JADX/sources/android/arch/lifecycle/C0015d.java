package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.d */
public interface C0015d {
}
