package android.arch.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.arch.lifecycle.C0012c;
import android.os.Bundle;

/* renamed from: android.arch.lifecycle.m */
public class C0026m extends Fragment {

    /* renamed from: a */
    private C0027a f55a;

    /* renamed from: android.arch.lifecycle.m$a */
    interface C0027a {
        /* renamed from: a */
        void mo56a();

        /* renamed from: b */
        void mo57b();

        /* renamed from: c */
        void mo58c();
    }

    /* renamed from: a */
    public static void m97a(Activity activity) {
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("android.arch.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new C0026m(), "android.arch.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }

    /* renamed from: a */
    private void m99a(C0027a aVar) {
        if (aVar != null) {
            aVar.mo56a();
        }
    }

    /* renamed from: b */
    private void m100b(C0027a aVar) {
        if (aVar != null) {
            aVar.mo57b();
        }
    }

    /* renamed from: c */
    private void m101c(C0027a aVar) {
        if (aVar != null) {
            aVar.mo58c();
        }
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        m99a(this.f55a);
        m98a(C0012c.C0013a.ON_CREATE);
    }

    public void onStart() {
        super.onStart();
        m100b(this.f55a);
        m98a(C0012c.C0013a.ON_START);
    }

    public void onResume() {
        super.onResume();
        m101c(this.f55a);
        m98a(C0012c.C0013a.ON_RESUME);
    }

    public void onPause() {
        super.onPause();
        m98a(C0012c.C0013a.ON_PAUSE);
    }

    public void onStop() {
        super.onStop();
        m98a(C0012c.C0013a.ON_STOP);
    }

    public void onDestroy() {
        super.onDestroy();
        m98a(C0012c.C0013a.ON_DESTROY);
        this.f55a = null;
    }

    /* renamed from: a */
    private void m98a(C0012c.C0013a aVar) {
        Activity activity = getActivity();
        if (activity instanceof C0020g) {
            ((C0020g) activity).mo47a().mo44a(aVar);
        } else if (activity instanceof C0016e) {
            C0012c lifecycle = ((C0016e) activity).getLifecycle();
            if (lifecycle instanceof C0017f) {
                ((C0017f) lifecycle).mo44a(aVar);
            }
        }
    }
}
