package android.arch.lifecycle;

import android.arch.lifecycle.C0012c;

/* renamed from: android.arch.lifecycle.b */
public interface C0011b {
    /* renamed from: a */
    void mo38a(C0016e eVar, C0012c.C0013a aVar, boolean z, C0022i iVar);
}
