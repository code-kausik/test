package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.q */
public interface C0032q {
    C0031p getViewModelStore();
}
