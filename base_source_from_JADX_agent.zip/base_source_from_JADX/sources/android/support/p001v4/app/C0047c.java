package android.support.p001v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.p001v4.app.C0045b;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

/* renamed from: android.support.v4.app.c */
final class C0047c implements Parcelable {
    public static final Parcelable.Creator<C0047c> CREATOR = new Parcelable.Creator<C0047c>() {
        /* renamed from: a */
        public C0047c createFromParcel(Parcel parcel) {
            return new C0047c(parcel);
        }

        /* renamed from: a */
        public C0047c[] newArray(int i) {
            return new C0047c[i];
        }
    };

    /* renamed from: a */
    final int[] f109a;

    /* renamed from: b */
    final int f110b;

    /* renamed from: c */
    final int f111c;

    /* renamed from: d */
    final String f112d;

    /* renamed from: e */
    final int f113e;

    /* renamed from: f */
    final int f114f;

    /* renamed from: g */
    final CharSequence f115g;

    /* renamed from: h */
    final int f116h;

    /* renamed from: i */
    final CharSequence f117i;

    /* renamed from: j */
    final ArrayList<String> f118j;

    /* renamed from: k */
    final ArrayList<String> f119k;

    /* renamed from: l */
    final boolean f120l;

    public int describeContents() {
        return 0;
    }

    public C0047c(C0045b bVar) {
        int size = bVar.f83b.size();
        this.f109a = new int[(size * 6)];
        if (!bVar.f90i) {
            throw new IllegalStateException("Not on back stack");
        }
        int i = 0;
        int i2 = 0;
        while (i < size) {
            C0045b.C0046a aVar = bVar.f83b.get(i);
            int i3 = i2 + 1;
            this.f109a[i2] = aVar.f103a;
            int i4 = i3 + 1;
            this.f109a[i3] = aVar.f104b != null ? aVar.f104b.mIndex : -1;
            int i5 = i4 + 1;
            this.f109a[i4] = aVar.f105c;
            int i6 = i5 + 1;
            this.f109a[i5] = aVar.f106d;
            int i7 = i6 + 1;
            this.f109a[i6] = aVar.f107e;
            this.f109a[i7] = aVar.f108f;
            i++;
            i2 = i7 + 1;
        }
        this.f110b = bVar.f88g;
        this.f111c = bVar.f89h;
        this.f112d = bVar.f92k;
        this.f113e = bVar.f94m;
        this.f114f = bVar.f95n;
        this.f115g = bVar.f96o;
        this.f116h = bVar.f97p;
        this.f117i = bVar.f98q;
        this.f118j = bVar.f99r;
        this.f119k = bVar.f100s;
        this.f120l = bVar.f101t;
    }

    public C0047c(Parcel parcel) {
        this.f109a = parcel.createIntArray();
        this.f110b = parcel.readInt();
        this.f111c = parcel.readInt();
        this.f112d = parcel.readString();
        this.f113e = parcel.readInt();
        this.f114f = parcel.readInt();
        this.f115g = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f116h = parcel.readInt();
        this.f117i = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f118j = parcel.createStringArrayList();
        this.f119k = parcel.createStringArrayList();
        this.f120l = parcel.readInt() != 0;
    }

    /* renamed from: a */
    public C0045b mo120a(C0070k kVar) {
        C0045b bVar = new C0045b(kVar);
        int i = 0;
        int i2 = 0;
        while (i < this.f109a.length) {
            C0045b.C0046a aVar = new C0045b.C0046a();
            int i3 = i + 1;
            aVar.f103a = this.f109a[i];
            if (C0070k.f172a) {
                Log.v("FragmentManager", "Instantiate " + bVar + " op #" + i2 + " base fragment #" + this.f109a[i3]);
            }
            int i4 = i3 + 1;
            int i5 = this.f109a[i3];
            if (i5 >= 0) {
                aVar.f104b = kVar.f184f.get(i5);
            } else {
                aVar.f104b = null;
            }
            int i6 = i4 + 1;
            aVar.f105c = this.f109a[i4];
            int i7 = i6 + 1;
            aVar.f106d = this.f109a[i6];
            int i8 = i7 + 1;
            aVar.f107e = this.f109a[i7];
            aVar.f108f = this.f109a[i8];
            bVar.f84c = aVar.f105c;
            bVar.f85d = aVar.f106d;
            bVar.f86e = aVar.f107e;
            bVar.f87f = aVar.f108f;
            bVar.mo106a(aVar);
            i2++;
            i = i8 + 1;
        }
        bVar.f88g = this.f110b;
        bVar.f89h = this.f111c;
        bVar.f92k = this.f112d;
        bVar.f94m = this.f113e;
        bVar.f90i = true;
        bVar.f95n = this.f114f;
        bVar.f96o = this.f115g;
        bVar.f97p = this.f116h;
        bVar.f98q = this.f117i;
        bVar.f99r = this.f118j;
        bVar.f100s = this.f119k;
        bVar.f101t = this.f120l;
        bVar.mo105a(1);
        return bVar;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.f109a);
        parcel.writeInt(this.f110b);
        parcel.writeInt(this.f111c);
        parcel.writeString(this.f112d);
        parcel.writeInt(this.f113e);
        parcel.writeInt(this.f114f);
        TextUtils.writeToParcel(this.f115g, parcel, 0);
        parcel.writeInt(this.f116h);
        TextUtils.writeToParcel(this.f117i, parcel, 0);
        parcel.writeStringList(this.f118j);
        parcel.writeStringList(this.f119k);
        parcel.writeInt(this.f120l ? 1 : 0);
    }
}
