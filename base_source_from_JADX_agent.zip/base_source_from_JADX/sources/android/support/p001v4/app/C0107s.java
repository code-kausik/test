package android.support.p001v4.app;

import android.arch.lifecycle.C0016e;
import android.arch.lifecycle.C0032q;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: android.support.v4.app.s */
public abstract class C0107s {

    /* renamed from: android.support.v4.app.s$a */
    public interface C0108a<D> {
        /* renamed from: a */
        void mo553a(C0308i<D> iVar);

        /* renamed from: a */
        void mo554a(C0308i<D> iVar, D d);
    }

    /* renamed from: a */
    public abstract void mo73a();

    @Deprecated
    /* renamed from: a */
    public abstract void mo74a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    /* renamed from: a */
    public static <T extends C0016e & C0032q> C0107s m476a(T t) {
        return new LoaderManagerImpl(t, ((C0032q) t).getViewModelStore());
    }
}
