package android.support.p001v4.app;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;

/* renamed from: android.support.v4.app.ac */
public final class C0044ac implements Iterable<Intent> {

    /* renamed from: a */
    private final ArrayList<Intent> f80a = new ArrayList<>();

    /* renamed from: b */
    private final Context f81b;

    private C0044ac(Context context) {
        this.f81b = context;
    }

    /* renamed from: a */
    public static C0044ac m142a(Context context) {
        return new C0044ac(context);
    }

    /* renamed from: a */
    public C0044ac mo99a(Intent intent) {
        this.f80a.add(intent);
        return this;
    }

    @Deprecated
    public Iterator<Intent> iterator() {
        return this.f80a.iterator();
    }

    /* renamed from: a */
    public PendingIntent mo97a(int i, int i2) {
        return mo98a(i, i2, (Bundle) null);
    }

    /* renamed from: a */
    public PendingIntent mo98a(int i, int i2, Bundle bundle) {
        if (this.f80a.isEmpty()) {
            throw new IllegalStateException("No intents added to TaskStackBuilder; cannot getPendingIntent");
        }
        Intent[] intentArr = (Intent[]) this.f80a.toArray(new Intent[this.f80a.size()]);
        intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
        if (Build.VERSION.SDK_INT >= 16) {
            return PendingIntent.getActivities(this.f81b, i, intentArr, i2, bundle);
        }
        return PendingIntent.getActivities(this.f81b, i, intentArr, i2);
    }
}
