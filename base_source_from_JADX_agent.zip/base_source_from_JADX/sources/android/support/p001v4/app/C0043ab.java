package android.support.p001v4.app;

import android.app.Activity;
import android.arch.lifecycle.C0012c;
import android.arch.lifecycle.C0016e;
import android.arch.lifecycle.C0017f;
import android.arch.lifecycle.C0026m;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import p000.C0466v;

/* renamed from: android.support.v4.app.ab */
public class C0043ab extends Activity implements C0016e, C0466v.C0467a {

    /* renamed from: a */
    private C0464t<Class<? extends Object>, Object> f78a = new C0464t<>();

    /* renamed from: b */
    private C0017f f79b = new C0017f(this);

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        C0026m.m97a((Activity) this);
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        this.f79b.mo45a(C0012c.C0014b.CREATED);
        super.onSaveInstanceState(bundle);
    }

    public C0012c getLifecycle() {
        return this.f79b;
    }

    /* renamed from: a */
    public boolean mo92a(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        View decorView = getWindow().getDecorView();
        if (decorView == null || !C0466v.m1511a(decorView, keyEvent)) {
            return super.dispatchKeyShortcutEvent(keyEvent);
        }
        return true;
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        View decorView = getWindow().getDecorView();
        if (decorView == null || !C0466v.m1511a(decorView, keyEvent)) {
            return C0466v.m1512a(this, decorView, this, keyEvent);
        }
        return true;
    }
}
