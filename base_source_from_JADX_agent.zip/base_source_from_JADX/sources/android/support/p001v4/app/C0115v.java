package android.support.p001v4.app;

import android.app.Notification;
import android.app.RemoteInput;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.p001v4.app.C0110u;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* renamed from: android.support.v4.app.v */
class C0115v implements C0109t {

    /* renamed from: a */
    private final Notification.Builder f372a;

    /* renamed from: b */
    private final C0110u.C0113c f373b;

    /* renamed from: c */
    private RemoteViews f374c;

    /* renamed from: d */
    private RemoteViews f375d;

    /* renamed from: e */
    private final List<Bundle> f376e = new ArrayList();

    /* renamed from: f */
    private final Bundle f377f = new Bundle();

    /* renamed from: g */
    private int f378g;

    /* renamed from: h */
    private RemoteViews f379h;

    C0115v(C0110u.C0113c cVar) {
        this.f373b = cVar;
        if (Build.VERSION.SDK_INT >= 26) {
            this.f372a = new Notification.Builder(cVar.f342a, cVar.f335I);
        } else {
            this.f372a = new Notification.Builder(cVar.f342a);
        }
        Notification notification = cVar.f340N;
        this.f372a.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, cVar.f349h).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(cVar.f345d).setContentText(cVar.f346e).setContentInfo(cVar.f351j).setContentIntent(cVar.f347f).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(cVar.f348g, (notification.flags & 128) != 0).setLargeIcon(cVar.f350i).setNumber(cVar.f352k).setProgress(cVar.f359r, cVar.f360s, cVar.f361t);
        if (Build.VERSION.SDK_INT < 21) {
            this.f372a.setSound(notification.sound, notification.audioStreamType);
        }
        if (Build.VERSION.SDK_INT >= 16) {
            this.f372a.setSubText(cVar.f357p).setUsesChronometer(cVar.f355n).setPriority(cVar.f353l);
            Iterator<C0110u.C0111a> it = cVar.f343b.iterator();
            while (it.hasNext()) {
                m523a(it.next());
            }
            if (cVar.f328B != null) {
                this.f377f.putAll(cVar.f328B);
            }
            if (Build.VERSION.SDK_INT < 20) {
                if (cVar.f365x) {
                    this.f377f.putBoolean("android.support.localOnly", true);
                }
                if (cVar.f362u != null) {
                    this.f377f.putString("android.support.groupKey", cVar.f362u);
                    if (cVar.f363v) {
                        this.f377f.putBoolean("android.support.isGroupSummary", true);
                    } else {
                        this.f377f.putBoolean("android.support.useSideChannel", true);
                    }
                }
                if (cVar.f364w != null) {
                    this.f377f.putString("android.support.sortKey", cVar.f364w);
                }
            }
            this.f374c = cVar.f332F;
            this.f375d = cVar.f333G;
        }
        if (Build.VERSION.SDK_INT >= 19) {
            this.f372a.setShowWhen(cVar.f354m);
            if (Build.VERSION.SDK_INT < 21 && cVar.f341O != null && !cVar.f341O.isEmpty()) {
                this.f377f.putStringArray("android.people", (String[]) cVar.f341O.toArray(new String[cVar.f341O.size()]));
            }
        }
        if (Build.VERSION.SDK_INT >= 20) {
            this.f372a.setLocalOnly(cVar.f365x).setGroup(cVar.f362u).setGroupSummary(cVar.f363v).setSortKey(cVar.f364w);
            this.f378g = cVar.f339M;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            this.f372a.setCategory(cVar.f327A).setColor(cVar.f329C).setVisibility(cVar.f330D).setPublicVersion(cVar.f331E).setSound(notification.sound, notification.audioAttributes);
            Iterator<String> it2 = cVar.f341O.iterator();
            while (it2.hasNext()) {
                this.f372a.addPerson(it2.next());
            }
            this.f379h = cVar.f334H;
            if (cVar.f344c.size() > 0) {
                Bundle bundle = cVar.mo567a().getBundle("android.car.EXTENSIONS");
                bundle = bundle == null ? new Bundle() : bundle;
                Bundle bundle2 = new Bundle();
                for (int i = 0; i < cVar.f344c.size(); i++) {
                    bundle2.putBundle(Integer.toString(i), C0116w.m529a(cVar.f344c.get(i)));
                }
                bundle.putBundle("invisible_actions", bundle2);
                cVar.mo567a().putBundle("android.car.EXTENSIONS", bundle);
                this.f377f.putBundle("android.car.EXTENSIONS", bundle);
            }
        }
        if (Build.VERSION.SDK_INT >= 24) {
            this.f372a.setExtras(cVar.f328B).setRemoteInputHistory(cVar.f358q);
            if (cVar.f332F != null) {
                this.f372a.setCustomContentView(cVar.f332F);
            }
            if (cVar.f333G != null) {
                this.f372a.setCustomBigContentView(cVar.f333G);
            }
            if (cVar.f334H != null) {
                this.f372a.setCustomHeadsUpContentView(cVar.f334H);
            }
        }
        if (Build.VERSION.SDK_INT >= 26) {
            this.f372a.setBadgeIconType(cVar.f336J).setShortcutId(cVar.f337K).setTimeoutAfter(cVar.f338L).setGroupAlertBehavior(cVar.f339M);
            if (cVar.f367z) {
                this.f372a.setColorized(cVar.f366y);
            }
            if (!TextUtils.isEmpty(cVar.f335I)) {
                this.f372a.setSound((Uri) null).setDefaults(0).setLights(0, 0, 0).setVibrate((long[]) null);
            }
        }
    }

    /* renamed from: a */
    public Notification.Builder mo555a() {
        return this.f372a;
    }

    /* renamed from: b */
    public Notification mo591b() {
        Bundle a;
        RemoteViews d;
        RemoteViews c;
        C0110u.C0114d dVar = this.f373b.f356o;
        if (dVar != null) {
            dVar.mo566a((C0109t) this);
        }
        RemoteViews b = dVar != null ? dVar.mo588b(this) : null;
        Notification c2 = mo592c();
        if (b != null) {
            c2.contentView = b;
        } else if (this.f373b.f332F != null) {
            c2.contentView = this.f373b.f332F;
        }
        if (!(Build.VERSION.SDK_INT < 16 || dVar == null || (c = dVar.mo589c(this)) == null)) {
            c2.bigContentView = c;
        }
        if (!(Build.VERSION.SDK_INT < 21 || dVar == null || (d = this.f373b.f356o.mo590d(this)) == null)) {
            c2.headsUpContentView = d;
        }
        if (!(Build.VERSION.SDK_INT < 16 || dVar == null || (a = C0110u.m482a(c2)) == null)) {
            dVar.mo586a(a);
        }
        return c2;
    }

    /* renamed from: a */
    private void m523a(C0110u.C0111a aVar) {
        Bundle bundle;
        if (Build.VERSION.SDK_INT >= 20) {
            Notification.Action.Builder builder = new Notification.Action.Builder(aVar.mo556a(), aVar.mo557b(), aVar.mo558c());
            if (aVar.mo561f() != null) {
                for (RemoteInput addRemoteInput : C0118y.m536a(aVar.mo561f())) {
                    builder.addRemoteInput(addRemoteInput);
                }
            }
            if (aVar.mo559d() != null) {
                bundle = new Bundle(aVar.mo559d());
            } else {
                bundle = new Bundle();
            }
            bundle.putBoolean("android.support.allowGeneratedReplies", aVar.mo560e());
            if (Build.VERSION.SDK_INT >= 24) {
                builder.setAllowGeneratedReplies(aVar.mo560e());
            }
            bundle.putInt("android.support.action.semanticAction", aVar.mo562g());
            if (Build.VERSION.SDK_INT >= 28) {
                builder.setSemanticAction(aVar.mo562g());
            }
            bundle.putBoolean("android.support.action.showsUserInterface", aVar.mo564i());
            builder.addExtras(bundle);
            this.f372a.addAction(builder.build());
        } else if (Build.VERSION.SDK_INT >= 16) {
            this.f376e.add(C0116w.m527a(this.f372a, aVar));
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public Notification mo592c() {
        if (Build.VERSION.SDK_INT >= 26) {
            return this.f372a.build();
        }
        if (Build.VERSION.SDK_INT >= 24) {
            Notification build = this.f372a.build();
            if (this.f378g != 0) {
                if (!(build.getGroup() == null || (build.flags & 512) == 0 || this.f378g != 2)) {
                    m522a(build);
                }
                if (build.getGroup() != null && (build.flags & 512) == 0 && this.f378g == 1) {
                    m522a(build);
                }
            }
            return build;
        } else if (Build.VERSION.SDK_INT >= 21) {
            this.f372a.setExtras(this.f377f);
            Notification build2 = this.f372a.build();
            if (this.f374c != null) {
                build2.contentView = this.f374c;
            }
            if (this.f375d != null) {
                build2.bigContentView = this.f375d;
            }
            if (this.f379h != null) {
                build2.headsUpContentView = this.f379h;
            }
            if (this.f378g != 0) {
                if (!(build2.getGroup() == null || (build2.flags & 512) == 0 || this.f378g != 2)) {
                    m522a(build2);
                }
                if (build2.getGroup() != null && (build2.flags & 512) == 0 && this.f378g == 1) {
                    m522a(build2);
                }
            }
            return build2;
        } else if (Build.VERSION.SDK_INT >= 20) {
            this.f372a.setExtras(this.f377f);
            Notification build3 = this.f372a.build();
            if (this.f374c != null) {
                build3.contentView = this.f374c;
            }
            if (this.f375d != null) {
                build3.bigContentView = this.f375d;
            }
            if (this.f378g != 0) {
                if (!(build3.getGroup() == null || (build3.flags & 512) == 0 || this.f378g != 2)) {
                    m522a(build3);
                }
                if (build3.getGroup() != null && (build3.flags & 512) == 0 && this.f378g == 1) {
                    m522a(build3);
                }
            }
            return build3;
        } else if (Build.VERSION.SDK_INT >= 19) {
            SparseArray<Bundle> a = C0116w.m531a(this.f376e);
            if (a != null) {
                this.f377f.putSparseParcelableArray("android.support.actionExtras", a);
            }
            this.f372a.setExtras(this.f377f);
            Notification build4 = this.f372a.build();
            if (this.f374c != null) {
                build4.contentView = this.f374c;
            }
            if (this.f375d != null) {
                build4.bigContentView = this.f375d;
            }
            return build4;
        } else if (Build.VERSION.SDK_INT < 16) {
            return this.f372a.getNotification();
        } else {
            Notification build5 = this.f372a.build();
            Bundle a2 = C0110u.m482a(build5);
            Bundle bundle = new Bundle(this.f377f);
            for (String str : this.f377f.keySet()) {
                if (a2.containsKey(str)) {
                    bundle.remove(str);
                }
            }
            a2.putAll(bundle);
            SparseArray<Bundle> a3 = C0116w.m531a(this.f376e);
            if (a3 != null) {
                C0110u.m482a(build5).putSparseParcelableArray("android.support.actionExtras", a3);
            }
            if (this.f374c != null) {
                build5.contentView = this.f374c;
            }
            if (this.f375d != null) {
                build5.bigContentView = this.f375d;
            }
            return build5;
        }
    }

    /* renamed from: a */
    private void m522a(Notification notification) {
        notification.sound = null;
        notification.vibrate = null;
        notification.defaults &= -2;
        notification.defaults &= -3;
    }
}
