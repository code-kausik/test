package android.support.p001v4.app;

import android.support.p001v4.app.C0051e;
import android.support.p001v4.app.C0070k;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

/* renamed from: android.support.v4.app.b */
final class C0045b extends C0091o implements C0070k.C0084h {

    /* renamed from: a */
    final C0070k f82a;

    /* renamed from: b */
    ArrayList<C0046a> f83b = new ArrayList<>();

    /* renamed from: c */
    int f84c;

    /* renamed from: d */
    int f85d;

    /* renamed from: e */
    int f86e;

    /* renamed from: f */
    int f87f;

    /* renamed from: g */
    int f88g;

    /* renamed from: h */
    int f89h;

    /* renamed from: i */
    boolean f90i;

    /* renamed from: j */
    boolean f91j = true;

    /* renamed from: k */
    String f92k;

    /* renamed from: l */
    boolean f93l;

    /* renamed from: m */
    int f94m = -1;

    /* renamed from: n */
    int f95n;

    /* renamed from: o */
    CharSequence f96o;

    /* renamed from: p */
    int f97p;

    /* renamed from: q */
    CharSequence f98q;

    /* renamed from: r */
    ArrayList<String> f99r;

    /* renamed from: s */
    ArrayList<String> f100s;

    /* renamed from: t */
    boolean f101t = false;

    /* renamed from: u */
    ArrayList<Runnable> f102u;

    /* renamed from: android.support.v4.app.b$a */
    static final class C0046a {

        /* renamed from: a */
        int f103a;

        /* renamed from: b */
        C0051e f104b;

        /* renamed from: c */
        int f105c;

        /* renamed from: d */
        int f106d;

        /* renamed from: e */
        int f107e;

        /* renamed from: f */
        int f108f;

        C0046a() {
        }

        C0046a(int i, C0051e eVar) {
            this.f103a = i;
            this.f104b = eVar;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f94m >= 0) {
            sb.append(" #");
            sb.append(this.f94m);
        }
        if (this.f92k != null) {
            sb.append(" ");
            sb.append(this.f92k);
        }
        sb.append("}");
        return sb.toString();
    }

    /* renamed from: a */
    public void mo108a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        mo109a(str, printWriter, true);
    }

    /* renamed from: a */
    public void mo109a(String str, PrintWriter printWriter, boolean z) {
        String str2;
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f92k);
            printWriter.print(" mIndex=");
            printWriter.print(this.f94m);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f93l);
            if (this.f88g != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f88g));
                printWriter.print(" mTransitionStyle=#");
                printWriter.println(Integer.toHexString(this.f89h));
            }
            if (!(this.f84c == 0 && this.f85d == 0)) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f84c));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f85d));
            }
            if (!(this.f86e == 0 && this.f87f == 0)) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f86e));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f87f));
            }
            if (!(this.f95n == 0 && this.f96o == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f95n));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f96o);
            }
            if (!(this.f97p == 0 && this.f98q == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f97p));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f98q);
            }
        }
        if (!this.f83b.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Operations:");
            str + "    ";
            int size = this.f83b.size();
            for (int i = 0; i < size; i++) {
                C0046a aVar = this.f83b.get(i);
                switch (aVar.f103a) {
                    case 0:
                        str2 = "NULL";
                        break;
                    case 1:
                        str2 = "ADD";
                        break;
                    case 2:
                        str2 = "REPLACE";
                        break;
                    case 3:
                        str2 = "REMOVE";
                        break;
                    case 4:
                        str2 = "HIDE";
                        break;
                    case 5:
                        str2 = "SHOW";
                        break;
                    case 6:
                        str2 = "DETACH";
                        break;
                    case 7:
                        str2 = "ATTACH";
                        break;
                    case 8:
                        str2 = "SET_PRIMARY_NAV";
                        break;
                    case 9:
                        str2 = "UNSET_PRIMARY_NAV";
                        break;
                    default:
                        str2 = "cmd=" + aVar.f103a;
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.print(str2);
                printWriter.print(" ");
                printWriter.println(aVar.f104b);
                if (z) {
                    if (!(aVar.f105c == 0 && aVar.f106d == 0)) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f105c));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f106d));
                    }
                    if (aVar.f107e != 0 || aVar.f108f != 0) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f107e));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f108f));
                    }
                }
            }
        }
    }

    public C0045b(C0070k kVar) {
        this.f82a = kVar;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo106a(C0046a aVar) {
        this.f83b.add(aVar);
        aVar.f105c = this.f84c;
        aVar.f106d = this.f85d;
        aVar.f107e = this.f86e;
        aVar.f108f = this.f87f;
    }

    /* renamed from: a */
    public C0091o mo103a(C0051e eVar, String str) {
        m146a(0, eVar, str, 1);
        return this;
    }

    /* renamed from: a */
    private void m146a(int i, C0051e eVar, String str, int i2) {
        Class<?> cls = eVar.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from" + " instance state.");
        }
        eVar.mFragmentManager = this.f82a;
        if (str != null) {
            if (eVar.mTag == null || str.equals(eVar.mTag)) {
                eVar.mTag = str;
            } else {
                throw new IllegalStateException("Can't change tag of fragment " + eVar + ": was " + eVar.mTag + " now " + str);
            }
        }
        if (i != 0) {
            if (i == -1) {
                throw new IllegalArgumentException("Can't add fragment " + eVar + " with tag " + str + " to container view with no id");
            } else if (eVar.mFragmentId == 0 || eVar.mFragmentId == i) {
                eVar.mFragmentId = i;
                eVar.mContainerId = i;
            } else {
                throw new IllegalStateException("Can't change container ID of fragment " + eVar + ": was " + eVar.mFragmentId + " now " + i);
            }
        }
        mo106a(new C0046a(i2, eVar));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo105a(int i) {
        if (this.f90i) {
            if (C0070k.f172a) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i);
            }
            int size = this.f83b.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0046a aVar = this.f83b.get(i2);
                if (aVar.f104b != null) {
                    aVar.f104b.mBackStackNesting += i;
                    if (C0070k.f172a) {
                        Log.v("FragmentManager", "Bump nesting of " + aVar.f104b + " to " + aVar.f104b.mBackStackNesting);
                    }
                }
            }
        }
    }

    /* renamed from: a */
    public void mo104a() {
        if (this.f102u != null) {
            int size = this.f102u.size();
            for (int i = 0; i < size; i++) {
                this.f102u.get(i).run();
            }
            this.f102u = null;
        }
    }

    /* renamed from: b */
    public int mo112b() {
        return mo101a(true);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public int mo101a(boolean z) {
        if (this.f93l) {
            throw new IllegalStateException("commit already called");
        }
        if (C0070k.f172a) {
            Log.v("FragmentManager", "Commit: " + this);
            PrintWriter printWriter = new PrintWriter(new C0456q("FragmentManager"));
            mo108a("  ", (FileDescriptor) null, printWriter, (String[]) null);
            printWriter.close();
        }
        this.f93l = true;
        if (this.f90i) {
            this.f94m = this.f82a.mo401a(this);
        } else {
            this.f94m = -1;
        }
        this.f82a.mo417a((C0070k.C0084h) this, z);
        return this.f94m;
    }

    /* renamed from: a */
    public boolean mo111a(ArrayList<C0045b> arrayList, ArrayList<Boolean> arrayList2) {
        if (C0070k.f172a) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(false);
        if (!this.f90i) {
            return true;
        }
        this.f82a.mo426b(this);
        return true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public boolean mo115b(int i) {
        int size = this.f83b.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0046a aVar = this.f83b.get(i2);
            int i3 = aVar.f104b != null ? aVar.f104b.mContainerId : 0;
            if (i3 != 0 && i3 == i) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public boolean mo110a(ArrayList<C0045b> arrayList, int i, int i2) {
        if (i2 == i) {
            return false;
        }
        int size = this.f83b.size();
        int i3 = -1;
        for (int i4 = 0; i4 < size; i4++) {
            C0046a aVar = this.f83b.get(i4);
            int i5 = aVar.f104b != null ? aVar.f104b.mContainerId : 0;
            if (!(i5 == 0 || i5 == i3)) {
                for (int i6 = i; i6 < i2; i6++) {
                    C0045b bVar = arrayList.get(i6);
                    int size2 = bVar.f83b.size();
                    for (int i7 = 0; i7 < size2; i7++) {
                        C0046a aVar2 = bVar.f83b.get(i7);
                        if ((aVar2.f104b != null ? aVar2.f104b.mContainerId : 0) == i5) {
                            return true;
                        }
                    }
                }
                i3 = i5;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo116c() {
        int size = this.f83b.size();
        for (int i = 0; i < size; i++) {
            C0046a aVar = this.f83b.get(i);
            C0051e eVar = aVar.f104b;
            if (eVar != null) {
                eVar.setNextTransition(this.f88g, this.f89h);
            }
            int i2 = aVar.f103a;
            if (i2 != 1) {
                switch (i2) {
                    case 3:
                        eVar.setNextAnim(aVar.f106d);
                        this.f82a.mo451h(eVar);
                        break;
                    case 4:
                        eVar.setNextAnim(aVar.f106d);
                        this.f82a.mo454i(eVar);
                        break;
                    case 5:
                        eVar.setNextAnim(aVar.f105c);
                        this.f82a.mo456j(eVar);
                        break;
                    case 6:
                        eVar.setNextAnim(aVar.f106d);
                        this.f82a.mo458k(eVar);
                        break;
                    case 7:
                        eVar.setNextAnim(aVar.f105c);
                        this.f82a.mo460l(eVar);
                        break;
                    case 8:
                        this.f82a.mo466o(eVar);
                        break;
                    case 9:
                        this.f82a.mo466o((C0051e) null);
                        break;
                    default:
                        throw new IllegalArgumentException("Unknown cmd: " + aVar.f103a);
                }
            } else {
                eVar.setNextAnim(aVar.f105c);
                this.f82a.mo415a(eVar, false);
            }
            if (!(this.f101t || aVar.f103a == 1 || eVar == null)) {
                this.f82a.mo442e(eVar);
            }
        }
        if (!this.f101t) {
            this.f82a.mo405a(this.f82a.f190l, true);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo114b(boolean z) {
        for (int size = this.f83b.size() - 1; size >= 0; size--) {
            C0046a aVar = this.f83b.get(size);
            C0051e eVar = aVar.f104b;
            if (eVar != null) {
                eVar.setNextTransition(C0070k.m301d(this.f88g), this.f89h);
            }
            int i = aVar.f103a;
            if (i != 1) {
                switch (i) {
                    case 3:
                        eVar.setNextAnim(aVar.f107e);
                        this.f82a.mo415a(eVar, false);
                        break;
                    case 4:
                        eVar.setNextAnim(aVar.f107e);
                        this.f82a.mo456j(eVar);
                        break;
                    case 5:
                        eVar.setNextAnim(aVar.f108f);
                        this.f82a.mo454i(eVar);
                        break;
                    case 6:
                        eVar.setNextAnim(aVar.f107e);
                        this.f82a.mo460l(eVar);
                        break;
                    case 7:
                        eVar.setNextAnim(aVar.f108f);
                        this.f82a.mo458k(eVar);
                        break;
                    case 8:
                        this.f82a.mo466o((C0051e) null);
                        break;
                    case 9:
                        this.f82a.mo466o(eVar);
                        break;
                    default:
                        throw new IllegalArgumentException("Unknown cmd: " + aVar.f103a);
                }
            } else {
                eVar.setNextAnim(aVar.f108f);
                this.f82a.mo451h(eVar);
            }
            if (!(this.f101t || aVar.f103a == 3 || eVar == null)) {
                this.f82a.mo442e(eVar);
            }
        }
        if (!this.f101t && z) {
            this.f82a.mo405a(this.f82a.f190l, true);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public C0051e mo102a(ArrayList<C0051e> arrayList, C0051e eVar) {
        C0051e eVar2 = eVar;
        int i = 0;
        while (i < this.f83b.size()) {
            C0046a aVar = this.f83b.get(i);
            switch (aVar.f103a) {
                case 1:
                case 7:
                    arrayList.add(aVar.f104b);
                    break;
                case 2:
                    C0051e eVar3 = aVar.f104b;
                    int i2 = eVar3.mContainerId;
                    C0051e eVar4 = eVar2;
                    int i3 = i;
                    boolean z = false;
                    for (int size = arrayList.size() - 1; size >= 0; size--) {
                        C0051e eVar5 = arrayList.get(size);
                        if (eVar5.mContainerId == i2) {
                            if (eVar5 == eVar3) {
                                z = true;
                            } else {
                                if (eVar5 == eVar4) {
                                    this.f83b.add(i3, new C0046a(9, eVar5));
                                    i3++;
                                    eVar4 = null;
                                }
                                C0046a aVar2 = new C0046a(3, eVar5);
                                aVar2.f105c = aVar.f105c;
                                aVar2.f107e = aVar.f107e;
                                aVar2.f106d = aVar.f106d;
                                aVar2.f108f = aVar.f108f;
                                this.f83b.add(i3, aVar2);
                                arrayList.remove(eVar5);
                                i3++;
                            }
                        }
                    }
                    if (z) {
                        this.f83b.remove(i3);
                        i3--;
                    } else {
                        aVar.f103a = 1;
                        arrayList.add(eVar3);
                    }
                    i = i3;
                    eVar2 = eVar4;
                    break;
                case 3:
                case 6:
                    arrayList.remove(aVar.f104b);
                    if (aVar.f104b != eVar2) {
                        break;
                    } else {
                        this.f83b.add(i, new C0046a(9, aVar.f104b));
                        i++;
                        eVar2 = null;
                        break;
                    }
                case 8:
                    this.f83b.add(i, new C0046a(9, eVar2));
                    i++;
                    eVar2 = aVar.f104b;
                    break;
            }
            i++;
        }
        return eVar2;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public C0051e mo113b(ArrayList<C0051e> arrayList, C0051e eVar) {
        for (int i = 0; i < this.f83b.size(); i++) {
            C0046a aVar = this.f83b.get(i);
            int i2 = aVar.f103a;
            if (i2 != 1) {
                if (i2 != 3) {
                    switch (i2) {
                        case 6:
                            break;
                        case 7:
                            break;
                        case 8:
                            eVar = null;
                            break;
                        case 9:
                            eVar = aVar.f104b;
                            break;
                    }
                }
                arrayList.add(aVar.f104b);
            }
            arrayList.remove(aVar.f104b);
        }
        return eVar;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public boolean mo117d() {
        for (int i = 0; i < this.f83b.size(); i++) {
            if (m147b(this.f83b.get(i))) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo107a(C0051e.C0057c cVar) {
        for (int i = 0; i < this.f83b.size(); i++) {
            C0046a aVar = this.f83b.get(i);
            if (m147b(aVar)) {
                aVar.f104b.setOnStartEnterTransitionListener(cVar);
            }
        }
    }

    /* renamed from: b */
    private static boolean m147b(C0046a aVar) {
        C0051e eVar = aVar.f104b;
        return eVar != null && eVar.mAdded && eVar.mView != null && !eVar.mDetached && !eVar.mHidden && eVar.isPostponed();
    }

    /* renamed from: e */
    public String mo118e() {
        return this.f92k;
    }
}
