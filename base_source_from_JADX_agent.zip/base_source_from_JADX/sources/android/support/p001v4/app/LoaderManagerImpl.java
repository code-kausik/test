package android.support.p001v4.app;

import android.arch.lifecycle.C0016e;
import android.arch.lifecycle.C0023j;
import android.arch.lifecycle.C0024k;
import android.arch.lifecycle.C0028n;
import android.arch.lifecycle.C0029o;
import android.arch.lifecycle.C0031p;
import android.os.Bundle;
import android.support.p001v4.app.C0107s;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import p000.C0308i;

/* renamed from: android.support.v4.app.LoaderManagerImpl */
class LoaderManagerImpl extends C0107s {

    /* renamed from: a */
    static boolean f59a = false;

    /* renamed from: b */
    private final C0016e f60b;

    /* renamed from: c */
    private final LoaderViewModel f61c;

    /* renamed from: android.support.v4.app.LoaderManagerImpl$a */
    public static class C0035a<D> extends C0023j<D> implements C0308i.C0309a<D> {

        /* renamed from: a */
        private final int f65a;

        /* renamed from: b */
        private final Bundle f66b;

        /* renamed from: c */
        private final C0308i<D> f67c;

        /* renamed from: d */
        private C0016e f68d;

        /* renamed from: e */
        private C0036b<D> f69e;

        /* renamed from: f */
        private C0308i<D> f70f;

        /* access modifiers changed from: package-private */
        /* renamed from: f */
        public C0308i<D> mo80f() {
            return this.f67c;
        }

        /* access modifiers changed from: protected */
        /* renamed from: b */
        public void mo24b() {
            if (LoaderManagerImpl.f59a) {
                Log.v("LoaderManager", "  Starting: " + this);
            }
            this.f67c.mo3444a();
        }

        /* access modifiers changed from: protected */
        /* renamed from: c */
        public void mo25c() {
            if (LoaderManagerImpl.f59a) {
                Log.v("LoaderManager", "  Stopping: " + this);
            }
            this.f67c.mo3450e();
        }

        /* access modifiers changed from: package-private */
        /* renamed from: g */
        public void mo81g() {
            C0016e eVar = this.f68d;
            C0036b<D> bVar = this.f69e;
            if (eVar != null && bVar != null) {
                super.mo22a(bVar);
                mo21a(eVar, bVar);
            }
        }

        /* renamed from: a */
        public void mo22a(C0024k<? super D> kVar) {
            super.mo22a(kVar);
            this.f68d = null;
            this.f69e = null;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public C0308i<D> mo78a(boolean z) {
            if (LoaderManagerImpl.f59a) {
                Log.v("LoaderManager", "  Destroying: " + this);
            }
            this.f67c.mo3448c();
            this.f67c.mo3452g();
            C0036b<D> bVar = this.f69e;
            if (bVar != null) {
                mo22a(bVar);
                if (z) {
                    bVar.mo85b();
                }
            }
            this.f67c.mo3445a(this);
            if ((bVar == null || bVar.mo84a()) && !z) {
                return this.f67c;
            }
            this.f67c.mo3454i();
            return this.f70f;
        }

        /* renamed from: a */
        public void mo23a(D d) {
            super.mo23a(d);
            if (this.f70f != null) {
                this.f70f.mo3454i();
                this.f70f = null;
            }
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(64);
            sb.append("LoaderInfo{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" #");
            sb.append(this.f65a);
            sb.append(" : ");
            C0455p.m1460a(this.f67c, sb);
            sb.append("}}");
            return sb.toString();
        }

        /* renamed from: a */
        public void mo79a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            printWriter.print(str);
            printWriter.print("mId=");
            printWriter.print(this.f65a);
            printWriter.print(" mArgs=");
            printWriter.println(this.f66b);
            printWriter.print(str);
            printWriter.print("mLoader=");
            printWriter.println(this.f67c);
            C0308i<D> iVar = this.f67c;
            iVar.mo3446a(str + "  ", fileDescriptor, printWriter, strArr);
            if (this.f69e != null) {
                printWriter.print(str);
                printWriter.print("mCallbacks=");
                printWriter.println(this.f69e);
                C0036b<D> bVar = this.f69e;
                bVar.mo83a(str + "  ", printWriter);
            }
            printWriter.print(str);
            printWriter.print("mData=");
            printWriter.println(mo80f().mo3443a(mo20a()));
            printWriter.print(str);
            printWriter.print("mStarted=");
            printWriter.println(mo26d());
        }
    }

    /* renamed from: android.support.v4.app.LoaderManagerImpl$b */
    static class C0036b<D> implements C0024k<D> {

        /* renamed from: a */
        private final C0308i<D> f71a;

        /* renamed from: b */
        private final C0107s.C0108a<D> f72b;

        /* renamed from: c */
        private boolean f73c;

        /* renamed from: a */
        public void mo48a(D d) {
            if (LoaderManagerImpl.f59a) {
                Log.v("LoaderManager", "  onLoadFinished in " + this.f71a + ": " + this.f71a.mo3443a(d));
            }
            this.f72b.mo554a(this.f71a, d);
            this.f73c = true;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public boolean mo84a() {
            return this.f73c;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo85b() {
            if (this.f73c) {
                if (LoaderManagerImpl.f59a) {
                    Log.v("LoaderManager", "  Resetting: " + this.f71a);
                }
                this.f72b.mo553a(this.f71a);
            }
        }

        public String toString() {
            return this.f72b.toString();
        }

        /* renamed from: a */
        public void mo83a(String str, PrintWriter printWriter) {
            printWriter.print(str);
            printWriter.print("mDeliveredData=");
            printWriter.println(this.f73c);
        }
    }

    /* renamed from: android.support.v4.app.LoaderManagerImpl$LoaderViewModel */
    static class LoaderViewModel extends C0028n {

        /* renamed from: a */
        private static final C0029o.C0030a f62a = new C0029o.C0030a() {
            /* renamed from: a */
            public <T extends C0028n> T mo62a(Class<T> cls) {
                return new LoaderViewModel();
            }
        };

        /* renamed from: b */
        private C0465u<C0035a> f63b = new C0465u<>();

        /* renamed from: c */
        private boolean f64c = false;

        LoaderViewModel() {
        }

        /* renamed from: a */
        static LoaderViewModel m116a(C0031p pVar) {
            return (LoaderViewModel) new C0029o(pVar, f62a).mo60a(LoaderViewModel.class);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: b */
        public void mo77b() {
            int b = this.f63b.mo4175b();
            for (int i = 0; i < b; i++) {
                this.f63b.mo4182e(i).mo81g();
            }
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo59a() {
            super.mo59a();
            int b = this.f63b.mo4175b();
            for (int i = 0; i < b; i++) {
                this.f63b.mo4182e(i).mo78a(true);
            }
            this.f63b.mo4178c();
        }

        /* renamed from: a */
        public void mo76a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            if (this.f63b.mo4175b() > 0) {
                printWriter.print(str);
                printWriter.println("Loaders:");
                String str2 = str + "    ";
                for (int i = 0; i < this.f63b.mo4175b(); i++) {
                    C0035a e = this.f63b.mo4182e(i);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(this.f63b.mo4181d(i));
                    printWriter.print(": ");
                    printWriter.println(e.toString());
                    e.mo79a(str2, fileDescriptor, printWriter, strArr);
                }
            }
        }
    }

    LoaderManagerImpl(C0016e eVar, C0031p pVar) {
        this.f60b = eVar;
        this.f61c = LoaderViewModel.m116a(pVar);
    }

    /* renamed from: a */
    public void mo73a() {
        this.f61c.mo77b();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("LoaderManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        C0455p.m1460a(this.f60b, sb);
        sb.append("}}");
        return sb.toString();
    }

    @Deprecated
    /* renamed from: a */
    public void mo74a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        this.f61c.mo76a(str, fileDescriptor, printWriter, strArr);
    }
}
