package android.support.p001v4.app;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: android.support.v4.app.m */
final class C0087m implements Parcelable {
    public static final Parcelable.Creator<C0087m> CREATOR = new Parcelable.Creator<C0087m>() {
        /* renamed from: a */
        public C0087m createFromParcel(Parcel parcel) {
            return new C0087m(parcel);
        }

        /* renamed from: a */
        public C0087m[] newArray(int i) {
            return new C0087m[i];
        }
    };

    /* renamed from: a */
    C0089n[] f237a;

    /* renamed from: b */
    int[] f238b;

    /* renamed from: c */
    C0047c[] f239c;

    /* renamed from: d */
    int f240d = -1;

    /* renamed from: e */
    int f241e;

    public int describeContents() {
        return 0;
    }

    public C0087m() {
    }

    public C0087m(Parcel parcel) {
        this.f237a = (C0089n[]) parcel.createTypedArray(C0089n.CREATOR);
        this.f238b = parcel.createIntArray();
        this.f239c = (C0047c[]) parcel.createTypedArray(C0047c.CREATOR);
        this.f240d = parcel.readInt();
        this.f241e = parcel.readInt();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedArray(this.f237a, i);
        parcel.writeIntArray(this.f238b);
        parcel.writeTypedArray(this.f239c, i);
        parcel.writeInt(this.f240d);
        parcel.writeInt(this.f241e);
    }
}
