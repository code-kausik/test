package android.support.p001v4.app;

import android.app.RemoteInput;
import android.os.Bundle;
import java.util.Set;

/* renamed from: android.support.v4.app.y */
public final class C0118y {

    /* renamed from: a */
    private final String f387a;

    /* renamed from: b */
    private final CharSequence f388b;

    /* renamed from: c */
    private final CharSequence[] f389c;

    /* renamed from: d */
    private final boolean f390d;

    /* renamed from: e */
    private final Bundle f391e;

    /* renamed from: f */
    private final Set<String> f392f;

    /* renamed from: a */
    public String mo597a() {
        return this.f387a;
    }

    /* renamed from: b */
    public CharSequence mo598b() {
        return this.f388b;
    }

    /* renamed from: c */
    public CharSequence[] mo599c() {
        return this.f389c;
    }

    /* renamed from: d */
    public Set<String> mo600d() {
        return this.f392f;
    }

    /* renamed from: e */
    public boolean mo601e() {
        return this.f390d;
    }

    /* renamed from: f */
    public Bundle mo602f() {
        return this.f391e;
    }

    /* renamed from: a */
    static RemoteInput[] m536a(C0118y[] yVarArr) {
        if (yVarArr == null) {
            return null;
        }
        RemoteInput[] remoteInputArr = new RemoteInput[yVarArr.length];
        for (int i = 0; i < yVarArr.length; i++) {
            remoteInputArr[i] = m535a(yVarArr[i]);
        }
        return remoteInputArr;
    }

    /* renamed from: a */
    static RemoteInput m535a(C0118y yVar) {
        return new RemoteInput.Builder(yVar.mo597a()).setLabel(yVar.mo598b()).setChoices(yVar.mo599c()).setAllowFreeFormInput(yVar.mo601e()).addExtras(yVar.mo602f()).build();
    }
}
