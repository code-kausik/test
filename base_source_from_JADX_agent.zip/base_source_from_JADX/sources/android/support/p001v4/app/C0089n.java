package android.support.p001v4.app;

import android.arch.lifecycle.C0031p;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

/* renamed from: android.support.v4.app.n */
final class C0089n implements Parcelable {
    public static final Parcelable.Creator<C0089n> CREATOR = new Parcelable.Creator<C0089n>() {
        /* renamed from: a */
        public C0089n createFromParcel(Parcel parcel) {
            return new C0089n(parcel);
        }

        /* renamed from: a */
        public C0089n[] newArray(int i) {
            return new C0089n[i];
        }
    };

    /* renamed from: a */
    final String f242a;

    /* renamed from: b */
    final int f243b;

    /* renamed from: c */
    final boolean f244c;

    /* renamed from: d */
    final int f245d;

    /* renamed from: e */
    final int f246e;

    /* renamed from: f */
    final String f247f;

    /* renamed from: g */
    final boolean f248g;

    /* renamed from: h */
    final boolean f249h;

    /* renamed from: i */
    final Bundle f250i;

    /* renamed from: j */
    final boolean f251j;

    /* renamed from: k */
    Bundle f252k;

    /* renamed from: l */
    C0051e f253l;

    public int describeContents() {
        return 0;
    }

    C0089n(C0051e eVar) {
        this.f242a = eVar.getClass().getName();
        this.f243b = eVar.mIndex;
        this.f244c = eVar.mFromLayout;
        this.f245d = eVar.mFragmentId;
        this.f246e = eVar.mContainerId;
        this.f247f = eVar.mTag;
        this.f248g = eVar.mRetainInstance;
        this.f249h = eVar.mDetached;
        this.f250i = eVar.mArguments;
        this.f251j = eVar.mHidden;
    }

    C0089n(Parcel parcel) {
        this.f242a = parcel.readString();
        this.f243b = parcel.readInt();
        boolean z = false;
        this.f244c = parcel.readInt() != 0;
        this.f245d = parcel.readInt();
        this.f246e = parcel.readInt();
        this.f247f = parcel.readString();
        this.f248g = parcel.readInt() != 0;
        this.f249h = parcel.readInt() != 0;
        this.f250i = parcel.readBundle();
        this.f251j = parcel.readInt() != 0 ? true : z;
        this.f252k = parcel.readBundle();
    }

    /* renamed from: a */
    public C0051e mo504a(C0066i iVar, C0064g gVar, C0051e eVar, C0086l lVar, C0031p pVar) {
        if (this.f253l == null) {
            Context i = iVar.mo377i();
            if (this.f250i != null) {
                this.f250i.setClassLoader(i.getClassLoader());
            }
            if (gVar != null) {
                this.f253l = gVar.mo288a(i, this.f242a, this.f250i);
            } else {
                this.f253l = C0051e.instantiate(i, this.f242a, this.f250i);
            }
            if (this.f252k != null) {
                this.f252k.setClassLoader(i.getClassLoader());
                this.f253l.mSavedFragmentState = this.f252k;
            }
            this.f253l.setIndex(this.f243b, eVar);
            this.f253l.mFromLayout = this.f244c;
            this.f253l.mRestored = true;
            this.f253l.mFragmentId = this.f245d;
            this.f253l.mContainerId = this.f246e;
            this.f253l.mTag = this.f247f;
            this.f253l.mRetainInstance = this.f248g;
            this.f253l.mDetached = this.f249h;
            this.f253l.mHidden = this.f251j;
            this.f253l.mFragmentManager = iVar.f164b;
            if (C0070k.f172a) {
                Log.v("FragmentManager", "Instantiated fragment " + this.f253l);
            }
        }
        this.f253l.mChildNonConfig = lVar;
        this.f253l.mViewModelStore = pVar;
        return this.f253l;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f242a);
        parcel.writeInt(this.f243b);
        parcel.writeInt(this.f244c ? 1 : 0);
        parcel.writeInt(this.f245d);
        parcel.writeInt(this.f246e);
        parcel.writeString(this.f247f);
        parcel.writeInt(this.f248g ? 1 : 0);
        parcel.writeInt(this.f249h ? 1 : 0);
        parcel.writeBundle(this.f250i);
        parcel.writeInt(this.f251j ? 1 : 0);
        parcel.writeBundle(this.f252k);
    }
}
