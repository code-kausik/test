package android.support.p001v4.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

/* renamed from: android.support.v4.app.j */
public abstract class C0067j {

    /* renamed from: android.support.v4.app.j$a */
    public static abstract class C0068a {
        /* renamed from: a */
        public void mo386a(C0067j jVar, C0051e eVar) {
        }

        /* renamed from: a */
        public void mo387a(C0067j jVar, C0051e eVar, Context context) {
        }

        /* renamed from: a */
        public void mo388a(C0067j jVar, C0051e eVar, Bundle bundle) {
        }

        /* renamed from: a */
        public void mo389a(C0067j jVar, C0051e eVar, View view, Bundle bundle) {
        }

        /* renamed from: b */
        public void mo390b(C0067j jVar, C0051e eVar) {
        }

        /* renamed from: b */
        public void mo391b(C0067j jVar, C0051e eVar, Context context) {
        }

        /* renamed from: b */
        public void mo392b(C0067j jVar, C0051e eVar, Bundle bundle) {
        }

        /* renamed from: c */
        public void mo393c(C0067j jVar, C0051e eVar) {
        }

        /* renamed from: c */
        public void mo394c(C0067j jVar, C0051e eVar, Bundle bundle) {
        }

        /* renamed from: d */
        public void mo395d(C0067j jVar, C0051e eVar) {
        }

        /* renamed from: d */
        public void mo396d(C0067j jVar, C0051e eVar, Bundle bundle) {
        }

        /* renamed from: e */
        public void mo397e(C0067j jVar, C0051e eVar) {
        }

        /* renamed from: f */
        public void mo398f(C0067j jVar, C0051e eVar) {
        }

        /* renamed from: g */
        public void mo399g(C0067j jVar, C0051e eVar) {
        }
    }

    /* renamed from: android.support.v4.app.j$b */
    public interface C0069b {
        /* renamed from: a */
        void mo400a();
    }

    /* renamed from: a */
    public abstract C0051e mo380a(String str);

    /* renamed from: a */
    public abstract C0091o mo381a();

    /* renamed from: a */
    public abstract void mo382a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    /* renamed from: b */
    public abstract boolean mo383b();

    /* renamed from: c */
    public abstract List<C0051e> mo384c();

    /* renamed from: d */
    public abstract boolean mo385d();
}
