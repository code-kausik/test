package android.support.p001v4.app;

import android.view.View;
import android.view.ViewTreeObserver;

/* renamed from: android.support.v4.app.x */
class C0117x implements View.OnAttachStateChangeListener, ViewTreeObserver.OnPreDrawListener {

    /* renamed from: a */
    private final View f384a;

    /* renamed from: b */
    private ViewTreeObserver f385b;

    /* renamed from: c */
    private final Runnable f386c;

    private C0117x(View view, Runnable runnable) {
        this.f384a = view;
        this.f385b = view.getViewTreeObserver();
        this.f386c = runnable;
    }

    /* renamed from: a */
    public static C0117x m533a(View view, Runnable runnable) {
        C0117x xVar = new C0117x(view, runnable);
        view.getViewTreeObserver().addOnPreDrawListener(xVar);
        view.addOnAttachStateChangeListener(xVar);
        return xVar;
    }

    public boolean onPreDraw() {
        mo593a();
        this.f386c.run();
        return true;
    }

    /* renamed from: a */
    public void mo593a() {
        if (this.f385b.isAlive()) {
            this.f385b.removeOnPreDrawListener(this);
        } else {
            this.f384a.getViewTreeObserver().removeOnPreDrawListener(this);
        }
        this.f384a.removeOnAttachStateChangeListener(this);
    }

    public void onViewAttachedToWindow(View view) {
        this.f385b = view.getViewTreeObserver();
    }

    public void onViewDetachedFromWindow(View view) {
        mo593a();
    }
}
