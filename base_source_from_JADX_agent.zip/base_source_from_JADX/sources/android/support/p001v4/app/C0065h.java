package android.support.p001v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

/* renamed from: android.support.v4.app.h */
public class C0065h {

    /* renamed from: a */
    private final C0066i<?> f162a;

    /* renamed from: a */
    public static C0065h m212a(C0066i<?> iVar) {
        return new C0065h(iVar);
    }

    private C0065h(C0066i<?> iVar) {
        this.f162a = iVar;
    }

    /* renamed from: a */
    public C0067j mo352a() {
        return this.f162a.mo379k();
    }

    /* renamed from: a */
    public C0051e mo351a(String str) {
        return this.f162a.f164b.mo425b(str);
    }

    /* renamed from: a */
    public void mo356a(C0051e eVar) {
        this.f162a.f164b.mo416a((C0066i) this.f162a, (C0064g) this.f162a, eVar);
    }

    /* renamed from: a */
    public View mo353a(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f162a.f164b.onCreateView(view, str, context, attributeSet);
    }

    /* renamed from: b */
    public void mo361b() {
        this.f162a.f164b.mo461m();
    }

    /* renamed from: c */
    public Parcelable mo365c() {
        return this.f162a.f164b.mo459l();
    }

    /* renamed from: a */
    public void mo355a(Parcelable parcelable, C0086l lVar) {
        this.f162a.f164b.mo408a(parcelable, lVar);
    }

    /* renamed from: d */
    public C0086l mo366d() {
        return this.f162a.f164b.mo455j();
    }

    /* renamed from: e */
    public void mo367e() {
        this.f162a.f164b.mo464n();
    }

    /* renamed from: f */
    public void mo368f() {
        this.f162a.f164b.mo465o();
    }

    /* renamed from: g */
    public void mo369g() {
        this.f162a.f164b.mo469p();
    }

    /* renamed from: h */
    public void mo370h() {
        this.f162a.f164b.mo470q();
    }

    /* renamed from: i */
    public void mo371i() {
        this.f162a.f164b.mo471r();
    }

    /* renamed from: j */
    public void mo372j() {
        this.f162a.f164b.mo472s();
    }

    /* renamed from: k */
    public void mo373k() {
        this.f162a.f164b.mo475u();
    }

    /* renamed from: a */
    public void mo357a(boolean z) {
        this.f162a.f164b.mo418a(z);
    }

    /* renamed from: b */
    public void mo363b(boolean z) {
        this.f162a.f164b.mo432b(z);
    }

    /* renamed from: a */
    public void mo354a(Configuration configuration) {
        this.f162a.f164b.mo406a(configuration);
    }

    /* renamed from: l */
    public void mo374l() {
        this.f162a.f164b.mo476v();
    }

    /* renamed from: a */
    public boolean mo359a(Menu menu, MenuInflater menuInflater) {
        return this.f162a.f164b.mo421a(menu, menuInflater);
    }

    /* renamed from: a */
    public boolean mo358a(Menu menu) {
        return this.f162a.f164b.mo420a(menu);
    }

    /* renamed from: a */
    public boolean mo360a(MenuItem menuItem) {
        return this.f162a.f164b.mo422a(menuItem);
    }

    /* renamed from: b */
    public boolean mo364b(MenuItem menuItem) {
        return this.f162a.f164b.mo433b(menuItem);
    }

    /* renamed from: b */
    public void mo362b(Menu menu) {
        this.f162a.f164b.mo431b(menu);
    }

    /* renamed from: m */
    public boolean mo375m() {
        return this.f162a.f164b.mo449g();
    }
}
