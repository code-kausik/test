package android.support.p001v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.ArrayList;
import p000.C0301f;

/* renamed from: android.support.v4.app.u */
public class C0110u {

    /* renamed from: android.support.v4.app.u$c */
    public static class C0113c {

        /* renamed from: A */
        String f327A;

        /* renamed from: B */
        Bundle f328B;

        /* renamed from: C */
        int f329C;

        /* renamed from: D */
        int f330D;

        /* renamed from: E */
        Notification f331E;

        /* renamed from: F */
        RemoteViews f332F;

        /* renamed from: G */
        RemoteViews f333G;

        /* renamed from: H */
        RemoteViews f334H;

        /* renamed from: I */
        String f335I;

        /* renamed from: J */
        int f336J;

        /* renamed from: K */
        String f337K;

        /* renamed from: L */
        long f338L;

        /* renamed from: M */
        int f339M;

        /* renamed from: N */
        Notification f340N;
        @Deprecated

        /* renamed from: O */
        public ArrayList<String> f341O;

        /* renamed from: a */
        public Context f342a;

        /* renamed from: b */
        public ArrayList<C0111a> f343b;

        /* renamed from: c */
        ArrayList<C0111a> f344c;

        /* renamed from: d */
        CharSequence f345d;

        /* renamed from: e */
        CharSequence f346e;

        /* renamed from: f */
        PendingIntent f347f;

        /* renamed from: g */
        PendingIntent f348g;

        /* renamed from: h */
        RemoteViews f349h;

        /* renamed from: i */
        Bitmap f350i;

        /* renamed from: j */
        CharSequence f351j;

        /* renamed from: k */
        int f352k;

        /* renamed from: l */
        int f353l;

        /* renamed from: m */
        boolean f354m;

        /* renamed from: n */
        boolean f355n;

        /* renamed from: o */
        C0114d f356o;

        /* renamed from: p */
        CharSequence f357p;

        /* renamed from: q */
        CharSequence[] f358q;

        /* renamed from: r */
        int f359r;

        /* renamed from: s */
        int f360s;

        /* renamed from: t */
        boolean f361t;

        /* renamed from: u */
        String f362u;

        /* renamed from: v */
        boolean f363v;

        /* renamed from: w */
        String f364w;

        /* renamed from: x */
        boolean f365x;

        /* renamed from: y */
        boolean f366y;

        /* renamed from: z */
        boolean f367z;

        public C0113c(Context context, String str) {
            this.f343b = new ArrayList<>();
            this.f344c = new ArrayList<>();
            this.f354m = true;
            this.f365x = false;
            this.f329C = 0;
            this.f330D = 0;
            this.f336J = 0;
            this.f339M = 0;
            this.f340N = new Notification();
            this.f342a = context;
            this.f335I = str;
            this.f340N.when = System.currentTimeMillis();
            this.f340N.audioStreamType = -1;
            this.f353l = 0;
            this.f341O = new ArrayList<>();
        }

        @Deprecated
        public C0113c(Context context) {
            this(context, (String) null);
        }

        /* renamed from: a */
        public C0113c mo568a(int i) {
            this.f340N.icon = i;
            return this;
        }

        /* renamed from: a */
        public C0113c mo574a(CharSequence charSequence) {
            this.f345d = m496d(charSequence);
            return this;
        }

        /* renamed from: b */
        public C0113c mo579b(CharSequence charSequence) {
            this.f346e = m496d(charSequence);
            return this;
        }

        /* renamed from: b */
        public C0113c mo577b(int i) {
            this.f352k = i;
            return this;
        }

        /* renamed from: a */
        public C0113c mo570a(PendingIntent pendingIntent) {
            this.f347f = pendingIntent;
            return this;
        }

        /* renamed from: b */
        public C0113c mo578b(PendingIntent pendingIntent) {
            this.f340N.deleteIntent = pendingIntent;
            return this;
        }

        /* renamed from: c */
        public C0113c mo583c(CharSequence charSequence) {
            this.f340N.tickerText = m496d(charSequence);
            return this;
        }

        /* renamed from: a */
        public C0113c mo571a(Bitmap bitmap) {
            this.f350i = m495b(bitmap);
            return this;
        }

        /* renamed from: b */
        private Bitmap m495b(Bitmap bitmap) {
            if (bitmap == null || Build.VERSION.SDK_INT >= 27) {
                return bitmap;
            }
            Resources resources = this.f342a.getResources();
            int dimensionPixelSize = resources.getDimensionPixelSize(C0301f.C0302a.compat_notification_large_icon_max_width);
            int dimensionPixelSize2 = resources.getDimensionPixelSize(C0301f.C0302a.compat_notification_large_icon_max_height);
            if (bitmap.getWidth() <= dimensionPixelSize && bitmap.getHeight() <= dimensionPixelSize2) {
                return bitmap;
            }
            double min = Math.min(((double) dimensionPixelSize) / ((double) Math.max(1, bitmap.getWidth())), ((double) dimensionPixelSize2) / ((double) Math.max(1, bitmap.getHeight())));
            return Bitmap.createScaledBitmap(bitmap, (int) Math.ceil(((double) bitmap.getWidth()) * min), (int) Math.ceil(((double) bitmap.getHeight()) * min), true);
        }

        /* renamed from: a */
        public C0113c mo572a(Uri uri) {
            this.f340N.sound = uri;
            this.f340N.audioStreamType = -1;
            if (Build.VERSION.SDK_INT >= 21) {
                this.f340N.audioAttributes = new AudioAttributes.Builder().setContentType(4).setUsage(5).build();
            }
            return this;
        }

        /* renamed from: a */
        public C0113c mo569a(int i, int i2, int i3) {
            this.f340N.ledARGB = i;
            this.f340N.ledOnMS = i2;
            this.f340N.ledOffMS = i3;
            this.f340N.flags = ((this.f340N.ledOnMS == 0 || this.f340N.ledOffMS == 0) ? 0 : 1) | (this.f340N.flags & -2);
            return this;
        }

        /* renamed from: a */
        public C0113c mo575a(boolean z) {
            m494a(2, z);
            return this;
        }

        /* renamed from: b */
        public C0113c mo580b(boolean z) {
            m494a(16, z);
            return this;
        }

        /* renamed from: c */
        public C0113c mo582c(int i) {
            this.f340N.defaults = i;
            if ((i & 4) != 0) {
                this.f340N.flags |= 1;
            }
            return this;
        }

        /* renamed from: a */
        private void m494a(int i, boolean z) {
            if (z) {
                Notification notification = this.f340N;
                notification.flags = i | notification.flags;
                return;
            }
            Notification notification2 = this.f340N;
            notification2.flags = (i ^ -1) & notification2.flags;
        }

        /* renamed from: d */
        public C0113c mo584d(int i) {
            this.f353l = i;
            return this;
        }

        /* renamed from: a */
        public Bundle mo567a() {
            if (this.f328B == null) {
                this.f328B = new Bundle();
            }
            return this.f328B;
        }

        /* renamed from: a */
        public C0113c mo573a(C0114d dVar) {
            if (this.f356o != dVar) {
                this.f356o = dVar;
                if (this.f356o != null) {
                    this.f356o.mo587a(this);
                }
            }
            return this;
        }

        /* renamed from: e */
        public C0113c mo585e(int i) {
            this.f329C = i;
            return this;
        }

        @Deprecated
        /* renamed from: b */
        public Notification mo576b() {
            return mo581c();
        }

        /* renamed from: c */
        public Notification mo581c() {
            return new C0115v(this).mo591b();
        }

        /* renamed from: d */
        protected static CharSequence m496d(CharSequence charSequence) {
            return (charSequence != null && charSequence.length() > 5120) ? charSequence.subSequence(0, 5120) : charSequence;
        }
    }

    /* renamed from: android.support.v4.app.u$d */
    public static abstract class C0114d {

        /* renamed from: a */
        protected C0113c f368a;

        /* renamed from: b */
        CharSequence f369b;

        /* renamed from: c */
        CharSequence f370c;

        /* renamed from: d */
        boolean f371d = false;

        /* renamed from: a */
        public void mo586a(Bundle bundle) {
        }

        /* renamed from: a */
        public void mo566a(C0109t tVar) {
        }

        /* renamed from: b */
        public RemoteViews mo588b(C0109t tVar) {
            return null;
        }

        /* renamed from: c */
        public RemoteViews mo589c(C0109t tVar) {
            return null;
        }

        /* renamed from: d */
        public RemoteViews mo590d(C0109t tVar) {
            return null;
        }

        /* renamed from: a */
        public void mo587a(C0113c cVar) {
            if (this.f368a != cVar) {
                this.f368a = cVar;
                if (this.f368a != null) {
                    this.f368a.mo573a(this);
                }
            }
        }
    }

    /* renamed from: android.support.v4.app.u$b */
    public static class C0112b extends C0114d {

        /* renamed from: e */
        private CharSequence f326e;

        /* renamed from: a */
        public C0112b mo565a(CharSequence charSequence) {
            this.f326e = C0113c.m496d(charSequence);
            return this;
        }

        /* renamed from: a */
        public void mo566a(C0109t tVar) {
            if (Build.VERSION.SDK_INT >= 16) {
                Notification.BigTextStyle bigText = new Notification.BigTextStyle(tVar.mo555a()).setBigContentTitle(this.f369b).bigText(this.f326e);
                if (this.f371d) {
                    bigText.setSummaryText(this.f370c);
                }
            }
        }
    }

    /* renamed from: android.support.v4.app.u$a */
    public static class C0111a {

        /* renamed from: a */
        final Bundle f317a;

        /* renamed from: b */
        boolean f318b;

        /* renamed from: c */
        public int f319c;

        /* renamed from: d */
        public CharSequence f320d;

        /* renamed from: e */
        public PendingIntent f321e;

        /* renamed from: f */
        private final C0118y[] f322f;

        /* renamed from: g */
        private final C0118y[] f323g;

        /* renamed from: h */
        private boolean f324h;

        /* renamed from: i */
        private final int f325i;

        /* renamed from: a */
        public int mo556a() {
            return this.f319c;
        }

        /* renamed from: b */
        public CharSequence mo557b() {
            return this.f320d;
        }

        /* renamed from: c */
        public PendingIntent mo558c() {
            return this.f321e;
        }

        /* renamed from: d */
        public Bundle mo559d() {
            return this.f317a;
        }

        /* renamed from: e */
        public boolean mo560e() {
            return this.f324h;
        }

        /* renamed from: f */
        public C0118y[] mo561f() {
            return this.f322f;
        }

        /* renamed from: g */
        public int mo562g() {
            return this.f325i;
        }

        /* renamed from: h */
        public C0118y[] mo563h() {
            return this.f323g;
        }

        /* renamed from: i */
        public boolean mo564i() {
            return this.f318b;
        }
    }

    /* renamed from: a */
    public static Bundle m482a(Notification notification) {
        if (Build.VERSION.SDK_INT >= 19) {
            return notification.extras;
        }
        if (Build.VERSION.SDK_INT >= 16) {
            return C0116w.m528a(notification);
        }
        return null;
    }
}
