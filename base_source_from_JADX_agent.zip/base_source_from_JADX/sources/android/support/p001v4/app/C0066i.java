package android.support.p001v4.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: android.support.v4.app.i */
public abstract class C0066i<E> extends C0064g {

    /* renamed from: a */
    private final Activity f163a;

    /* renamed from: b */
    final C0070k f164b;

    /* renamed from: c */
    private final Context f165c;

    /* renamed from: d */
    private final Handler f166d;

    /* renamed from: e */
    private final int f167e;

    /* renamed from: a */
    public View mo289a(int i) {
        return null;
    }

    /* renamed from: a */
    public void mo340a(C0051e eVar, String[] strArr, int i) {
    }

    /* renamed from: a */
    public void mo341a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
    }

    /* renamed from: a */
    public boolean mo290a() {
        return true;
    }

    /* renamed from: a */
    public boolean mo342a(C0051e eVar) {
        return true;
    }

    /* renamed from: a */
    public boolean mo343a(String str) {
        return false;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo345b(C0051e eVar) {
    }

    /* renamed from: d */
    public void mo347d() {
    }

    /* renamed from: e */
    public boolean mo348e() {
        return true;
    }

    /* renamed from: g */
    public abstract E mo350g();

    C0066i(C0060f fVar) {
        this(fVar, fVar, fVar.f146a, 0);
    }

    C0066i(Activity activity, Context context, Handler handler, int i) {
        this.f164b = new C0070k();
        this.f163a = activity;
        this.f165c = (Context) C0463s.m1482a(context, "context == null");
        this.f166d = (Handler) C0463s.m1482a(handler, "handler == null");
        this.f167e = i;
    }

    /* renamed from: b */
    public LayoutInflater mo344b() {
        return LayoutInflater.from(this.f165c);
    }

    /* renamed from: a */
    public void mo338a(C0051e eVar, Intent intent, int i, Bundle bundle) {
        if (i != -1) {
            throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
        }
        this.f165c.startActivity(intent);
    }

    /* renamed from: a */
    public void mo339a(C0051e eVar, IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) throws IntentSender.SendIntentException {
        int i5 = i;
        if (i5 != -1) {
            throw new IllegalStateException("Starting intent sender with a requestCode requires a FragmentActivity host");
        }
        C0037a.m135a(this.f163a, intentSender, i5, intent, i2, i3, i4, bundle);
    }

    /* renamed from: f */
    public int mo349f() {
        return this.f167e;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public Activity mo376h() {
        return this.f163a;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public Context mo377i() {
        return this.f165c;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public Handler mo378j() {
        return this.f166d;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public C0070k mo379k() {
        return this.f164b;
    }
}
