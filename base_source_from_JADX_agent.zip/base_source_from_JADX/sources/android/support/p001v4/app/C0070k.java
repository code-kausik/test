package android.support.p001v4.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.arch.lifecycle.C0031p;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.support.p001v4.app.C0051e;
import android.support.p001v4.app.C0067j;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/* renamed from: android.support.v4.app.k */
final class C0070k extends C0067j implements LayoutInflater.Factory2 {

    /* renamed from: F */
    static final Interpolator f168F = new DecelerateInterpolator(2.5f);

    /* renamed from: G */
    static final Interpolator f169G = new DecelerateInterpolator(1.5f);

    /* renamed from: H */
    static final Interpolator f170H = new AccelerateInterpolator(2.5f);

    /* renamed from: I */
    static final Interpolator f171I = new AccelerateInterpolator(1.5f);

    /* renamed from: a */
    static boolean f172a = false;

    /* renamed from: q */
    static Field f173q;

    /* renamed from: A */
    Bundle f174A = null;

    /* renamed from: B */
    SparseArray<Parcelable> f175B = null;

    /* renamed from: C */
    ArrayList<C0085i> f176C;

    /* renamed from: D */
    C0086l f177D;

    /* renamed from: E */
    Runnable f178E = new Runnable() {
        public void run() {
            C0070k.this.mo449g();
        }
    };

    /* renamed from: J */
    private final CopyOnWriteArrayList<C0082f> f179J = new CopyOnWriteArrayList<>();

    /* renamed from: b */
    ArrayList<C0084h> f180b;

    /* renamed from: c */
    boolean f181c;

    /* renamed from: d */
    int f182d = 0;

    /* renamed from: e */
    final ArrayList<C0051e> f183e = new ArrayList<>();

    /* renamed from: f */
    SparseArray<C0051e> f184f;

    /* renamed from: g */
    ArrayList<C0045b> f185g;

    /* renamed from: h */
    ArrayList<C0051e> f186h;

    /* renamed from: i */
    ArrayList<C0045b> f187i;

    /* renamed from: j */
    ArrayList<Integer> f188j;

    /* renamed from: k */
    ArrayList<C0067j.C0069b> f189k;

    /* renamed from: l */
    int f190l = 0;

    /* renamed from: m */
    C0066i f191m;

    /* renamed from: n */
    C0064g f192n;

    /* renamed from: o */
    C0051e f193o;

    /* renamed from: p */
    C0051e f194p;

    /* renamed from: r */
    boolean f195r;

    /* renamed from: s */
    boolean f196s;

    /* renamed from: t */
    boolean f197t;

    /* renamed from: u */
    boolean f198u;

    /* renamed from: v */
    String f199v;

    /* renamed from: w */
    boolean f200w;

    /* renamed from: x */
    ArrayList<C0045b> f201x;

    /* renamed from: y */
    ArrayList<Boolean> f202y;

    /* renamed from: z */
    ArrayList<C0051e> f203z;

    /* renamed from: android.support.v4.app.k$f */
    private static final class C0082f {

        /* renamed from: a */
        final C0067j.C0068a f228a;

        /* renamed from: b */
        final boolean f229b;
    }

    /* renamed from: android.support.v4.app.k$g */
    static class C0083g {

        /* renamed from: a */
        public static final int[] f230a = {16842755, 16842960, 16842961};
    }

    /* renamed from: android.support.v4.app.k$h */
    interface C0084h {
        /* renamed from: a */
        boolean mo111a(ArrayList<C0045b> arrayList, ArrayList<Boolean> arrayList2);
    }

    /* renamed from: b */
    public static int m294b(int i, boolean z) {
        if (i == 4097) {
            return z ? 1 : 2;
        }
        if (i == 4099) {
            return z ? 5 : 6;
        }
        if (i != 8194) {
            return -1;
        }
        return z ? 3 : 4;
    }

    /* renamed from: d */
    public static int m301d(int i) {
        if (i == 4097) {
            return 8194;
        }
        if (i != 4099) {
            return i != 8194 ? 0 : 4097;
        }
        return 4099;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: x */
    public LayoutInflater.Factory2 mo478x() {
        return this;
    }

    C0070k() {
    }

    /* renamed from: a */
    static boolean m291a(C0079c cVar) {
        if (cVar.f220a instanceof AlphaAnimation) {
            return true;
        }
        if (!(cVar.f220a instanceof AnimationSet)) {
            return m290a(cVar.f221b);
        }
        List<Animation> animations = ((AnimationSet) cVar.f220a).getAnimations();
        for (int i = 0; i < animations.size(); i++) {
            if (animations.get(i) instanceof AlphaAnimation) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    static boolean m290a(Animator animator) {
        if (animator == null) {
            return false;
        }
        if (animator instanceof ValueAnimator) {
            PropertyValuesHolder[] values = ((ValueAnimator) animator).getValues();
            for (PropertyValuesHolder propertyName : values) {
                if ("alpha".equals(propertyName.getPropertyName())) {
                    return true;
                }
            }
        } else if (animator instanceof AnimatorSet) {
            ArrayList<Animator> childAnimations = ((AnimatorSet) animator).getChildAnimations();
            for (int i = 0; i < childAnimations.size(); i++) {
                if (m290a(childAnimations.get(i))) {
                    return true;
                }
            }
        }
        return false;
    }

    /* renamed from: a */
    static boolean m292a(View view, C0079c cVar) {
        if (view == null || cVar == null || Build.VERSION.SDK_INT < 19 || view.getLayerType() != 0 || !C0469x.m1519b(view) || !m291a(cVar)) {
            return false;
        }
        return true;
    }

    /* renamed from: a */
    private void m286a(RuntimeException runtimeException) {
        Log.e("FragmentManager", runtimeException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new C0456q("FragmentManager"));
        if (this.f191m != null) {
            try {
                this.f191m.mo341a("  ", (FileDescriptor) null, printWriter, new String[0]);
            } catch (Exception e) {
                Log.e("FragmentManager", "Failed dumping state", e);
            }
        } else {
            try {
                mo382a("  ", (FileDescriptor) null, printWriter, new String[0]);
            } catch (Exception e2) {
                Log.e("FragmentManager", "Failed dumping state", e2);
            }
        }
        throw runtimeException;
    }

    /* renamed from: a */
    public C0091o mo381a() {
        return new C0045b(this);
    }

    /* renamed from: b */
    public boolean mo383b() {
        m304y();
        return m293a((String) null, -1, 0);
    }

    /* renamed from: a */
    private boolean m293a(String str, int i, int i2) {
        C0067j peekChildFragmentManager;
        mo449g();
        m299c(true);
        if (this.f194p != null && i < 0 && str == null && (peekChildFragmentManager = this.f194p.peekChildFragmentManager()) != null && peekChildFragmentManager.mo383b()) {
            return true;
        }
        boolean a = mo423a(this.f201x, this.f202y, str, i, i2);
        if (a) {
            this.f181c = true;
            try {
                m296b(this.f201x, this.f202y);
            } finally {
                m305z();
            }
        }
        mo450h();
        m279C();
        return a;
    }

    /* renamed from: a */
    public void mo407a(Bundle bundle, String str, C0051e eVar) {
        if (eVar.mIndex < 0) {
            m286a((RuntimeException) new IllegalStateException("Fragment " + eVar + " is not currently in the FragmentManager"));
        }
        bundle.putInt(str, eVar.mIndex);
    }

    /* renamed from: a */
    public C0051e mo402a(Bundle bundle, String str) {
        int i = bundle.getInt(str, -1);
        if (i == -1) {
            return null;
        }
        C0051e eVar = this.f184f.get(i);
        if (eVar == null) {
            m286a((RuntimeException) new IllegalStateException("Fragment no longer exists for key " + str + ": index " + i));
        }
        return eVar;
    }

    /* renamed from: c */
    public List<C0051e> mo384c() {
        List<C0051e> list;
        if (this.f183e.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.f183e) {
            list = (List) this.f183e.clone();
        }
        return list;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        if (this.f193o != null) {
            C0455p.m1460a(this.f193o, sb);
        } else {
            C0455p.m1460a(this.f191m, sb);
        }
        sb.append("}}");
        return sb.toString();
    }

    /* renamed from: a */
    public void mo382a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        int size3;
        int size4;
        int size5;
        String str2 = str + "    ";
        if (this.f184f != null && (size5 = this.f184f.size()) > 0) {
            printWriter.print(str);
            printWriter.print("Active Fragments in ");
            printWriter.print(Integer.toHexString(System.identityHashCode(this)));
            printWriter.println(":");
            for (int i = 0; i < size5; i++) {
                C0051e valueAt = this.f184f.valueAt(i);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.println(valueAt);
                if (valueAt != null) {
                    valueAt.dump(str2, fileDescriptor, printWriter, strArr);
                }
            }
        }
        int size6 = this.f183e.size();
        if (size6 > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i2 = 0; i2 < size6; i2++) {
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(this.f183e.get(i2).toString());
            }
        }
        if (this.f186h != null && (size4 = this.f186h.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i3 = 0; i3 < size4; i3++) {
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i3);
                printWriter.print(": ");
                printWriter.println(this.f186h.get(i3).toString());
            }
        }
        if (this.f185g != null && (size3 = this.f185g.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i4 = 0; i4 < size3; i4++) {
                C0045b bVar = this.f185g.get(i4);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i4);
                printWriter.print(": ");
                printWriter.println(bVar.toString());
                bVar.mo108a(str2, fileDescriptor, printWriter, strArr);
            }
        }
        synchronized (this) {
            if (this.f187i != null && (size2 = this.f187i.size()) > 0) {
                printWriter.print(str);
                printWriter.println("Back Stack Indices:");
                for (int i5 = 0; i5 < size2; i5++) {
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i5);
                    printWriter.print(": ");
                    printWriter.println(this.f187i.get(i5));
                }
            }
            if (this.f188j != null && this.f188j.size() > 0) {
                printWriter.print(str);
                printWriter.print("mAvailBackStackIndices: ");
                printWriter.println(Arrays.toString(this.f188j.toArray()));
            }
        }
        if (this.f180b != null && (size = this.f180b.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Pending Actions:");
            for (int i6 = 0; i6 < size; i6++) {
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i6);
                printWriter.print(": ");
                printWriter.println(this.f180b.get(i6));
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f191m);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f192n);
        if (this.f193o != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f193o);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f190l);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.f196s);
        printWriter.print(" mStopped=");
        printWriter.print(this.f197t);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.f198u);
        if (this.f195r) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.f195r);
        }
        if (this.f199v != null) {
            printWriter.print(str);
            printWriter.print("  mNoTransactionsBecause=");
            printWriter.println(this.f199v);
        }
    }

    /* renamed from: a */
    static C0079c m282a(Context context, float f, float f2, float f3, float f4) {
        AnimationSet animationSet = new AnimationSet(false);
        ScaleAnimation scaleAnimation = new ScaleAnimation(f, f2, f, f2, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setInterpolator(f168F);
        scaleAnimation.setDuration(220);
        animationSet.addAnimation(scaleAnimation);
        AlphaAnimation alphaAnimation = new AlphaAnimation(f3, f4);
        alphaAnimation.setInterpolator(f169G);
        alphaAnimation.setDuration(220);
        animationSet.addAnimation(alphaAnimation);
        return new C0079c((Animation) animationSet);
    }

    /* renamed from: a */
    static C0079c m281a(Context context, float f, float f2) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(f, f2);
        alphaAnimation.setInterpolator(f169G);
        alphaAnimation.setDuration(220);
        return new C0079c((Animation) alphaAnimation);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public C0079c mo403a(C0051e eVar, int i, boolean z, int i2) {
        int b;
        int nextAnim = eVar.getNextAnim();
        Animation onCreateAnimation = eVar.onCreateAnimation(i, z, nextAnim);
        if (onCreateAnimation != null) {
            return new C0079c(onCreateAnimation);
        }
        Animator onCreateAnimator = eVar.onCreateAnimator(i, z, nextAnim);
        if (onCreateAnimator != null) {
            return new C0079c(onCreateAnimator);
        }
        if (nextAnim != 0) {
            boolean equals = "anim".equals(this.f191m.mo377i().getResources().getResourceTypeName(nextAnim));
            boolean z2 = false;
            if (equals) {
                try {
                    Animation loadAnimation = AnimationUtils.loadAnimation(this.f191m.mo377i(), nextAnim);
                    if (loadAnimation != null) {
                        return new C0079c(loadAnimation);
                    }
                    z2 = true;
                } catch (Resources.NotFoundException e) {
                    throw e;
                } catch (RuntimeException unused) {
                }
            }
            if (!z2) {
                try {
                    Animator loadAnimator = AnimatorInflater.loadAnimator(this.f191m.mo377i(), nextAnim);
                    if (loadAnimator != null) {
                        return new C0079c(loadAnimator);
                    }
                } catch (RuntimeException e2) {
                    if (equals) {
                        throw e2;
                    }
                    Animation loadAnimation2 = AnimationUtils.loadAnimation(this.f191m.mo377i(), nextAnim);
                    if (loadAnimation2 != null) {
                        return new C0079c(loadAnimation2);
                    }
                }
            }
        }
        if (i == 0 || (b = m294b(i, z)) < 0) {
            return null;
        }
        switch (b) {
            case 1:
                return m282a(this.f191m.mo377i(), 1.125f, 1.0f, 0.0f, 1.0f);
            case 2:
                return m282a(this.f191m.mo377i(), 1.0f, 0.975f, 1.0f, 0.0f);
            case 3:
                return m282a(this.f191m.mo377i(), 0.975f, 1.0f, 0.0f, 1.0f);
            case 4:
                return m282a(this.f191m.mo377i(), 1.0f, 1.075f, 1.0f, 0.0f);
            case 5:
                return m281a(this.f191m.mo377i(), 0.0f, 1.0f);
            case 6:
                return m281a(this.f191m.mo377i(), 1.0f, 0.0f);
            default:
                if (i2 == 0 && this.f191m.mo348e()) {
                    i2 = this.f191m.mo349f();
                }
                return i2 == 0 ? null : null;
        }
    }

    /* renamed from: a */
    public void mo410a(C0051e eVar) {
        if (!eVar.mDeferStart) {
            return;
        }
        if (this.f181c) {
            this.f200w = true;
            return;
        }
        eVar.mDeferStart = false;
        mo411a(eVar, this.f190l, 0, 0, false);
    }

    /* renamed from: b */
    private static void m295b(View view, C0079c cVar) {
        if (view != null && cVar != null && m292a(view, cVar)) {
            if (cVar.f221b != null) {
                cVar.f221b.addListener(new C0080d(view));
                return;
            }
            Animation.AnimationListener a = m283a(cVar.f220a);
            view.setLayerType(2, (Paint) null);
            cVar.f220a.setAnimationListener(new C0076a(view, a));
        }
    }

    /* renamed from: a */
    private static Animation.AnimationListener m283a(Animation animation) {
        try {
            if (f173q == null) {
                f173q = Animation.class.getDeclaredField("mListener");
                f173q.setAccessible(true);
            }
            return (Animation.AnimationListener) f173q.get(animation);
        } catch (NoSuchFieldException e) {
            Log.e("FragmentManager", "No field with the name mListener is found in Animation class", e);
            return null;
        } catch (IllegalAccessException e2) {
            Log.e("FragmentManager", "Cannot access Animation's mListener field", e2);
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public boolean mo419a(int i) {
        return this.f190l >= i;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v0, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v0, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v1, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v1, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v2, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v2, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v3, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v4, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v3, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v4, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v5, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v6, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v7, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v8, resolved type: int} */
    /* access modifiers changed from: package-private */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:100:?, code lost:
        r1 = r7.getResources().getResourceName(r7.mContainerId);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:101:0x020f, code lost:
        r1 = org.apache.cordova.networkinformation.NetworkManager.TYPE_UNKNOWN;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x0241, code lost:
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:144:0x031c, code lost:
        if (r11 >= 3) goto L_0x033e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:146:0x0320, code lost:
        if (f172a == false) goto L_0x0338;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:147:0x0322, code lost:
        android.util.Log.v("FragmentManager", "movefrom STARTED: " + r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:148:0x0338, code lost:
        r7.performStop();
        mo443e(r7, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:149:0x033e, code lost:
        if (r11 >= 2) goto L_0x03c5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:151:0x0342, code lost:
        if (f172a == false) goto L_0x035a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:152:0x0344, code lost:
        android.util.Log.v("FragmentManager", "movefrom ACTIVITY_CREATED: " + r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:154:0x035c, code lost:
        if (r7.mView == null) goto L_0x036d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:156:0x0364, code lost:
        if (r6.f191m.mo342a(r7) == false) goto L_0x036d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:158:0x0368, code lost:
        if (r7.mSavedViewState != null) goto L_0x036d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:159:0x036a, code lost:
        mo462m(r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:160:0x036d, code lost:
        r7.performDestroyView();
        mo446f(r7, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:161:0x0375, code lost:
        if (r7.mView == null) goto L_0x03b6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:163:0x0379, code lost:
        if (r7.mContainer == null) goto L_0x03b6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:164:0x037b, code lost:
        r7.mContainer.endViewTransition(r7.mView);
        r7.mView.clearAnimation();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:165:0x038a, code lost:
        if (r6.f190l <= 0) goto L_0x03a7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:167:0x038e, code lost:
        if (r6.f198u != false) goto L_0x03a7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:169:0x0396, code lost:
        if (r7.mView.getVisibility() != 0) goto L_0x03a7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:171:0x039c, code lost:
        if (r7.mPostponedAlpha < 0.0f) goto L_0x03a7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:172:0x039e, code lost:
        r0 = mo403a(r7, r17, false, r18);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:173:0x03a7, code lost:
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:174:0x03a8, code lost:
        r7.mPostponedAlpha = 0.0f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:175:0x03aa, code lost:
        if (r0 == null) goto L_0x03af;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:176:0x03ac, code lost:
        m284a(r7, r0, r11);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:177:0x03af, code lost:
        r7.mContainer.removeView(r7.mView);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:178:0x03b6, code lost:
        r7.mContainer = null;
        r7.mView = null;
        r7.mViewLifecycleOwner = null;
        r7.mViewLifecycleOwnerLiveData.mo23a(null);
        r7.mInnerView = null;
        r7.mInLayout = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:179:0x03c5, code lost:
        if (r11 >= 1) goto L_0x043b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:181:0x03c9, code lost:
        if (r6.f198u == false) goto L_0x03ec;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:183:0x03cf, code lost:
        if (r7.getAnimatingAway() == null) goto L_0x03dc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:184:0x03d1, code lost:
        r0 = r7.getAnimatingAway();
        r7.setAnimatingAway((android.view.View) null);
        r0.clearAnimation();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:186:0x03e0, code lost:
        if (r7.getAnimator() == null) goto L_0x03ec;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:187:0x03e2, code lost:
        r0 = r7.getAnimator();
        r7.setAnimator((android.animation.Animator) null);
        r0.cancel();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:189:0x03f0, code lost:
        if (r7.getAnimatingAway() != null) goto L_0x0437;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:191:0x03f6, code lost:
        if (r7.getAnimator() == null) goto L_0x03f9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:193:0x03fb, code lost:
        if (f172a == false) goto L_0x0413;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:194:0x03fd, code lost:
        android.util.Log.v("FragmentManager", "movefrom CREATED: " + r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:196:0x0415, code lost:
        if (r7.mRetaining != false) goto L_0x041e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:197:0x0417, code lost:
        r7.performDestroy();
        mo448g(r7, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:198:0x041e, code lost:
        r7.mState = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:199:0x0420, code lost:
        r7.performDetach();
        mo452h(r7, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:200:0x0426, code lost:
        if (r19 != false) goto L_0x043b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:202:0x042a, code lost:
        if (r7.mRetaining != false) goto L_0x0430;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:203:0x042c, code lost:
        mo447g(r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:204:0x0430, code lost:
        r7.mHost = null;
        r7.mParentFragment = null;
        r7.mFragmentManager = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:205:0x0437, code lost:
        r7.setStateAfterAnimating(r11);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x01aa, code lost:
        mo435c(r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:84:0x01ad, code lost:
        if (r11 <= 1) goto L_0x02a4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:86:0x01b1, code lost:
        if (f172a == false) goto L_0x01c9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x01b3, code lost:
        android.util.Log.v("FragmentManager", "moveto ACTIVITY_CREATED: " + r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x01cb, code lost:
        if (r7.mFromLayout != false) goto L_0x028f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x01cf, code lost:
        if (r7.mContainerId == 0) goto L_0x0241;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:0x01d4, code lost:
        if (r7.mContainerId != -1) goto L_0x01f4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:94:0x01d6, code lost:
        m286a((java.lang.RuntimeException) new java.lang.IllegalArgumentException("Cannot create fragment " + r7 + " for a container view with no id"));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:95:0x01f4, code lost:
        r0 = (android.view.ViewGroup) r6.f192n.mo289a(r7.mContainerId);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:96:0x01fe, code lost:
        if (r0 != null) goto L_0x0242;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:0x0202, code lost:
        if (r7.mRestored != false) goto L_0x0242;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:209:0x0440  */
    /* JADX WARNING: Removed duplicated region for block: B:211:? A[RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo411a(android.support.p001v4.app.C0051e r15, int r16, int r17, int r18, boolean r19) {
        /*
            r14 = this;
            r6 = r14
            r7 = r15
            boolean r0 = r7.mAdded
            r8 = 1
            if (r0 == 0) goto L_0x000f
            boolean r0 = r7.mDetached
            if (r0 == 0) goto L_0x000c
            goto L_0x000f
        L_0x000c:
            r0 = r16
            goto L_0x0014
        L_0x000f:
            r0 = r16
            if (r0 <= r8) goto L_0x0014
            r0 = r8
        L_0x0014:
            boolean r1 = r7.mRemoving
            if (r1 == 0) goto L_0x002a
            int r1 = r7.mState
            if (r0 <= r1) goto L_0x002a
            int r0 = r7.mState
            if (r0 != 0) goto L_0x0028
            boolean r0 = r7.isInBackStack()
            if (r0 == 0) goto L_0x0028
            r0 = r8
            goto L_0x002a
        L_0x0028:
            int r0 = r7.mState
        L_0x002a:
            boolean r1 = r7.mDeferStart
            r9 = 3
            r10 = 2
            if (r1 == 0) goto L_0x0038
            int r1 = r7.mState
            if (r1 >= r9) goto L_0x0038
            if (r0 <= r10) goto L_0x0038
            r11 = r10
            goto L_0x0039
        L_0x0038:
            r11 = r0
        L_0x0039:
            int r0 = r7.mState
            r12 = 0
            r13 = 0
            if (r0 > r11) goto L_0x02ee
            boolean r0 = r7.mFromLayout
            if (r0 == 0) goto L_0x0048
            boolean r0 = r7.mInLayout
            if (r0 != 0) goto L_0x0048
            return
        L_0x0048:
            android.view.View r0 = r7.getAnimatingAway()
            if (r0 != 0) goto L_0x0054
            android.animation.Animator r0 = r7.getAnimator()
            if (r0 == 0) goto L_0x0066
        L_0x0054:
            r7.setAnimatingAway(r12)
            r7.setAnimator(r12)
            int r2 = r7.getStateAfterAnimating()
            r3 = 0
            r4 = 0
            r5 = 1
            r0 = r6
            r1 = r7
            r0.mo411a((android.support.p001v4.app.C0051e) r1, (int) r2, (int) r3, (int) r4, (boolean) r5)
        L_0x0066:
            int r0 = r7.mState
            switch(r0) {
                case 0: goto L_0x006d;
                case 1: goto L_0x01aa;
                case 2: goto L_0x02a4;
                case 3: goto L_0x02c6;
                default: goto L_0x006b;
            }
        L_0x006b:
            goto L_0x043b
        L_0x006d:
            if (r11 <= 0) goto L_0x01aa
            boolean r0 = f172a
            if (r0 == 0) goto L_0x0089
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveto CREATED: "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x0089:
            android.os.Bundle r0 = r7.mSavedFragmentState
            if (r0 == 0) goto L_0x00e0
            android.os.Bundle r0 = r7.mSavedFragmentState
            android.support.v4.app.i r1 = r6.f191m
            android.content.Context r1 = r1.mo377i()
            java.lang.ClassLoader r1 = r1.getClassLoader()
            r0.setClassLoader(r1)
            android.os.Bundle r0 = r7.mSavedFragmentState
            java.lang.String r1 = "android:view_state"
            android.util.SparseArray r0 = r0.getSparseParcelableArray(r1)
            r7.mSavedViewState = r0
            android.os.Bundle r0 = r7.mSavedFragmentState
            java.lang.String r1 = "android:target_state"
            android.support.v4.app.e r0 = r6.mo402a((android.os.Bundle) r0, (java.lang.String) r1)
            r7.mTarget = r0
            android.support.v4.app.e r0 = r7.mTarget
            if (r0 == 0) goto L_0x00be
            android.os.Bundle r0 = r7.mSavedFragmentState
            java.lang.String r1 = "android:target_req_state"
            int r0 = r0.getInt(r1, r13)
            r7.mTargetRequestCode = r0
        L_0x00be:
            java.lang.Boolean r0 = r7.mSavedUserVisibleHint
            if (r0 == 0) goto L_0x00cd
            java.lang.Boolean r0 = r7.mSavedUserVisibleHint
            boolean r0 = r0.booleanValue()
            r7.mUserVisibleHint = r0
            r7.mSavedUserVisibleHint = r12
            goto L_0x00d7
        L_0x00cd:
            android.os.Bundle r0 = r7.mSavedFragmentState
            java.lang.String r1 = "android:user_visible_hint"
            boolean r0 = r0.getBoolean(r1, r8)
            r7.mUserVisibleHint = r0
        L_0x00d7:
            boolean r0 = r7.mUserVisibleHint
            if (r0 != 0) goto L_0x00e0
            r7.mDeferStart = r8
            if (r11 <= r10) goto L_0x00e0
            r11 = r10
        L_0x00e0:
            android.support.v4.app.i r0 = r6.f191m
            r7.mHost = r0
            android.support.v4.app.e r0 = r6.f193o
            r7.mParentFragment = r0
            android.support.v4.app.e r0 = r6.f193o
            if (r0 == 0) goto L_0x00f1
            android.support.v4.app.e r0 = r6.f193o
            android.support.v4.app.k r0 = r0.mChildFragmentManager
            goto L_0x00f7
        L_0x00f1:
            android.support.v4.app.i r0 = r6.f191m
            android.support.v4.app.k r0 = r0.mo379k()
        L_0x00f7:
            r7.mFragmentManager = r0
            android.support.v4.app.e r0 = r7.mTarget
            if (r0 == 0) goto L_0x0141
            android.util.SparseArray<android.support.v4.app.e> r0 = r6.f184f
            android.support.v4.app.e r1 = r7.mTarget
            int r1 = r1.mIndex
            java.lang.Object r0 = r0.get(r1)
            android.support.v4.app.e r1 = r7.mTarget
            if (r0 == r1) goto L_0x0131
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Fragment "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r2 = " declared target fragment "
            r1.append(r2)
            android.support.v4.app.e r2 = r7.mTarget
            r1.append(r2)
            java.lang.String r2 = " that does not belong to this FragmentManager!"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0131:
            android.support.v4.app.e r0 = r7.mTarget
            int r0 = r0.mState
            if (r0 >= r8) goto L_0x0141
            android.support.v4.app.e r1 = r7.mTarget
            r2 = 1
            r3 = 0
            r4 = 0
            r5 = 1
            r0 = r6
            r0.mo411a((android.support.p001v4.app.C0051e) r1, (int) r2, (int) r3, (int) r4, (boolean) r5)
        L_0x0141:
            android.support.v4.app.i r0 = r6.f191m
            android.content.Context r0 = r0.mo377i()
            r6.mo412a((android.support.p001v4.app.C0051e) r7, (android.content.Context) r0, (boolean) r13)
            r7.mCalled = r13
            android.support.v4.app.i r0 = r6.f191m
            android.content.Context r0 = r0.mo377i()
            r7.onAttach((android.content.Context) r0)
            boolean r0 = r7.mCalled
            if (r0 != 0) goto L_0x0175
            android.support.v4.app.aa r0 = new android.support.v4.app.aa
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Fragment "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r2 = " did not call through to super.onAttach()"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0175:
            android.support.v4.app.e r0 = r7.mParentFragment
            if (r0 != 0) goto L_0x017f
            android.support.v4.app.i r0 = r6.f191m
            r0.mo345b(r7)
            goto L_0x0184
        L_0x017f:
            android.support.v4.app.e r0 = r7.mParentFragment
            r0.onAttachFragment(r7)
        L_0x0184:
            android.support.v4.app.i r0 = r6.f191m
            android.content.Context r0 = r0.mo377i()
            r6.mo428b((android.support.p001v4.app.C0051e) r7, (android.content.Context) r0, (boolean) r13)
            boolean r0 = r7.mIsCreated
            if (r0 != 0) goto L_0x01a1
            android.os.Bundle r0 = r7.mSavedFragmentState
            r6.mo413a((android.support.p001v4.app.C0051e) r7, (android.os.Bundle) r0, (boolean) r13)
            android.os.Bundle r0 = r7.mSavedFragmentState
            r7.performCreate(r0)
            android.os.Bundle r0 = r7.mSavedFragmentState
            r6.mo429b((android.support.p001v4.app.C0051e) r7, (android.os.Bundle) r0, (boolean) r13)
            goto L_0x01a8
        L_0x01a1:
            android.os.Bundle r0 = r7.mSavedFragmentState
            r7.restoreChildFragmentState(r0)
            r7.mState = r8
        L_0x01a8:
            r7.mRetaining = r13
        L_0x01aa:
            r6.mo435c((android.support.p001v4.app.C0051e) r7)
            if (r11 <= r8) goto L_0x02a4
            boolean r0 = f172a
            if (r0 == 0) goto L_0x01c9
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveto ACTIVITY_CREATED: "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x01c9:
            boolean r0 = r7.mFromLayout
            if (r0 != 0) goto L_0x028f
            int r0 = r7.mContainerId
            if (r0 == 0) goto L_0x0241
            int r0 = r7.mContainerId
            r1 = -1
            if (r0 != r1) goto L_0x01f4
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Cannot create fragment "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r2 = " for a container view with no id"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            r6.m286a((java.lang.RuntimeException) r0)
        L_0x01f4:
            android.support.v4.app.g r0 = r6.f192n
            int r1 = r7.mContainerId
            android.view.View r0 = r0.mo289a(r1)
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            if (r0 != 0) goto L_0x0242
            boolean r1 = r7.mRestored
            if (r1 != 0) goto L_0x0242
            android.content.res.Resources r1 = r7.getResources()     // Catch:{ NotFoundException -> 0x020f }
            int r2 = r7.mContainerId     // Catch:{ NotFoundException -> 0x020f }
            java.lang.String r1 = r1.getResourceName(r2)     // Catch:{ NotFoundException -> 0x020f }
            goto L_0x0211
        L_0x020f:
            java.lang.String r1 = "unknown"
        L_0x0211:
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "No view found for id 0x"
            r3.append(r4)
            int r4 = r7.mContainerId
            java.lang.String r4 = java.lang.Integer.toHexString(r4)
            r3.append(r4)
            java.lang.String r4 = " ("
            r3.append(r4)
            r3.append(r1)
            java.lang.String r1 = ") for fragment "
            r3.append(r1)
            r3.append(r7)
            java.lang.String r1 = r3.toString()
            r2.<init>(r1)
            r6.m286a((java.lang.RuntimeException) r2)
            goto L_0x0242
        L_0x0241:
            r0 = r12
        L_0x0242:
            r7.mContainer = r0
            android.os.Bundle r1 = r7.mSavedFragmentState
            android.view.LayoutInflater r1 = r7.performGetLayoutInflater(r1)
            android.os.Bundle r2 = r7.mSavedFragmentState
            r7.performCreateView(r1, r0, r2)
            android.view.View r1 = r7.mView
            if (r1 == 0) goto L_0x028d
            android.view.View r1 = r7.mView
            r7.mInnerView = r1
            android.view.View r1 = r7.mView
            r1.setSaveFromParentEnabled(r13)
            if (r0 == 0) goto L_0x0263
            android.view.View r1 = r7.mView
            r0.addView(r1)
        L_0x0263:
            boolean r0 = r7.mHidden
            if (r0 == 0) goto L_0x026e
            android.view.View r0 = r7.mView
            r1 = 8
            r0.setVisibility(r1)
        L_0x026e:
            android.view.View r0 = r7.mView
            android.os.Bundle r1 = r7.mSavedFragmentState
            r7.onViewCreated(r0, r1)
            android.view.View r0 = r7.mView
            android.os.Bundle r1 = r7.mSavedFragmentState
            r6.mo414a((android.support.p001v4.app.C0051e) r7, (android.view.View) r0, (android.os.Bundle) r1, (boolean) r13)
            android.view.View r0 = r7.mView
            int r0 = r0.getVisibility()
            if (r0 != 0) goto L_0x0289
            android.view.ViewGroup r0 = r7.mContainer
            if (r0 == 0) goto L_0x0289
            goto L_0x028a
        L_0x0289:
            r8 = r13
        L_0x028a:
            r7.mIsNewlyAdded = r8
            goto L_0x028f
        L_0x028d:
            r7.mInnerView = r12
        L_0x028f:
            android.os.Bundle r0 = r7.mSavedFragmentState
            r7.performActivityCreated(r0)
            android.os.Bundle r0 = r7.mSavedFragmentState
            r6.mo436c(r7, r0, r13)
            android.view.View r0 = r7.mView
            if (r0 == 0) goto L_0x02a2
            android.os.Bundle r0 = r7.mSavedFragmentState
            r7.restoreViewState(r0)
        L_0x02a2:
            r7.mSavedFragmentState = r12
        L_0x02a4:
            if (r11 <= r10) goto L_0x02c6
            boolean r0 = f172a
            if (r0 == 0) goto L_0x02c0
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveto STARTED: "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x02c0:
            r7.performStart()
            r6.mo430b((android.support.p001v4.app.C0051e) r7, (boolean) r13)
        L_0x02c6:
            if (r11 <= r9) goto L_0x043b
            boolean r0 = f172a
            if (r0 == 0) goto L_0x02e2
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveto RESUMED: "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x02e2:
            r7.performResume()
            r6.mo437c((android.support.p001v4.app.C0051e) r7, (boolean) r13)
            r7.mSavedFragmentState = r12
            r7.mSavedViewState = r12
            goto L_0x043b
        L_0x02ee:
            int r0 = r7.mState
            if (r0 <= r11) goto L_0x043b
            int r0 = r7.mState
            switch(r0) {
                case 1: goto L_0x03c5;
                case 2: goto L_0x033e;
                case 3: goto L_0x031c;
                case 4: goto L_0x02f9;
                default: goto L_0x02f7;
            }
        L_0x02f7:
            goto L_0x043b
        L_0x02f9:
            r0 = 4
            if (r11 >= r0) goto L_0x031c
            boolean r0 = f172a
            if (r0 == 0) goto L_0x0316
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "movefrom RESUMED: "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x0316:
            r7.performPause()
            r6.mo440d(r7, r13)
        L_0x031c:
            if (r11 >= r9) goto L_0x033e
            boolean r0 = f172a
            if (r0 == 0) goto L_0x0338
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "movefrom STARTED: "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x0338:
            r7.performStop()
            r6.mo443e(r7, r13)
        L_0x033e:
            if (r11 >= r10) goto L_0x03c5
            boolean r0 = f172a
            if (r0 == 0) goto L_0x035a
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "movefrom ACTIVITY_CREATED: "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x035a:
            android.view.View r0 = r7.mView
            if (r0 == 0) goto L_0x036d
            android.support.v4.app.i r0 = r6.f191m
            boolean r0 = r0.mo342a((android.support.p001v4.app.C0051e) r7)
            if (r0 == 0) goto L_0x036d
            android.util.SparseArray<android.os.Parcelable> r0 = r7.mSavedViewState
            if (r0 != 0) goto L_0x036d
            r6.mo462m(r7)
        L_0x036d:
            r7.performDestroyView()
            r6.mo446f(r7, r13)
            android.view.View r0 = r7.mView
            if (r0 == 0) goto L_0x03b6
            android.view.ViewGroup r0 = r7.mContainer
            if (r0 == 0) goto L_0x03b6
            android.view.ViewGroup r0 = r7.mContainer
            android.view.View r1 = r7.mView
            r0.endViewTransition(r1)
            android.view.View r0 = r7.mView
            r0.clearAnimation()
            int r0 = r6.f190l
            r1 = 0
            if (r0 <= 0) goto L_0x03a7
            boolean r0 = r6.f198u
            if (r0 != 0) goto L_0x03a7
            android.view.View r0 = r7.mView
            int r0 = r0.getVisibility()
            if (r0 != 0) goto L_0x03a7
            float r0 = r7.mPostponedAlpha
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L_0x03a7
            r0 = r17
            r2 = r18
            android.support.v4.app.k$c r0 = r6.mo403a((android.support.p001v4.app.C0051e) r7, (int) r0, (boolean) r13, (int) r2)
            goto L_0x03a8
        L_0x03a7:
            r0 = r12
        L_0x03a8:
            r7.mPostponedAlpha = r1
            if (r0 == 0) goto L_0x03af
            r6.m284a((android.support.p001v4.app.C0051e) r7, (android.support.p001v4.app.C0070k.C0079c) r0, (int) r11)
        L_0x03af:
            android.view.ViewGroup r0 = r7.mContainer
            android.view.View r1 = r7.mView
            r0.removeView(r1)
        L_0x03b6:
            r7.mContainer = r12
            r7.mView = r12
            r7.mViewLifecycleOwner = r12
            android.arch.lifecycle.j<android.arch.lifecycle.e> r0 = r7.mViewLifecycleOwnerLiveData
            r0.mo23a(r12)
            r7.mInnerView = r12
            r7.mInLayout = r13
        L_0x03c5:
            if (r11 >= r8) goto L_0x043b
            boolean r0 = r6.f198u
            if (r0 == 0) goto L_0x03ec
            android.view.View r0 = r7.getAnimatingAway()
            if (r0 == 0) goto L_0x03dc
            android.view.View r0 = r7.getAnimatingAway()
            r7.setAnimatingAway(r12)
            r0.clearAnimation()
            goto L_0x03ec
        L_0x03dc:
            android.animation.Animator r0 = r7.getAnimator()
            if (r0 == 0) goto L_0x03ec
            android.animation.Animator r0 = r7.getAnimator()
            r7.setAnimator(r12)
            r0.cancel()
        L_0x03ec:
            android.view.View r0 = r7.getAnimatingAway()
            if (r0 != 0) goto L_0x0437
            android.animation.Animator r0 = r7.getAnimator()
            if (r0 == 0) goto L_0x03f9
            goto L_0x0437
        L_0x03f9:
            boolean r0 = f172a
            if (r0 == 0) goto L_0x0413
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "movefrom CREATED: "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r0, r1)
        L_0x0413:
            boolean r0 = r7.mRetaining
            if (r0 != 0) goto L_0x041e
            r7.performDestroy()
            r6.mo448g(r7, r13)
            goto L_0x0420
        L_0x041e:
            r7.mState = r13
        L_0x0420:
            r7.performDetach()
            r6.mo452h(r7, r13)
            if (r19 != 0) goto L_0x043b
            boolean r0 = r7.mRetaining
            if (r0 != 0) goto L_0x0430
            r6.mo447g(r7)
            goto L_0x043b
        L_0x0430:
            r7.mHost = r12
            r7.mParentFragment = r12
            r7.mFragmentManager = r12
            goto L_0x043b
        L_0x0437:
            r7.setStateAfterAnimating(r11)
            goto L_0x043c
        L_0x043b:
            r8 = r11
        L_0x043c:
            int r0 = r7.mState
            if (r0 == r8) goto L_0x046f
            java.lang.String r0 = "FragmentManager"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "moveToState: Fragment state for "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r2 = " not updated inline; "
            r1.append(r2)
            java.lang.String r2 = "expected state "
            r1.append(r2)
            r1.append(r8)
            java.lang.String r2 = " found "
            r1.append(r2)
            int r2 = r7.mState
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.w(r0, r1)
            r7.mState = r8
        L_0x046f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.app.C0070k.mo411a(android.support.v4.app.e, int, int, int, boolean):void");
    }

    /* renamed from: a */
    private void m284a(final C0051e eVar, C0079c cVar, int i) {
        final View view = eVar.mView;
        final ViewGroup viewGroup = eVar.mContainer;
        viewGroup.startViewTransition(view);
        eVar.setStateAfterAnimating(i);
        if (cVar.f220a != null) {
            C0081e eVar2 = new C0081e(cVar.f220a, viewGroup, view);
            eVar.setAnimatingAway(eVar.mView);
            eVar2.setAnimationListener(new C0078b(m283a((Animation) eVar2)) {
                public void onAnimationEnd(Animation animation) {
                    super.onAnimationEnd(animation);
                    viewGroup.post(new Runnable() {
                        public void run() {
                            if (eVar.getAnimatingAway() != null) {
                                eVar.setAnimatingAway((View) null);
                                C0070k.this.mo411a(eVar, eVar.getStateAfterAnimating(), 0, 0, false);
                            }
                        }
                    });
                }
            });
            m295b(view, cVar);
            eVar.mView.startAnimation(eVar2);
            return;
        }
        Animator animator = cVar.f221b;
        eVar.setAnimator(cVar.f221b);
        animator.addListener(new AnimatorListenerAdapter() {
            public void onAnimationEnd(Animator animator) {
                viewGroup.endViewTransition(view);
                Animator animator2 = eVar.getAnimator();
                eVar.setAnimator((Animator) null);
                if (animator2 != null && viewGroup.indexOfChild(view) < 0) {
                    C0070k.this.mo411a(eVar, eVar.getStateAfterAnimating(), 0, 0, false);
                }
            }
        });
        animator.setTarget(eVar.mView);
        m295b(eVar.mView, cVar);
        animator.start();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo427b(C0051e eVar) {
        mo411a(eVar, this.f190l, 0, 0, false);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo435c(C0051e eVar) {
        if (eVar.mFromLayout && !eVar.mPerformedCreateView) {
            eVar.performCreateView(eVar.performGetLayoutInflater(eVar.mSavedFragmentState), (ViewGroup) null, eVar.mSavedFragmentState);
            if (eVar.mView != null) {
                eVar.mInnerView = eVar.mView;
                eVar.mView.setSaveFromParentEnabled(false);
                if (eVar.mHidden) {
                    eVar.mView.setVisibility(8);
                }
                eVar.onViewCreated(eVar.mView, eVar.mSavedFragmentState);
                mo414a(eVar, eVar.mView, eVar.mSavedFragmentState, false);
                return;
            }
            eVar.mInnerView = null;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo438d(final C0051e eVar) {
        if (eVar.mView != null) {
            C0079c a = mo403a(eVar, eVar.getNextTransition(), !eVar.mHidden, eVar.getNextTransitionStyle());
            if (a == null || a.f221b == null) {
                if (a != null) {
                    m295b(eVar.mView, a);
                    eVar.mView.startAnimation(a.f220a);
                    a.f220a.start();
                }
                eVar.mView.setVisibility((!eVar.mHidden || eVar.isHideReplaced()) ? 0 : 8);
                if (eVar.isHideReplaced()) {
                    eVar.setHideReplaced(false);
                }
            } else {
                a.f221b.setTarget(eVar.mView);
                if (!eVar.mHidden) {
                    eVar.mView.setVisibility(0);
                } else if (eVar.isHideReplaced()) {
                    eVar.setHideReplaced(false);
                } else {
                    final ViewGroup viewGroup = eVar.mContainer;
                    final View view = eVar.mView;
                    viewGroup.startViewTransition(view);
                    a.f221b.addListener(new AnimatorListenerAdapter() {
                        public void onAnimationEnd(Animator animator) {
                            viewGroup.endViewTransition(view);
                            animator.removeListener(this);
                            if (eVar.mView != null) {
                                eVar.mView.setVisibility(8);
                            }
                        }
                    });
                }
                m295b(eVar.mView, a);
                a.f221b.start();
            }
        }
        if (eVar.mAdded && eVar.mHasMenu && eVar.mMenuVisible) {
            this.f195r = true;
        }
        eVar.mHiddenChanged = false;
        eVar.onHiddenChanged(eVar.mHidden);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0033, code lost:
        r0 = r0.mView;
        r1 = r11.mContainer;
        r0 = r1.indexOfChild(r0);
     */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo442e(android.support.p001v4.app.C0051e r11) {
        /*
            r10 = this;
            if (r11 != 0) goto L_0x0003
            return
        L_0x0003:
            int r0 = r10.f190l
            boolean r1 = r11.mRemoving
            r2 = 0
            r3 = 1
            if (r1 == 0) goto L_0x001a
            boolean r1 = r11.isInBackStack()
            if (r1 == 0) goto L_0x0016
            int r0 = java.lang.Math.min(r0, r3)
            goto L_0x001a
        L_0x0016:
            int r0 = java.lang.Math.min(r0, r2)
        L_0x001a:
            r6 = r0
            int r7 = r11.getNextTransition()
            int r8 = r11.getNextTransitionStyle()
            r9 = 0
            r4 = r10
            r5 = r11
            r4.mo411a((android.support.p001v4.app.C0051e) r5, (int) r6, (int) r7, (int) r8, (boolean) r9)
            android.view.View r0 = r11.mView
            if (r0 == 0) goto L_0x0090
            android.support.v4.app.e r0 = r10.m303p(r11)
            if (r0 == 0) goto L_0x004b
            android.view.View r0 = r0.mView
            android.view.ViewGroup r1 = r11.mContainer
            int r0 = r1.indexOfChild(r0)
            android.view.View r4 = r11.mView
            int r4 = r1.indexOfChild(r4)
            if (r4 >= r0) goto L_0x004b
            r1.removeViewAt(r4)
            android.view.View r4 = r11.mView
            r1.addView(r4, r0)
        L_0x004b:
            boolean r0 = r11.mIsNewlyAdded
            if (r0 == 0) goto L_0x0090
            android.view.ViewGroup r0 = r11.mContainer
            if (r0 == 0) goto L_0x0090
            float r0 = r11.mPostponedAlpha
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x0061
            android.view.View r0 = r11.mView
            float r4 = r11.mPostponedAlpha
            r0.setAlpha(r4)
        L_0x0061:
            r11.mPostponedAlpha = r1
            r11.mIsNewlyAdded = r2
            int r0 = r11.getNextTransition()
            int r1 = r11.getNextTransitionStyle()
            android.support.v4.app.k$c r0 = r10.mo403a((android.support.p001v4.app.C0051e) r11, (int) r0, (boolean) r3, (int) r1)
            if (r0 == 0) goto L_0x0090
            android.view.View r1 = r11.mView
            m295b((android.view.View) r1, (android.support.p001v4.app.C0070k.C0079c) r0)
            android.view.animation.Animation r1 = r0.f220a
            if (r1 == 0) goto L_0x0084
            android.view.View r1 = r11.mView
            android.view.animation.Animation r0 = r0.f220a
            r1.startAnimation(r0)
            goto L_0x0090
        L_0x0084:
            android.animation.Animator r1 = r0.f221b
            android.view.View r2 = r11.mView
            r1.setTarget(r2)
            android.animation.Animator r0 = r0.f221b
            r0.start()
        L_0x0090:
            boolean r0 = r11.mHiddenChanged
            if (r0 == 0) goto L_0x0097
            r10.mo438d((android.support.p001v4.app.C0051e) r11)
        L_0x0097:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.app.C0070k.mo442e(android.support.v4.app.e):void");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo405a(int i, boolean z) {
        if (this.f191m == null && i != 0) {
            throw new IllegalStateException("No activity");
        } else if (z || i != this.f190l) {
            this.f190l = i;
            if (this.f184f != null) {
                int size = this.f183e.size();
                for (int i2 = 0; i2 < size; i2++) {
                    mo442e(this.f183e.get(i2));
                }
                int size2 = this.f184f.size();
                for (int i3 = 0; i3 < size2; i3++) {
                    C0051e valueAt = this.f184f.valueAt(i3);
                    if (valueAt != null && ((valueAt.mRemoving || valueAt.mDetached) && !valueAt.mIsNewlyAdded)) {
                        mo442e(valueAt);
                    }
                }
                mo441e();
                if (this.f195r && this.f191m != null && this.f190l == 4) {
                    this.f191m.mo347d();
                    this.f195r = false;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo441e() {
        if (this.f184f != null) {
            for (int i = 0; i < this.f184f.size(); i++) {
                C0051e valueAt = this.f184f.valueAt(i);
                if (valueAt != null) {
                    mo410a(valueAt);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo445f(C0051e eVar) {
        if (eVar.mIndex < 0) {
            int i = this.f182d;
            this.f182d = i + 1;
            eVar.setIndex(i, this.f193o);
            if (this.f184f == null) {
                this.f184f = new SparseArray<>();
            }
            this.f184f.put(eVar.mIndex, eVar);
            if (f172a) {
                Log.v("FragmentManager", "Allocated fragment index " + eVar);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public void mo447g(C0051e eVar) {
        if (eVar.mIndex >= 0) {
            if (f172a) {
                Log.v("FragmentManager", "Freeing fragment index " + eVar);
            }
            this.f184f.put(eVar.mIndex, (Object) null);
            eVar.initState();
        }
    }

    /* renamed from: a */
    public void mo415a(C0051e eVar, boolean z) {
        if (f172a) {
            Log.v("FragmentManager", "add: " + eVar);
        }
        mo445f(eVar);
        if (eVar.mDetached) {
            return;
        }
        if (this.f183e.contains(eVar)) {
            throw new IllegalStateException("Fragment already added: " + eVar);
        }
        synchronized (this.f183e) {
            this.f183e.add(eVar);
        }
        eVar.mAdded = true;
        eVar.mRemoving = false;
        if (eVar.mView == null) {
            eVar.mHiddenChanged = false;
        }
        if (eVar.mHasMenu && eVar.mMenuVisible) {
            this.f195r = true;
        }
        if (z) {
            mo427b(eVar);
        }
    }

    /* renamed from: h */
    public void mo451h(C0051e eVar) {
        if (f172a) {
            Log.v("FragmentManager", "remove: " + eVar + " nesting=" + eVar.mBackStackNesting);
        }
        boolean z = !eVar.isInBackStack();
        if (!eVar.mDetached || z) {
            synchronized (this.f183e) {
                this.f183e.remove(eVar);
            }
            if (eVar.mHasMenu && eVar.mMenuVisible) {
                this.f195r = true;
            }
            eVar.mAdded = false;
            eVar.mRemoving = true;
        }
    }

    /* renamed from: i */
    public void mo454i(C0051e eVar) {
        if (f172a) {
            Log.v("FragmentManager", "hide: " + eVar);
        }
        if (!eVar.mHidden) {
            eVar.mHidden = true;
            eVar.mHiddenChanged = true ^ eVar.mHiddenChanged;
        }
    }

    /* renamed from: j */
    public void mo456j(C0051e eVar) {
        if (f172a) {
            Log.v("FragmentManager", "show: " + eVar);
        }
        if (eVar.mHidden) {
            eVar.mHidden = false;
            eVar.mHiddenChanged = !eVar.mHiddenChanged;
        }
    }

    /* renamed from: k */
    public void mo458k(C0051e eVar) {
        if (f172a) {
            Log.v("FragmentManager", "detach: " + eVar);
        }
        if (!eVar.mDetached) {
            eVar.mDetached = true;
            if (eVar.mAdded) {
                if (f172a) {
                    Log.v("FragmentManager", "remove from detach: " + eVar);
                }
                synchronized (this.f183e) {
                    this.f183e.remove(eVar);
                }
                if (eVar.mHasMenu && eVar.mMenuVisible) {
                    this.f195r = true;
                }
                eVar.mAdded = false;
            }
        }
    }

    /* renamed from: l */
    public void mo460l(C0051e eVar) {
        if (f172a) {
            Log.v("FragmentManager", "attach: " + eVar);
        }
        if (eVar.mDetached) {
            eVar.mDetached = false;
            if (eVar.mAdded) {
                return;
            }
            if (this.f183e.contains(eVar)) {
                throw new IllegalStateException("Fragment already added: " + eVar);
            }
            if (f172a) {
                Log.v("FragmentManager", "add from attach: " + eVar);
            }
            synchronized (this.f183e) {
                this.f183e.add(eVar);
            }
            eVar.mAdded = true;
            if (eVar.mHasMenu && eVar.mMenuVisible) {
                this.f195r = true;
            }
        }
    }

    /* renamed from: b */
    public C0051e mo424b(int i) {
        for (int size = this.f183e.size() - 1; size >= 0; size--) {
            C0051e eVar = this.f183e.get(size);
            if (eVar != null && eVar.mFragmentId == i) {
                return eVar;
            }
        }
        if (this.f184f == null) {
            return null;
        }
        for (int size2 = this.f184f.size() - 1; size2 >= 0; size2--) {
            C0051e valueAt = this.f184f.valueAt(size2);
            if (valueAt != null && valueAt.mFragmentId == i) {
                return valueAt;
            }
        }
        return null;
    }

    /* renamed from: a */
    public C0051e mo380a(String str) {
        if (str != null) {
            for (int size = this.f183e.size() - 1; size >= 0; size--) {
                C0051e eVar = this.f183e.get(size);
                if (eVar != null && str.equals(eVar.mTag)) {
                    return eVar;
                }
            }
        }
        if (this.f184f == null || str == null) {
            return null;
        }
        for (int size2 = this.f184f.size() - 1; size2 >= 0; size2--) {
            C0051e valueAt = this.f184f.valueAt(size2);
            if (valueAt != null && str.equals(valueAt.mTag)) {
                return valueAt;
            }
        }
        return null;
    }

    /* renamed from: b */
    public C0051e mo425b(String str) {
        C0051e findFragmentByWho;
        if (this.f184f == null || str == null) {
            return null;
        }
        for (int size = this.f184f.size() - 1; size >= 0; size--) {
            C0051e valueAt = this.f184f.valueAt(size);
            if (valueAt != null && (findFragmentByWho = valueAt.findFragmentByWho(str)) != null) {
                return findFragmentByWho;
            }
        }
        return null;
    }

    /* renamed from: y */
    private void m304y() {
        if (mo385d()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        } else if (this.f199v != null) {
            throw new IllegalStateException("Can not perform this action inside of " + this.f199v);
        }
    }

    /* renamed from: d */
    public boolean mo385d() {
        return this.f196s || this.f197t;
    }

    /* renamed from: a */
    public void mo417a(C0084h hVar, boolean z) {
        if (!z) {
            m304y();
        }
        synchronized (this) {
            if (!this.f198u) {
                if (this.f191m != null) {
                    if (this.f180b == null) {
                        this.f180b = new ArrayList<>();
                    }
                    this.f180b.add(hVar);
                    mo444f();
                    return;
                }
            }
            if (!z) {
                throw new IllegalStateException("Activity has been destroyed");
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo444f() {
        synchronized (this) {
            boolean z = false;
            boolean z2 = this.f176C != null && !this.f176C.isEmpty();
            if (this.f180b != null && this.f180b.size() == 1) {
                z = true;
            }
            if (z2 || z) {
                this.f191m.mo378j().removeCallbacks(this.f178E);
                this.f191m.mo378j().post(this.f178E);
            }
        }
    }

    /* renamed from: a */
    public int mo401a(C0045b bVar) {
        synchronized (this) {
            if (this.f188j != null) {
                if (this.f188j.size() > 0) {
                    int intValue = this.f188j.remove(this.f188j.size() - 1).intValue();
                    if (f172a) {
                        Log.v("FragmentManager", "Adding back stack index " + intValue + " with " + bVar);
                    }
                    this.f187i.set(intValue, bVar);
                    return intValue;
                }
            }
            if (this.f187i == null) {
                this.f187i = new ArrayList<>();
            }
            int size = this.f187i.size();
            if (f172a) {
                Log.v("FragmentManager", "Setting back stack index " + size + " to " + bVar);
            }
            this.f187i.add(bVar);
            return size;
        }
    }

    /* renamed from: a */
    public void mo404a(int i, C0045b bVar) {
        synchronized (this) {
            if (this.f187i == null) {
                this.f187i = new ArrayList<>();
            }
            int size = this.f187i.size();
            if (i < size) {
                if (f172a) {
                    Log.v("FragmentManager", "Setting back stack index " + i + " to " + bVar);
                }
                this.f187i.set(i, bVar);
            } else {
                while (size < i) {
                    this.f187i.add((Object) null);
                    if (this.f188j == null) {
                        this.f188j = new ArrayList<>();
                    }
                    if (f172a) {
                        Log.v("FragmentManager", "Adding available back stack index " + size);
                    }
                    this.f188j.add(Integer.valueOf(size));
                    size++;
                }
                if (f172a) {
                    Log.v("FragmentManager", "Adding back stack index " + i + " with " + bVar);
                }
                this.f187i.add(bVar);
            }
        }
    }

    /* renamed from: c */
    public void mo434c(int i) {
        synchronized (this) {
            this.f187i.set(i, (Object) null);
            if (this.f188j == null) {
                this.f188j = new ArrayList<>();
            }
            if (f172a) {
                Log.v("FragmentManager", "Freeing back stack index " + i);
            }
            this.f188j.add(Integer.valueOf(i));
        }
    }

    /* renamed from: c */
    private void m299c(boolean z) {
        if (this.f181c) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        } else if (this.f191m == null) {
            throw new IllegalStateException("Fragment host has been destroyed");
        } else if (Looper.myLooper() != this.f191m.mo378j().getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        } else {
            if (!z) {
                m304y();
            }
            if (this.f201x == null) {
                this.f201x = new ArrayList<>();
                this.f202y = new ArrayList<>();
            }
            this.f181c = true;
            try {
                m287a((ArrayList<C0045b>) null, (ArrayList<Boolean>) null);
            } finally {
                this.f181c = false;
            }
        }
    }

    /* renamed from: z */
    private void m305z() {
        this.f181c = false;
        this.f202y.clear();
        this.f201x.clear();
    }

    /* JADX INFO: finally extract failed */
    /* renamed from: g */
    public boolean mo449g() {
        m299c(true);
        boolean z = false;
        while (m300c(this.f201x, this.f202y)) {
            this.f181c = true;
            try {
                m296b(this.f201x, this.f202y);
                m305z();
                z = true;
            } catch (Throwable th) {
                m305z();
                throw th;
            }
        }
        mo450h();
        m279C();
        return z;
    }

    /* renamed from: a */
    private void m287a(ArrayList<C0045b> arrayList, ArrayList<Boolean> arrayList2) {
        int indexOf;
        int indexOf2;
        int size = this.f176C == null ? 0 : this.f176C.size();
        int i = 0;
        while (i < size) {
            C0085i iVar = this.f176C.get(i);
            if (arrayList != null && !iVar.f231a && (indexOf2 = arrayList.indexOf(iVar.f232b)) != -1 && arrayList2.get(indexOf2).booleanValue()) {
                iVar.mo494e();
            } else if (iVar.mo492c() || (arrayList != null && iVar.f232b.mo110a(arrayList, 0, arrayList.size()))) {
                this.f176C.remove(i);
                i--;
                size--;
                if (arrayList == null || iVar.f231a || (indexOf = arrayList.indexOf(iVar.f232b)) == -1 || !arrayList2.get(indexOf).booleanValue()) {
                    iVar.mo493d();
                } else {
                    iVar.mo494e();
                }
            }
            i++;
        }
    }

    /* renamed from: b */
    private void m296b(ArrayList<C0045b> arrayList, ArrayList<Boolean> arrayList2) {
        if (arrayList != null && !arrayList.isEmpty()) {
            if (arrayList2 == null || arrayList.size() != arrayList2.size()) {
                throw new IllegalStateException("Internal error with the back stack records");
            }
            m287a(arrayList, arrayList2);
            int size = arrayList.size();
            int i = 0;
            int i2 = 0;
            while (i < size) {
                if (!arrayList.get(i).f101t) {
                    if (i2 != i) {
                        m288a(arrayList, arrayList2, i2, i);
                    }
                    i2 = i + 1;
                    if (arrayList2.get(i).booleanValue()) {
                        while (i2 < size && arrayList2.get(i2).booleanValue() && !arrayList.get(i2).f101t) {
                            i2++;
                        }
                    }
                    m288a(arrayList, arrayList2, i, i2);
                    i = i2 - 1;
                }
                i++;
            }
            if (i2 != size) {
                m288a(arrayList, arrayList2, i2, size);
            }
        }
    }

    /* renamed from: a */
    private void m288a(ArrayList<C0045b> arrayList, ArrayList<Boolean> arrayList2, int i, int i2) {
        int i3;
        ArrayList<C0045b> arrayList3 = arrayList;
        ArrayList<Boolean> arrayList4 = arrayList2;
        int i4 = i;
        int i5 = i2;
        boolean z = arrayList3.get(i4).f101t;
        if (this.f203z == null) {
            this.f203z = new ArrayList<>();
        } else {
            this.f203z.clear();
        }
        this.f203z.addAll(this.f183e);
        C0051e w = mo477w();
        boolean z2 = false;
        for (int i6 = i4; i6 < i5; i6++) {
            C0045b bVar = arrayList3.get(i6);
            if (!arrayList4.get(i6).booleanValue()) {
                w = bVar.mo102a(this.f203z, w);
            } else {
                w = bVar.mo113b(this.f203z, w);
            }
            z2 = z2 || bVar.f90i;
        }
        this.f203z.clear();
        if (!z) {
            C0092p.m419a(this, arrayList3, arrayList4, i4, i5, false);
        }
        m297b(arrayList, arrayList2, i, i2);
        if (z) {
            C0320n nVar = new C0320n();
            m298b((C0320n<C0051e>) nVar);
            int a = m280a(arrayList3, arrayList4, i4, i5, (C0320n<C0051e>) nVar);
            m289a((C0320n<C0051e>) nVar);
            i3 = a;
        } else {
            i3 = i5;
        }
        if (i3 != i4 && z) {
            C0092p.m419a(this, arrayList3, arrayList4, i4, i3, true);
            mo405a(this.f190l, true);
        }
        while (i4 < i5) {
            C0045b bVar2 = arrayList3.get(i4);
            if (arrayList4.get(i4).booleanValue() && bVar2.f94m >= 0) {
                mo434c(bVar2.f94m);
                bVar2.f94m = -1;
            }
            bVar2.mo104a();
            i4++;
        }
        if (z2) {
            mo453i();
        }
    }

    /* renamed from: a */
    private void m289a(C0320n<C0051e> nVar) {
        int size = nVar.size();
        for (int i = 0; i < size; i++) {
            C0051e b = nVar.mo3486b(i);
            if (!b.mAdded) {
                View view = b.getView();
                b.mPostponedAlpha = view.getAlpha();
                view.setAlpha(0.0f);
            }
        }
    }

    /* renamed from: a */
    private int m280a(ArrayList<C0045b> arrayList, ArrayList<Boolean> arrayList2, int i, int i2, C0320n<C0051e> nVar) {
        int i3 = i2;
        for (int i4 = i2 - 1; i4 >= i; i4--) {
            C0045b bVar = arrayList.get(i4);
            boolean booleanValue = arrayList2.get(i4).booleanValue();
            if (bVar.mo117d() && !bVar.mo110a(arrayList, i4 + 1, i2)) {
                if (this.f176C == null) {
                    this.f176C = new ArrayList<>();
                }
                C0085i iVar = new C0085i(bVar, booleanValue);
                this.f176C.add(iVar);
                bVar.mo107a((C0051e.C0057c) iVar);
                if (booleanValue) {
                    bVar.mo116c();
                } else {
                    bVar.mo114b(false);
                }
                i3--;
                if (i4 != i3) {
                    arrayList.remove(i4);
                    arrayList.add(i3, bVar);
                }
                m298b(nVar);
            }
        }
        return i3;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo409a(C0045b bVar, boolean z, boolean z2, boolean z3) {
        if (z) {
            bVar.mo114b(z3);
        } else {
            bVar.mo116c();
        }
        ArrayList arrayList = new ArrayList(1);
        ArrayList arrayList2 = new ArrayList(1);
        arrayList.add(bVar);
        arrayList2.add(Boolean.valueOf(z));
        if (z2) {
            C0092p.m419a(this, (ArrayList<C0045b>) arrayList, (ArrayList<Boolean>) arrayList2, 0, 1, true);
        }
        if (z3) {
            mo405a(this.f190l, true);
        }
        if (this.f184f != null) {
            int size = this.f184f.size();
            for (int i = 0; i < size; i++) {
                C0051e valueAt = this.f184f.valueAt(i);
                if (valueAt != null && valueAt.mView != null && valueAt.mIsNewlyAdded && bVar.mo115b(valueAt.mContainerId)) {
                    if (valueAt.mPostponedAlpha > 0.0f) {
                        valueAt.mView.setAlpha(valueAt.mPostponedAlpha);
                    }
                    if (z3) {
                        valueAt.mPostponedAlpha = 0.0f;
                    } else {
                        valueAt.mPostponedAlpha = -1.0f;
                        valueAt.mIsNewlyAdded = false;
                    }
                }
            }
        }
    }

    /* renamed from: p */
    private C0051e m303p(C0051e eVar) {
        ViewGroup viewGroup = eVar.mContainer;
        View view = eVar.mView;
        if (viewGroup == null || view == null) {
            return null;
        }
        for (int indexOf = this.f183e.indexOf(eVar) - 1; indexOf >= 0; indexOf--) {
            C0051e eVar2 = this.f183e.get(indexOf);
            if (eVar2.mContainer == viewGroup && eVar2.mView != null) {
                return eVar2;
            }
        }
        return null;
    }

    /* renamed from: b */
    private static void m297b(ArrayList<C0045b> arrayList, ArrayList<Boolean> arrayList2, int i, int i2) {
        while (i < i2) {
            C0045b bVar = arrayList.get(i);
            boolean z = true;
            if (arrayList2.get(i).booleanValue()) {
                bVar.mo105a(-1);
                if (i != i2 - 1) {
                    z = false;
                }
                bVar.mo114b(z);
            } else {
                bVar.mo105a(1);
                bVar.mo116c();
            }
            i++;
        }
    }

    /* renamed from: b */
    private void m298b(C0320n<C0051e> nVar) {
        if (this.f190l >= 1) {
            int min = Math.min(this.f190l, 3);
            int size = this.f183e.size();
            for (int i = 0; i < size; i++) {
                C0051e eVar = this.f183e.get(i);
                if (eVar.mState < min) {
                    mo411a(eVar, min, eVar.getNextAnim(), eVar.getNextTransition(), false);
                    if (eVar.mView != null && !eVar.mHidden && eVar.mIsNewlyAdded) {
                        nVar.add(eVar);
                    }
                }
            }
        }
    }

    /* renamed from: A */
    private void m277A() {
        if (this.f176C != null) {
            while (!this.f176C.isEmpty()) {
                this.f176C.remove(0).mo493d();
            }
        }
    }

    /* renamed from: B */
    private void m278B() {
        int size = this.f184f == null ? 0 : this.f184f.size();
        for (int i = 0; i < size; i++) {
            C0051e valueAt = this.f184f.valueAt(i);
            if (valueAt != null) {
                if (valueAt.getAnimatingAway() != null) {
                    int stateAfterAnimating = valueAt.getStateAfterAnimating();
                    View animatingAway = valueAt.getAnimatingAway();
                    Animation animation = animatingAway.getAnimation();
                    if (animation != null) {
                        animation.cancel();
                        animatingAway.clearAnimation();
                    }
                    valueAt.setAnimatingAway((View) null);
                    mo411a(valueAt, stateAfterAnimating, 0, 0, false);
                } else if (valueAt.getAnimator() != null) {
                    valueAt.getAnimator().end();
                }
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x003b, code lost:
        return false;
     */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m300c(java.util.ArrayList<android.support.p001v4.app.C0045b> r5, java.util.ArrayList<java.lang.Boolean> r6) {
        /*
            r4 = this;
            monitor-enter(r4)
            java.util.ArrayList<android.support.v4.app.k$h> r0 = r4.f180b     // Catch:{ all -> 0x003c }
            r1 = 0
            if (r0 == 0) goto L_0x003a
            java.util.ArrayList<android.support.v4.app.k$h> r0 = r4.f180b     // Catch:{ all -> 0x003c }
            int r0 = r0.size()     // Catch:{ all -> 0x003c }
            if (r0 != 0) goto L_0x000f
            goto L_0x003a
        L_0x000f:
            java.util.ArrayList<android.support.v4.app.k$h> r0 = r4.f180b     // Catch:{ all -> 0x003c }
            int r0 = r0.size()     // Catch:{ all -> 0x003c }
            r2 = r1
        L_0x0016:
            if (r1 >= r0) goto L_0x0028
            java.util.ArrayList<android.support.v4.app.k$h> r3 = r4.f180b     // Catch:{ all -> 0x003c }
            java.lang.Object r3 = r3.get(r1)     // Catch:{ all -> 0x003c }
            android.support.v4.app.k$h r3 = (android.support.p001v4.app.C0070k.C0084h) r3     // Catch:{ all -> 0x003c }
            boolean r3 = r3.mo111a(r5, r6)     // Catch:{ all -> 0x003c }
            r2 = r2 | r3
            int r1 = r1 + 1
            goto L_0x0016
        L_0x0028:
            java.util.ArrayList<android.support.v4.app.k$h> r5 = r4.f180b     // Catch:{ all -> 0x003c }
            r5.clear()     // Catch:{ all -> 0x003c }
            android.support.v4.app.i r5 = r4.f191m     // Catch:{ all -> 0x003c }
            android.os.Handler r5 = r5.mo378j()     // Catch:{ all -> 0x003c }
            java.lang.Runnable r6 = r4.f178E     // Catch:{ all -> 0x003c }
            r5.removeCallbacks(r6)     // Catch:{ all -> 0x003c }
            monitor-exit(r4)     // Catch:{ all -> 0x003c }
            return r2
        L_0x003a:
            monitor-exit(r4)     // Catch:{ all -> 0x003c }
            return r1
        L_0x003c:
            r5 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x003c }
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.app.C0070k.m300c(java.util.ArrayList, java.util.ArrayList):boolean");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo450h() {
        if (this.f200w) {
            this.f200w = false;
            mo441e();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: i */
    public void mo453i() {
        if (this.f189k != null) {
            for (int i = 0; i < this.f189k.size(); i++) {
                this.f189k.get(i).mo400a();
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo426b(C0045b bVar) {
        if (this.f185g == null) {
            this.f185g = new ArrayList<>();
        }
        this.f185g.add(bVar);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public boolean mo423a(ArrayList<C0045b> arrayList, ArrayList<Boolean> arrayList2, String str, int i, int i2) {
        int i3;
        if (this.f185g == null) {
            return false;
        }
        if (str == null && i < 0 && (i2 & 1) == 0) {
            int size = this.f185g.size() - 1;
            if (size < 0) {
                return false;
            }
            arrayList.add(this.f185g.remove(size));
            arrayList2.add(true);
        } else {
            if (str != null || i >= 0) {
                int size2 = this.f185g.size() - 1;
                while (i3 >= 0) {
                    C0045b bVar = this.f185g.get(i3);
                    if ((str != null && str.equals(bVar.mo118e())) || (i >= 0 && i == bVar.f94m)) {
                        break;
                    }
                    size2 = i3 - 1;
                }
                if (i3 < 0) {
                    return false;
                }
                if ((i2 & 1) != 0) {
                    i3--;
                    while (i3 >= 0) {
                        C0045b bVar2 = this.f185g.get(i3);
                        if ((str == null || !str.equals(bVar2.mo118e())) && (i < 0 || i != bVar2.f94m)) {
                            break;
                        }
                        i3--;
                    }
                }
            } else {
                i3 = -1;
            }
            if (i3 == this.f185g.size() - 1) {
                return false;
            }
            for (int size3 = this.f185g.size() - 1; size3 > i3; size3--) {
                arrayList.add(this.f185g.remove(size3));
                arrayList2.add(true);
            }
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: j */
    public C0086l mo455j() {
        m285a(this.f177D);
        return this.f177D;
    }

    /* renamed from: a */
    private static void m285a(C0086l lVar) {
        if (lVar != null) {
            List<C0051e> a = lVar.mo495a();
            if (a != null) {
                for (C0051e eVar : a) {
                    eVar.mRetaining = true;
                }
            }
            List<C0086l> b = lVar.mo496b();
            if (b != null) {
                for (C0086l a2 : b) {
                    m285a(a2);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: k */
    public void mo457k() {
        ArrayList arrayList;
        ArrayList arrayList2;
        ArrayList arrayList3;
        C0086l lVar;
        if (this.f184f != null) {
            arrayList3 = null;
            arrayList2 = null;
            arrayList = null;
            for (int i = 0; i < this.f184f.size(); i++) {
                C0051e valueAt = this.f184f.valueAt(i);
                if (valueAt != null) {
                    if (valueAt.mRetainInstance) {
                        if (arrayList3 == null) {
                            arrayList3 = new ArrayList();
                        }
                        arrayList3.add(valueAt);
                        valueAt.mTargetIndex = valueAt.mTarget != null ? valueAt.mTarget.mIndex : -1;
                        if (f172a) {
                            Log.v("FragmentManager", "retainNonConfig: keeping retained " + valueAt);
                        }
                    }
                    if (valueAt.mChildFragmentManager != null) {
                        valueAt.mChildFragmentManager.mo457k();
                        lVar = valueAt.mChildFragmentManager.f177D;
                    } else {
                        lVar = valueAt.mChildNonConfig;
                    }
                    if (arrayList2 == null && lVar != null) {
                        arrayList2 = new ArrayList(this.f184f.size());
                        for (int i2 = 0; i2 < i; i2++) {
                            arrayList2.add((Object) null);
                        }
                    }
                    if (arrayList2 != null) {
                        arrayList2.add(lVar);
                    }
                    if (arrayList == null && valueAt.mViewModelStore != null) {
                        arrayList = new ArrayList(this.f184f.size());
                        for (int i3 = 0; i3 < i; i3++) {
                            arrayList.add((Object) null);
                        }
                    }
                    if (arrayList != null) {
                        arrayList.add(valueAt.mViewModelStore);
                    }
                }
            }
        } else {
            arrayList3 = null;
            arrayList2 = null;
            arrayList = null;
        }
        if (arrayList3 == null && arrayList2 == null && arrayList == null) {
            this.f177D = null;
        } else {
            this.f177D = new C0086l(arrayList3, arrayList2, arrayList);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: m */
    public void mo462m(C0051e eVar) {
        if (eVar.mInnerView != null) {
            if (this.f175B == null) {
                this.f175B = new SparseArray<>();
            } else {
                this.f175B.clear();
            }
            eVar.mInnerView.saveHierarchyState(this.f175B);
            if (this.f175B.size() > 0) {
                eVar.mSavedViewState = this.f175B;
                this.f175B = null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: n */
    public Bundle mo463n(C0051e eVar) {
        Bundle bundle;
        if (this.f174A == null) {
            this.f174A = new Bundle();
        }
        eVar.performSaveInstanceState(this.f174A);
        mo439d(eVar, this.f174A, false);
        if (!this.f174A.isEmpty()) {
            bundle = this.f174A;
            this.f174A = null;
        } else {
            bundle = null;
        }
        if (eVar.mView != null) {
            mo462m(eVar);
        }
        if (eVar.mSavedViewState != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", eVar.mSavedViewState);
        }
        if (!eVar.mUserVisibleHint) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", eVar.mUserVisibleHint);
        }
        return bundle;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: l */
    public Parcelable mo459l() {
        int[] iArr;
        int size;
        m277A();
        m278B();
        mo449g();
        this.f196s = true;
        C0047c[] cVarArr = null;
        this.f177D = null;
        if (this.f184f == null || this.f184f.size() <= 0) {
            return null;
        }
        int size2 = this.f184f.size();
        C0089n[] nVarArr = new C0089n[size2];
        boolean z = false;
        for (int i = 0; i < size2; i++) {
            C0051e valueAt = this.f184f.valueAt(i);
            if (valueAt != null) {
                if (valueAt.mIndex < 0) {
                    m286a((RuntimeException) new IllegalStateException("Failure saving state: active " + valueAt + " has cleared index: " + valueAt.mIndex));
                }
                C0089n nVar = new C0089n(valueAt);
                nVarArr[i] = nVar;
                if (valueAt.mState <= 0 || nVar.f252k != null) {
                    nVar.f252k = valueAt.mSavedFragmentState;
                } else {
                    nVar.f252k = mo463n(valueAt);
                    if (valueAt.mTarget != null) {
                        if (valueAt.mTarget.mIndex < 0) {
                            m286a((RuntimeException) new IllegalStateException("Failure saving state: " + valueAt + " has target not in fragment manager: " + valueAt.mTarget));
                        }
                        if (nVar.f252k == null) {
                            nVar.f252k = new Bundle();
                        }
                        mo407a(nVar.f252k, "android:target_state", valueAt.mTarget);
                        if (valueAt.mTargetRequestCode != 0) {
                            nVar.f252k.putInt("android:target_req_state", valueAt.mTargetRequestCode);
                        }
                    }
                }
                if (f172a) {
                    Log.v("FragmentManager", "Saved state of " + valueAt + ": " + nVar.f252k);
                }
                z = true;
            }
        }
        if (!z) {
            if (f172a) {
                Log.v("FragmentManager", "saveAllState: no fragments!");
            }
            return null;
        }
        int size3 = this.f183e.size();
        if (size3 > 0) {
            iArr = new int[size3];
            for (int i2 = 0; i2 < size3; i2++) {
                iArr[i2] = this.f183e.get(i2).mIndex;
                if (iArr[i2] < 0) {
                    m286a((RuntimeException) new IllegalStateException("Failure saving state: active " + this.f183e.get(i2) + " has cleared index: " + iArr[i2]));
                }
                if (f172a) {
                    Log.v("FragmentManager", "saveAllState: adding fragment #" + i2 + ": " + this.f183e.get(i2));
                }
            }
        } else {
            iArr = null;
        }
        if (this.f185g != null && (size = this.f185g.size()) > 0) {
            cVarArr = new C0047c[size];
            for (int i3 = 0; i3 < size; i3++) {
                cVarArr[i3] = new C0047c(this.f185g.get(i3));
                if (f172a) {
                    Log.v("FragmentManager", "saveAllState: adding back stack #" + i3 + ": " + this.f185g.get(i3));
                }
            }
        }
        C0087m mVar = new C0087m();
        mVar.f237a = nVarArr;
        mVar.f238b = iArr;
        mVar.f239c = cVarArr;
        if (this.f194p != null) {
            mVar.f240d = this.f194p.mIndex;
        }
        mVar.f241e = this.f182d;
        mo457k();
        return mVar;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo408a(Parcelable parcelable, C0086l lVar) {
        List<C0031p> list;
        List<C0086l> list2;
        if (parcelable != null) {
            C0087m mVar = (C0087m) parcelable;
            if (mVar.f237a != null) {
                if (lVar != null) {
                    List<C0051e> a = lVar.mo495a();
                    list2 = lVar.mo496b();
                    list = lVar.mo497c();
                    int size = a != null ? a.size() : 0;
                    for (int i = 0; i < size; i++) {
                        C0051e eVar = a.get(i);
                        if (f172a) {
                            Log.v("FragmentManager", "restoreAllState: re-attaching retained " + eVar);
                        }
                        int i2 = 0;
                        while (i2 < mVar.f237a.length && mVar.f237a[i2].f243b != eVar.mIndex) {
                            i2++;
                        }
                        if (i2 == mVar.f237a.length) {
                            m286a((RuntimeException) new IllegalStateException("Could not find active fragment with index " + eVar.mIndex));
                        }
                        C0089n nVar = mVar.f237a[i2];
                        nVar.f253l = eVar;
                        eVar.mSavedViewState = null;
                        eVar.mBackStackNesting = 0;
                        eVar.mInLayout = false;
                        eVar.mAdded = false;
                        eVar.mTarget = null;
                        if (nVar.f252k != null) {
                            nVar.f252k.setClassLoader(this.f191m.mo377i().getClassLoader());
                            eVar.mSavedViewState = nVar.f252k.getSparseParcelableArray("android:view_state");
                            eVar.mSavedFragmentState = nVar.f252k;
                        }
                    }
                } else {
                    list2 = null;
                    list = null;
                }
                this.f184f = new SparseArray<>(mVar.f237a.length);
                int i3 = 0;
                while (i3 < mVar.f237a.length) {
                    C0089n nVar2 = mVar.f237a[i3];
                    if (nVar2 != null) {
                        C0051e a2 = nVar2.mo504a(this.f191m, this.f192n, this.f193o, (list2 == null || i3 >= list2.size()) ? null : list2.get(i3), (list == null || i3 >= list.size()) ? null : list.get(i3));
                        if (f172a) {
                            Log.v("FragmentManager", "restoreAllState: active #" + i3 + ": " + a2);
                        }
                        this.f184f.put(a2.mIndex, a2);
                        nVar2.f253l = null;
                    }
                    i3++;
                }
                if (lVar != null) {
                    List<C0051e> a3 = lVar.mo495a();
                    int size2 = a3 != null ? a3.size() : 0;
                    for (int i4 = 0; i4 < size2; i4++) {
                        C0051e eVar2 = a3.get(i4);
                        if (eVar2.mTargetIndex >= 0) {
                            eVar2.mTarget = this.f184f.get(eVar2.mTargetIndex);
                            if (eVar2.mTarget == null) {
                                Log.w("FragmentManager", "Re-attaching retained fragment " + eVar2 + " target no longer exists: " + eVar2.mTargetIndex);
                            }
                        }
                    }
                }
                this.f183e.clear();
                if (mVar.f238b != null) {
                    for (int i5 = 0; i5 < mVar.f238b.length; i5++) {
                        C0051e eVar3 = this.f184f.get(mVar.f238b[i5]);
                        if (eVar3 == null) {
                            m286a((RuntimeException) new IllegalStateException("No instantiated fragment for index #" + mVar.f238b[i5]));
                        }
                        eVar3.mAdded = true;
                        if (f172a) {
                            Log.v("FragmentManager", "restoreAllState: added #" + i5 + ": " + eVar3);
                        }
                        if (this.f183e.contains(eVar3)) {
                            throw new IllegalStateException("Already added!");
                        }
                        synchronized (this.f183e) {
                            this.f183e.add(eVar3);
                        }
                    }
                }
                if (mVar.f239c != null) {
                    this.f185g = new ArrayList<>(mVar.f239c.length);
                    for (int i6 = 0; i6 < mVar.f239c.length; i6++) {
                        C0045b a4 = mVar.f239c[i6].mo120a(this);
                        if (f172a) {
                            Log.v("FragmentManager", "restoreAllState: back stack #" + i6 + " (index " + a4.f94m + "): " + a4);
                            PrintWriter printWriter = new PrintWriter(new C0456q("FragmentManager"));
                            a4.mo109a("  ", printWriter, false);
                            printWriter.close();
                        }
                        this.f185g.add(a4);
                        if (a4.f94m >= 0) {
                            mo404a(a4.f94m, a4);
                        }
                    }
                } else {
                    this.f185g = null;
                }
                if (mVar.f240d >= 0) {
                    this.f194p = this.f184f.get(mVar.f240d);
                }
                this.f182d = mVar.f241e;
            }
        }
    }

    /* renamed from: C */
    private void m279C() {
        if (this.f184f != null) {
            for (int size = this.f184f.size() - 1; size >= 0; size--) {
                if (this.f184f.valueAt(size) == null) {
                    this.f184f.delete(this.f184f.keyAt(size));
                }
            }
        }
    }

    /* renamed from: a */
    public void mo416a(C0066i iVar, C0064g gVar, C0051e eVar) {
        if (this.f191m != null) {
            throw new IllegalStateException("Already attached");
        }
        this.f191m = iVar;
        this.f192n = gVar;
        this.f193o = eVar;
    }

    /* renamed from: m */
    public void mo461m() {
        this.f177D = null;
        this.f196s = false;
        this.f197t = false;
        int size = this.f183e.size();
        for (int i = 0; i < size; i++) {
            C0051e eVar = this.f183e.get(i);
            if (eVar != null) {
                eVar.noteStateNotSaved();
            }
        }
    }

    /* renamed from: n */
    public void mo464n() {
        this.f196s = false;
        this.f197t = false;
        m302e(1);
    }

    /* renamed from: o */
    public void mo465o() {
        this.f196s = false;
        this.f197t = false;
        m302e(2);
    }

    /* renamed from: p */
    public void mo469p() {
        this.f196s = false;
        this.f197t = false;
        m302e(3);
    }

    /* renamed from: q */
    public void mo470q() {
        this.f196s = false;
        this.f197t = false;
        m302e(4);
    }

    /* renamed from: r */
    public void mo471r() {
        m302e(3);
    }

    /* renamed from: s */
    public void mo472s() {
        this.f197t = true;
        m302e(2);
    }

    /* renamed from: t */
    public void mo473t() {
        m302e(1);
    }

    /* renamed from: u */
    public void mo475u() {
        this.f198u = true;
        mo449g();
        m302e(0);
        this.f191m = null;
        this.f192n = null;
        this.f193o = null;
    }

    /* JADX INFO: finally extract failed */
    /* renamed from: e */
    private void m302e(int i) {
        try {
            this.f181c = true;
            mo405a(i, false);
            this.f181c = false;
            mo449g();
        } catch (Throwable th) {
            this.f181c = false;
            throw th;
        }
    }

    /* renamed from: a */
    public void mo418a(boolean z) {
        for (int size = this.f183e.size() - 1; size >= 0; size--) {
            C0051e eVar = this.f183e.get(size);
            if (eVar != null) {
                eVar.performMultiWindowModeChanged(z);
            }
        }
    }

    /* renamed from: b */
    public void mo432b(boolean z) {
        for (int size = this.f183e.size() - 1; size >= 0; size--) {
            C0051e eVar = this.f183e.get(size);
            if (eVar != null) {
                eVar.performPictureInPictureModeChanged(z);
            }
        }
    }

    /* renamed from: a */
    public void mo406a(Configuration configuration) {
        for (int i = 0; i < this.f183e.size(); i++) {
            C0051e eVar = this.f183e.get(i);
            if (eVar != null) {
                eVar.performConfigurationChanged(configuration);
            }
        }
    }

    /* renamed from: v */
    public void mo476v() {
        for (int i = 0; i < this.f183e.size(); i++) {
            C0051e eVar = this.f183e.get(i);
            if (eVar != null) {
                eVar.performLowMemory();
            }
        }
    }

    /* renamed from: a */
    public boolean mo421a(Menu menu, MenuInflater menuInflater) {
        if (this.f190l < 1) {
            return false;
        }
        ArrayList<C0051e> arrayList = null;
        boolean z = false;
        for (int i = 0; i < this.f183e.size(); i++) {
            C0051e eVar = this.f183e.get(i);
            if (eVar != null && eVar.performCreateOptionsMenu(menu, menuInflater)) {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                arrayList.add(eVar);
                z = true;
            }
        }
        if (this.f186h != null) {
            for (int i2 = 0; i2 < this.f186h.size(); i2++) {
                C0051e eVar2 = this.f186h.get(i2);
                if (arrayList == null || !arrayList.contains(eVar2)) {
                    eVar2.onDestroyOptionsMenu();
                }
            }
        }
        this.f186h = arrayList;
        return z;
    }

    /* renamed from: a */
    public boolean mo420a(Menu menu) {
        if (this.f190l < 1) {
            return false;
        }
        boolean z = false;
        for (int i = 0; i < this.f183e.size(); i++) {
            C0051e eVar = this.f183e.get(i);
            if (eVar != null && eVar.performPrepareOptionsMenu(menu)) {
                z = true;
            }
        }
        return z;
    }

    /* renamed from: a */
    public boolean mo422a(MenuItem menuItem) {
        if (this.f190l < 1) {
            return false;
        }
        for (int i = 0; i < this.f183e.size(); i++) {
            C0051e eVar = this.f183e.get(i);
            if (eVar != null && eVar.performOptionsItemSelected(menuItem)) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: b */
    public boolean mo433b(MenuItem menuItem) {
        if (this.f190l < 1) {
            return false;
        }
        for (int i = 0; i < this.f183e.size(); i++) {
            C0051e eVar = this.f183e.get(i);
            if (eVar != null && eVar.performContextItemSelected(menuItem)) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: b */
    public void mo431b(Menu menu) {
        if (this.f190l >= 1) {
            for (int i = 0; i < this.f183e.size(); i++) {
                C0051e eVar = this.f183e.get(i);
                if (eVar != null) {
                    eVar.performOptionsMenuClosed(menu);
                }
            }
        }
    }

    /* renamed from: o */
    public void mo466o(C0051e eVar) {
        if (eVar == null || (this.f184f.get(eVar.mIndex) == eVar && (eVar.mHost == null || eVar.getFragmentManager() == this))) {
            this.f194p = eVar;
            return;
        }
        throw new IllegalArgumentException("Fragment " + eVar + " is not an active fragment of FragmentManager " + this);
    }

    /* renamed from: w */
    public C0051e mo477w() {
        return this.f194p;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo412a(C0051e eVar, Context context, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo412a(eVar, context, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo387a((C0067j) this, eVar, context);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo428b(C0051e eVar, Context context, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo428b(eVar, context, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo391b((C0067j) this, eVar, context);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo413a(C0051e eVar, Bundle bundle, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo413a(eVar, bundle, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo388a((C0067j) this, eVar, bundle);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo429b(C0051e eVar, Bundle bundle, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo429b(eVar, bundle, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo392b((C0067j) this, eVar, bundle);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo436c(C0051e eVar, Bundle bundle, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo436c(eVar, bundle, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo394c(this, eVar, bundle);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo414a(C0051e eVar, View view, Bundle bundle, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo414a(eVar, view, bundle, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo389a(this, eVar, view, bundle);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo430b(C0051e eVar, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo430b(eVar, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo386a(this, eVar);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public void mo437c(C0051e eVar, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo437c(eVar, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo390b(this, eVar);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo440d(C0051e eVar, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo440d(eVar, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo393c(this, eVar);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: e */
    public void mo443e(C0051e eVar, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo443e(eVar, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo395d(this, eVar);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: d */
    public void mo439d(C0051e eVar, Bundle bundle, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo439d(eVar, bundle, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo396d(this, eVar, bundle);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: f */
    public void mo446f(C0051e eVar, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo446f(eVar, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo397e(this, eVar);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: g */
    public void mo448g(C0051e eVar, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo448g(eVar, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo398f(this, eVar);
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h */
    public void mo452h(C0051e eVar, boolean z) {
        if (this.f193o != null) {
            C0067j fragmentManager = this.f193o.getFragmentManager();
            if (fragmentManager instanceof C0070k) {
                ((C0070k) fragmentManager).mo452h(eVar, true);
            }
        }
        Iterator<C0082f> it = this.f179J.iterator();
        while (it.hasNext()) {
            C0082f next = it.next();
            if (!z || next.f229b) {
                next.f228a.mo399g(this, eVar);
            }
        }
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        C0051e eVar;
        Context context2 = context;
        AttributeSet attributeSet2 = attributeSet;
        if (!"fragment".equals(str)) {
            return null;
        }
        String attributeValue = attributeSet2.getAttributeValue((String) null, "class");
        TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(attributeSet2, C0083g.f230a);
        int i = 0;
        if (attributeValue == null) {
            attributeValue = obtainStyledAttributes.getString(0);
        }
        String str2 = attributeValue;
        int resourceId = obtainStyledAttributes.getResourceId(1, -1);
        String string = obtainStyledAttributes.getString(2);
        obtainStyledAttributes.recycle();
        if (!C0051e.isSupportFragmentClass(this.f191m.mo377i(), str2)) {
            return null;
        }
        if (view != null) {
            i = view.getId();
        }
        if (i == -1 && resourceId == -1 && string == null) {
            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + str2);
        }
        C0051e b = resourceId != -1 ? mo424b(resourceId) : null;
        if (b == null && string != null) {
            b = mo380a(string);
        }
        if (b == null && i != -1) {
            b = mo424b(i);
        }
        if (f172a) {
            Log.v("FragmentManager", "onCreateView: id=0x" + Integer.toHexString(resourceId) + " fname=" + str2 + " existing=" + b);
        }
        if (b == null) {
            C0051e a = this.f192n.mo288a(context2, str2, (Bundle) null);
            a.mFromLayout = true;
            a.mFragmentId = resourceId != 0 ? resourceId : i;
            a.mContainerId = i;
            a.mTag = string;
            a.mInLayout = true;
            a.mFragmentManager = this;
            a.mHost = this.f191m;
            a.onInflate(this.f191m.mo377i(), attributeSet2, a.mSavedFragmentState);
            mo415a(a, true);
            eVar = a;
        } else if (b.mInLayout) {
            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(i) + " with another fragment for " + str2);
        } else {
            b.mInLayout = true;
            b.mHost = this.f191m;
            if (!b.mRetaining) {
                b.onInflate(this.f191m.mo377i(), attributeSet2, b.mSavedFragmentState);
            }
            eVar = b;
        }
        if (this.f190l >= 1 || !eVar.mFromLayout) {
            mo427b(eVar);
        } else {
            mo411a(eVar, 1, 0, 0, false);
        }
        if (eVar.mView == null) {
            throw new IllegalStateException("Fragment " + str2 + " did not create a view.");
        }
        if (resourceId != 0) {
            eVar.mView.setId(resourceId);
        }
        if (eVar.mView.getTag() == null) {
            eVar.mView.setTag(string);
        }
        return eVar.mView;
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView((View) null, str, context, attributeSet);
    }

    /* renamed from: android.support.v4.app.k$i */
    static class C0085i implements C0051e.C0057c {

        /* renamed from: a */
        final boolean f231a;

        /* renamed from: b */
        final C0045b f232b;

        /* renamed from: c */
        private int f233c;

        C0085i(C0045b bVar, boolean z) {
            this.f231a = z;
            this.f232b = bVar;
        }

        /* renamed from: a */
        public void mo291a() {
            this.f233c--;
            if (this.f233c == 0) {
                this.f232b.f82a.mo444f();
            }
        }

        /* renamed from: b */
        public void mo292b() {
            this.f233c++;
        }

        /* renamed from: c */
        public boolean mo492c() {
            return this.f233c == 0;
        }

        /* renamed from: d */
        public void mo493d() {
            boolean z = this.f233c > 0;
            C0070k kVar = this.f232b.f82a;
            int size = kVar.f183e.size();
            for (int i = 0; i < size; i++) {
                C0051e eVar = kVar.f183e.get(i);
                eVar.setOnStartEnterTransitionListener((C0051e.C0057c) null);
                if (z && eVar.isPostponed()) {
                    eVar.startPostponedEnterTransition();
                }
            }
            this.f232b.f82a.mo409a(this.f232b, this.f231a, !z, true);
        }

        /* renamed from: e */
        public void mo494e() {
            this.f232b.f82a.mo409a(this.f232b, this.f231a, false, false);
        }
    }

    /* renamed from: android.support.v4.app.k$c */
    private static class C0079c {

        /* renamed from: a */
        public final Animation f220a;

        /* renamed from: b */
        public final Animator f221b;

        C0079c(Animation animation) {
            this.f220a = animation;
            this.f221b = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }

        C0079c(Animator animator) {
            this.f220a = null;
            this.f221b = animator;
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }
    }

    /* renamed from: android.support.v4.app.k$b */
    private static class C0078b implements Animation.AnimationListener {

        /* renamed from: a */
        private final Animation.AnimationListener f219a;

        C0078b(Animation.AnimationListener animationListener) {
            this.f219a = animationListener;
        }

        public void onAnimationStart(Animation animation) {
            if (this.f219a != null) {
                this.f219a.onAnimationStart(animation);
            }
        }

        public void onAnimationEnd(Animation animation) {
            if (this.f219a != null) {
                this.f219a.onAnimationEnd(animation);
            }
        }

        public void onAnimationRepeat(Animation animation) {
            if (this.f219a != null) {
                this.f219a.onAnimationRepeat(animation);
            }
        }
    }

    /* renamed from: android.support.v4.app.k$a */
    private static class C0076a extends C0078b {

        /* renamed from: a */
        View f217a;

        C0076a(View view, Animation.AnimationListener animationListener) {
            super(animationListener);
            this.f217a = view;
        }

        public void onAnimationEnd(Animation animation) {
            if (C0469x.m1521c(this.f217a) || Build.VERSION.SDK_INT >= 24) {
                this.f217a.post(new Runnable() {
                    public void run() {
                        C0076a.this.f217a.setLayerType(0, (Paint) null);
                    }
                });
            } else {
                this.f217a.setLayerType(0, (Paint) null);
            }
            super.onAnimationEnd(animation);
        }
    }

    /* renamed from: android.support.v4.app.k$d */
    private static class C0080d extends AnimatorListenerAdapter {

        /* renamed from: a */
        View f222a;

        C0080d(View view) {
            this.f222a = view;
        }

        public void onAnimationStart(Animator animator) {
            this.f222a.setLayerType(2, (Paint) null);
        }

        public void onAnimationEnd(Animator animator) {
            this.f222a.setLayerType(0, (Paint) null);
            animator.removeListener(this);
        }
    }

    /* renamed from: android.support.v4.app.k$e */
    private static class C0081e extends AnimationSet implements Runnable {

        /* renamed from: a */
        private final ViewGroup f223a;

        /* renamed from: b */
        private final View f224b;

        /* renamed from: c */
        private boolean f225c;

        /* renamed from: d */
        private boolean f226d;

        /* renamed from: e */
        private boolean f227e = true;

        C0081e(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.f223a = viewGroup;
            this.f224b = view;
            addAnimation(animation);
            this.f223a.post(this);
        }

        public boolean getTransformation(long j, Transformation transformation) {
            this.f227e = true;
            if (this.f225c) {
                return !this.f226d;
            }
            if (!super.getTransformation(j, transformation)) {
                this.f225c = true;
                C0117x.m533a(this.f223a, this);
            }
            return true;
        }

        public boolean getTransformation(long j, Transformation transformation, float f) {
            this.f227e = true;
            if (this.f225c) {
                return !this.f226d;
            }
            if (!super.getTransformation(j, transformation, f)) {
                this.f225c = true;
                C0117x.m533a(this.f223a, this);
            }
            return true;
        }

        public void run() {
            if (this.f225c || !this.f227e) {
                this.f223a.endViewTransition(this.f224b);
                this.f226d = true;
                return;
            }
            this.f227e = false;
            this.f223a.post(this);
        }
    }
}
