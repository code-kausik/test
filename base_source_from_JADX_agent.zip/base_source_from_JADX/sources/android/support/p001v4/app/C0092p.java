package android.support.p001v4.app;

import android.graphics.Rect;
import android.os.Build;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/* renamed from: android.support.v4.app.p */
class C0092p {

    /* renamed from: a */
    private static final int[] f254a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8};

    /* renamed from: b */
    private static final C0103r f255b = (Build.VERSION.SDK_INT >= 21 ? new C0098q() : null);

    /* renamed from: c */
    private static final C0103r f256c = m404a();

    /* renamed from: a */
    private static C0103r m404a() {
        try {
            return (C0103r) Class.forName("android.support.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
            return null;
        }
    }

    /* renamed from: a */
    static void m419a(C0070k kVar, ArrayList<C0045b> arrayList, ArrayList<Boolean> arrayList2, int i, int i2, boolean z) {
        if (kVar.f190l >= 1) {
            SparseArray sparseArray = new SparseArray();
            for (int i3 = i; i3 < i2; i3++) {
                C0045b bVar = arrayList.get(i3);
                if (arrayList2.get(i3).booleanValue()) {
                    m430b(bVar, (SparseArray<C0097a>) sparseArray, z);
                } else {
                    m416a(bVar, (SparseArray<C0097a>) sparseArray, z);
                }
            }
            if (sparseArray.size() != 0) {
                View view = new View(kVar.f191m.mo377i());
                int size = sparseArray.size();
                for (int i4 = 0; i4 < size; i4++) {
                    int keyAt = sparseArray.keyAt(i4);
                    C0318m<String, String> a = m413a(keyAt, arrayList, arrayList2, i, i2);
                    C0097a aVar = (C0097a) sparseArray.valueAt(i4);
                    if (z) {
                        m418a(kVar, keyAt, aVar, view, a);
                    } else {
                        m431b(kVar, keyAt, aVar, view, a);
                    }
                }
            }
        }
    }

    /* renamed from: a */
    private static C0318m<String, String> m413a(int i, ArrayList<C0045b> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        ArrayList<String> arrayList3;
        ArrayList<String> arrayList4;
        C0318m<String, String> mVar = new C0318m<>();
        for (int i4 = i3 - 1; i4 >= i2; i4--) {
            C0045b bVar = arrayList.get(i4);
            if (bVar.mo115b(i)) {
                boolean booleanValue = arrayList2.get(i4).booleanValue();
                if (bVar.f99r != null) {
                    int size = bVar.f99r.size();
                    if (booleanValue) {
                        arrayList3 = bVar.f99r;
                        arrayList4 = bVar.f100s;
                    } else {
                        ArrayList<String> arrayList5 = bVar.f99r;
                        arrayList3 = bVar.f100s;
                        arrayList4 = arrayList5;
                    }
                    for (int i5 = 0; i5 < size; i5++) {
                        String str = arrayList4.get(i5);
                        String str2 = arrayList3.get(i5);
                        String remove = mVar.remove(str2);
                        if (remove != null) {
                            mVar.put(str, remove);
                        } else {
                            mVar.put(str, str2);
                        }
                    }
                }
            }
        }
        return mVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x001e, code lost:
        r11 = r4.f285a;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void m418a(android.support.p001v4.app.C0070k r19, int r20, android.support.p001v4.app.C0092p.C0097a r21, android.view.View r22, p000.C0318m<java.lang.String, java.lang.String> r23) {
        /*
            r0 = r19
            r4 = r21
            r9 = r22
            android.support.v4.app.g r1 = r0.f192n
            boolean r1 = r1.mo290a()
            if (r1 == 0) goto L_0x0019
            android.support.v4.app.g r0 = r0.f192n
            r1 = r20
            android.view.View r0 = r0.mo289a(r1)
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            goto L_0x001a
        L_0x0019:
            r0 = 0
        L_0x001a:
            r10 = r0
            if (r10 != 0) goto L_0x001e
            return
        L_0x001e:
            android.support.v4.app.e r11 = r4.f285a
            android.support.v4.app.e r12 = r4.f288d
            android.support.v4.app.r r13 = m405a((android.support.p001v4.app.C0051e) r12, (android.support.p001v4.app.C0051e) r11)
            if (r13 != 0) goto L_0x0029
            return
        L_0x0029:
            boolean r14 = r4.f286b
            boolean r0 = r4.f289e
            java.util.ArrayList r15 = new java.util.ArrayList
            r15.<init>()
            java.util.ArrayList r8 = new java.util.ArrayList
            r8.<init>()
            java.lang.Object r7 = m408a((android.support.p001v4.app.C0103r) r13, (android.support.p001v4.app.C0051e) r11, (boolean) r14)
            java.lang.Object r6 = m427b((android.support.p001v4.app.C0103r) r13, (android.support.p001v4.app.C0051e) r12, (boolean) r0)
            r0 = r13
            r1 = r10
            r2 = r9
            r3 = r23
            r5 = r8
            r16 = r6
            r6 = r15
            r17 = r7
            r18 = r10
            r10 = r8
            r8 = r16
            java.lang.Object r8 = m409a((android.support.p001v4.app.C0103r) r0, (android.view.ViewGroup) r1, (android.view.View) r2, (p000.C0318m<java.lang.String, java.lang.String>) r3, (android.support.p001v4.app.C0092p.C0097a) r4, (java.util.ArrayList<android.view.View>) r5, (java.util.ArrayList<android.view.View>) r6, (java.lang.Object) r7, (java.lang.Object) r8)
            r6 = r17
            if (r6 != 0) goto L_0x005e
            if (r8 != 0) goto L_0x005e
            r7 = r16
            if (r7 != 0) goto L_0x0060
            return
        L_0x005e:
            r7 = r16
        L_0x0060:
            java.util.ArrayList r5 = m412a((android.support.p001v4.app.C0103r) r13, (java.lang.Object) r7, (android.support.p001v4.app.C0051e) r12, (java.util.ArrayList<android.view.View>) r10, (android.view.View) r9)
            java.util.ArrayList r9 = m412a((android.support.p001v4.app.C0103r) r13, (java.lang.Object) r6, (android.support.p001v4.app.C0051e) r11, (java.util.ArrayList<android.view.View>) r15, (android.view.View) r9)
            r0 = 4
            m423a((java.util.ArrayList<android.view.View>) r9, (int) r0)
            r0 = r13
            r1 = r6
            r2 = r7
            r3 = r8
            r4 = r11
            r11 = r5
            r5 = r14
            java.lang.Object r14 = m410a((android.support.p001v4.app.C0103r) r0, (java.lang.Object) r1, (java.lang.Object) r2, (java.lang.Object) r3, (android.support.p001v4.app.C0051e) r4, (boolean) r5)
            if (r14 == 0) goto L_0x00a1
            m421a((android.support.p001v4.app.C0103r) r13, (java.lang.Object) r7, (android.support.p001v4.app.C0051e) r12, (java.util.ArrayList<android.view.View>) r11)
            java.util.ArrayList r12 = r13.mo543a((java.util.ArrayList<android.view.View>) r15)
            r0 = r13
            r1 = r14
            r2 = r6
            r3 = r9
            r4 = r7
            r5 = r11
            r6 = r8
            r7 = r15
            r0.mo520a(r1, r2, r3, r4, r5, r6, r7)
            r0 = r18
            r13.mo516a((android.view.ViewGroup) r0, (java.lang.Object) r14)
            r1 = r13
            r2 = r0
            r3 = r10
            r4 = r15
            r5 = r12
            r6 = r23
            r1.mo545a(r2, r3, r4, r5, r6)
            r0 = 0
            m423a((java.util.ArrayList<android.view.View>) r9, (int) r0)
            r13.mo522a((java.lang.Object) r8, (java.util.ArrayList<android.view.View>) r10, (java.util.ArrayList<android.view.View>) r15)
        L_0x00a1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.app.C0092p.m418a(android.support.v4.app.k, int, android.support.v4.app.p$a, android.view.View, m):void");
    }

    /* renamed from: a */
    private static void m421a(C0103r rVar, Object obj, C0051e eVar, final ArrayList<View> arrayList) {
        if (eVar != null && obj != null && eVar.mAdded && eVar.mHidden && eVar.mHiddenChanged) {
            eVar.setHideReplaced(true);
            rVar.mo527b(obj, eVar.getView(), arrayList);
            C0117x.m533a(eVar.mContainer, new Runnable() {
                public void run() {
                    C0092p.m423a((ArrayList<View>) arrayList, 4);
                }
            });
        }
    }

    /* renamed from: b */
    private static void m431b(C0070k kVar, int i, C0097a aVar, View view, C0318m<String, String> mVar) {
        C0051e eVar;
        C0051e eVar2;
        C0103r a;
        Object obj;
        C0070k kVar2 = kVar;
        C0097a aVar2 = aVar;
        View view2 = view;
        C0318m<String, String> mVar2 = mVar;
        ViewGroup viewGroup = kVar2.f192n.mo290a() ? (ViewGroup) kVar2.f192n.mo289a(i) : null;
        if (viewGroup != null && (a = m405a(eVar2, eVar)) != null) {
            boolean z = aVar2.f286b;
            boolean z2 = aVar2.f289e;
            Object a2 = m408a(a, (eVar = aVar2.f285a), z);
            Object b = m427b(a, (eVar2 = aVar2.f288d), z2);
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            ArrayList arrayList3 = arrayList;
            Object obj2 = b;
            C0103r rVar = a;
            Object b2 = m428b(a, viewGroup, view2, mVar2, aVar2, arrayList, arrayList2, a2, obj2);
            Object obj3 = a2;
            if (obj3 == null && b2 == null) {
                obj = obj2;
                if (obj == null) {
                    return;
                }
            } else {
                obj = obj2;
            }
            ArrayList<View> a3 = m412a(rVar, obj, eVar2, (ArrayList<View>) arrayList3, view2);
            Object obj4 = (a3 == null || a3.isEmpty()) ? null : obj;
            rVar.mo526b(obj3, view2);
            Object a4 = m410a(rVar, obj3, obj4, b2, eVar, aVar2.f286b);
            if (a4 != null) {
                ArrayList arrayList4 = new ArrayList();
                C0103r rVar2 = rVar;
                rVar2.mo520a(a4, obj3, arrayList4, obj4, a3, b2, arrayList2);
                m420a(rVar2, viewGroup, eVar, view2, (ArrayList<View>) arrayList2, obj3, (ArrayList<View>) arrayList4, obj4, a3);
                ArrayList arrayList5 = arrayList2;
                rVar.mo546a((View) viewGroup, (ArrayList<View>) arrayList5, (Map<String, String>) mVar2);
                rVar.mo516a(viewGroup, a4);
                rVar.mo547a(viewGroup, (ArrayList<View>) arrayList5, (Map<String, String>) mVar2);
            }
        }
    }

    /* renamed from: a */
    private static void m420a(C0103r rVar, ViewGroup viewGroup, C0051e eVar, View view, ArrayList<View> arrayList, Object obj, ArrayList<View> arrayList2, Object obj2, ArrayList<View> arrayList3) {
        final Object obj3 = obj;
        final C0103r rVar2 = rVar;
        final View view2 = view;
        final C0051e eVar2 = eVar;
        final ArrayList<View> arrayList4 = arrayList;
        final ArrayList<View> arrayList5 = arrayList2;
        final ArrayList<View> arrayList6 = arrayList3;
        final Object obj4 = obj2;
        C0117x.m533a(viewGroup, new Runnable() {
            public void run() {
                if (obj3 != null) {
                    rVar2.mo530c(obj3, view2);
                    arrayList5.addAll(C0092p.m412a(rVar2, obj3, eVar2, (ArrayList<View>) arrayList4, view2));
                }
                if (arrayList6 != null) {
                    if (obj4 != null) {
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(view2);
                        rVar2.mo528b(obj4, (ArrayList<View>) arrayList6, (ArrayList<View>) arrayList);
                    }
                    arrayList6.clear();
                    arrayList6.add(view2);
                }
            }
        });
    }

    /* renamed from: a */
    private static C0103r m405a(C0051e eVar, C0051e eVar2) {
        ArrayList arrayList = new ArrayList();
        if (eVar != null) {
            Object exitTransition = eVar.getExitTransition();
            if (exitTransition != null) {
                arrayList.add(exitTransition);
            }
            Object returnTransition = eVar.getReturnTransition();
            if (returnTransition != null) {
                arrayList.add(returnTransition);
            }
            Object sharedElementReturnTransition = eVar.getSharedElementReturnTransition();
            if (sharedElementReturnTransition != null) {
                arrayList.add(sharedElementReturnTransition);
            }
        }
        if (eVar2 != null) {
            Object enterTransition = eVar2.getEnterTransition();
            if (enterTransition != null) {
                arrayList.add(enterTransition);
            }
            Object reenterTransition = eVar2.getReenterTransition();
            if (reenterTransition != null) {
                arrayList.add(reenterTransition);
            }
            Object sharedElementEnterTransition = eVar2.getSharedElementEnterTransition();
            if (sharedElementEnterTransition != null) {
                arrayList.add(sharedElementEnterTransition);
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        if (f255b != null && m426a(f255b, (List<Object>) arrayList)) {
            return f255b;
        }
        if (f256c != null && m426a(f256c, (List<Object>) arrayList)) {
            return f256c;
        }
        if (f255b == null && f256c == null) {
            return null;
        }
        throw new IllegalArgumentException("Invalid Transition types");
    }

    /* renamed from: a */
    private static boolean m426a(C0103r rVar, List<Object> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            if (!rVar.mo523a(list.get(i))) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: a */
    private static Object m407a(C0103r rVar, C0051e eVar, C0051e eVar2, boolean z) {
        Object obj;
        if (eVar == null || eVar2 == null) {
            return null;
        }
        if (z) {
            obj = eVar2.getSharedElementReturnTransition();
        } else {
            obj = eVar.getSharedElementEnterTransition();
        }
        return rVar.mo529c(rVar.mo524b(obj));
    }

    /* renamed from: a */
    private static Object m408a(C0103r rVar, C0051e eVar, boolean z) {
        Object obj;
        if (eVar == null) {
            return null;
        }
        if (z) {
            obj = eVar.getReenterTransition();
        } else {
            obj = eVar.getEnterTransition();
        }
        return rVar.mo524b(obj);
    }

    /* renamed from: b */
    private static Object m427b(C0103r rVar, C0051e eVar, boolean z) {
        Object obj;
        if (eVar == null) {
            return null;
        }
        if (z) {
            obj = eVar.getReturnTransition();
        } else {
            obj = eVar.getExitTransition();
        }
        return rVar.mo524b(obj);
    }

    /* renamed from: a */
    private static Object m409a(C0103r rVar, ViewGroup viewGroup, View view, C0318m<String, String> mVar, C0097a aVar, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        Object obj3;
        Object obj4;
        final Rect rect;
        final View view2;
        final C0103r rVar2 = rVar;
        View view3 = view;
        C0318m<String, String> mVar2 = mVar;
        C0097a aVar2 = aVar;
        ArrayList<View> arrayList3 = arrayList;
        ArrayList<View> arrayList4 = arrayList2;
        Object obj5 = obj;
        C0051e eVar = aVar2.f285a;
        C0051e eVar2 = aVar2.f288d;
        if (eVar != null) {
            eVar.getView().setVisibility(0);
        }
        if (eVar == null || eVar2 == null) {
            return null;
        }
        boolean z = aVar2.f286b;
        if (mVar.isEmpty()) {
            obj3 = null;
        } else {
            obj3 = m407a(rVar2, eVar, eVar2, z);
        }
        C0318m<String, View> b = m429b(rVar2, mVar2, obj3, aVar2);
        C0318m<String, View> a = m414a(rVar2, mVar2, obj3, aVar2);
        if (mVar.isEmpty()) {
            if (b != null) {
                b.clear();
            }
            if (a != null) {
                a.clear();
            }
            obj4 = null;
        } else {
            m424a(arrayList3, b, (Collection<String>) mVar.keySet());
            m424a(arrayList4, a, mVar.values());
            obj4 = obj3;
        }
        if (obj5 == null && obj2 == null && obj4 == null) {
            return null;
        }
        m417a(eVar, eVar2, z, b, true);
        if (obj4 != null) {
            arrayList4.add(view3);
            rVar2.mo519a(obj4, view3, arrayList3);
            m422a(rVar2, obj4, obj2, b, aVar2.f289e, aVar2.f290f);
            Rect rect2 = new Rect();
            View a2 = m406a(a, aVar2, obj5, z);
            if (a2 != null) {
                rVar2.mo517a(obj5, rect2);
            }
            rect = rect2;
            view2 = a2;
        } else {
            view2 = null;
            rect = null;
        }
        final C0051e eVar3 = eVar;
        final C0051e eVar4 = eVar2;
        final boolean z2 = z;
        final C0318m<String, View> mVar3 = a;
        C0117x.m533a(viewGroup, new Runnable() {
            public void run() {
                C0092p.m417a(eVar3, eVar4, z2, (C0318m<String, View>) mVar3, false);
                if (view2 != null) {
                    rVar2.mo544a(view2, rect);
                }
            }
        });
        return obj4;
    }

    /* renamed from: a */
    private static void m424a(ArrayList<View> arrayList, C0318m<String, View> mVar, Collection<String> collection) {
        for (int size = mVar.size() - 1; size >= 0; size--) {
            View c = mVar.mo4159c(size);
            if (collection.contains(C0469x.m1516a(c))) {
                arrayList.add(c);
            }
        }
    }

    /* renamed from: b */
    private static Object m428b(C0103r rVar, ViewGroup viewGroup, View view, C0318m<String, String> mVar, C0097a aVar, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        C0318m<String, String> mVar2;
        Object obj3;
        Object obj4;
        Rect rect;
        C0103r rVar2 = rVar;
        C0097a aVar2 = aVar;
        final ArrayList<View> arrayList3 = arrayList;
        final Object obj5 = obj;
        C0051e eVar = aVar2.f285a;
        C0051e eVar2 = aVar2.f288d;
        if (eVar == null || eVar2 == null) {
            return null;
        }
        boolean z = aVar2.f286b;
        if (mVar.isEmpty()) {
            mVar2 = mVar;
            obj3 = null;
        } else {
            obj3 = m407a(rVar2, eVar, eVar2, z);
            mVar2 = mVar;
        }
        C0318m<String, View> b = m429b(rVar2, mVar2, obj3, aVar2);
        if (mVar.isEmpty()) {
            obj4 = null;
        } else {
            arrayList3.addAll(b.values());
            obj4 = obj3;
        }
        if (obj5 == null && obj2 == null && obj4 == null) {
            return null;
        }
        m417a(eVar, eVar2, z, b, true);
        if (obj4 != null) {
            rect = new Rect();
            rVar2.mo519a(obj4, view, arrayList3);
            m422a(rVar2, obj4, obj2, b, aVar2.f289e, aVar2.f290f);
            if (obj5 != null) {
                rVar2.mo517a(obj5, rect);
            }
        } else {
            rect = null;
        }
        final C0103r rVar3 = rVar2;
        final C0318m<String, String> mVar3 = mVar2;
        final Object obj6 = obj4;
        final C0097a aVar3 = aVar2;
        C00964 r13 = r0;
        final ArrayList<View> arrayList4 = arrayList2;
        final View view2 = view;
        final C0051e eVar3 = eVar;
        final C0051e eVar4 = eVar2;
        final boolean z2 = z;
        final Rect rect2 = rect;
        C00964 r0 = new Runnable() {
            public void run() {
                C0318m<String, View> a = C0092p.m414a(rVar3, (C0318m<String, String>) mVar3, obj6, aVar3);
                if (a != null) {
                    arrayList4.addAll(a.values());
                    arrayList4.add(view2);
                }
                C0092p.m417a(eVar3, eVar4, z2, a, false);
                if (obj6 != null) {
                    rVar3.mo522a(obj6, (ArrayList<View>) arrayList3, (ArrayList<View>) arrayList4);
                    View a2 = C0092p.m406a(a, aVar3, obj5, z2);
                    if (a2 != null) {
                        rVar3.mo544a(a2, rect2);
                    }
                }
            }
        };
        C0117x.m533a(viewGroup, r13);
        return obj4;
    }

    /* renamed from: b */
    private static C0318m<String, View> m429b(C0103r rVar, C0318m<String, String> mVar, Object obj, C0097a aVar) {
        C0119z zVar;
        ArrayList<String> arrayList;
        if (mVar.isEmpty() || obj == null) {
            mVar.clear();
            return null;
        }
        C0051e eVar = aVar.f288d;
        C0318m<String, View> mVar2 = new C0318m<>();
        rVar.mo549a((Map<String, View>) mVar2, eVar.getView());
        C0045b bVar = aVar.f290f;
        if (aVar.f289e) {
            zVar = eVar.getEnterTransitionCallback();
            arrayList = bVar.f100s;
        } else {
            zVar = eVar.getExitTransitionCallback();
            arrayList = bVar.f99r;
        }
        mVar2.mo3468a(arrayList);
        if (zVar != null) {
            zVar.mo604a(arrayList, mVar2);
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                String str = arrayList.get(size);
                View view = mVar2.get(str);
                if (view == null) {
                    mVar.remove(str);
                } else if (!str.equals(C0469x.m1516a(view))) {
                    mVar.put(C0469x.m1516a(view), mVar.remove(str));
                }
            }
        } else {
            mVar.mo3468a(mVar2.keySet());
        }
        return mVar2;
    }

    /* renamed from: a */
    static C0318m<String, View> m414a(C0103r rVar, C0318m<String, String> mVar, Object obj, C0097a aVar) {
        C0119z zVar;
        ArrayList<String> arrayList;
        String a;
        C0051e eVar = aVar.f285a;
        View view = eVar.getView();
        if (mVar.isEmpty() || obj == null || view == null) {
            mVar.clear();
            return null;
        }
        C0318m<String, View> mVar2 = new C0318m<>();
        rVar.mo549a((Map<String, View>) mVar2, view);
        C0045b bVar = aVar.f287c;
        if (aVar.f286b) {
            zVar = eVar.getExitTransitionCallback();
            arrayList = bVar.f99r;
        } else {
            zVar = eVar.getEnterTransitionCallback();
            arrayList = bVar.f100s;
        }
        if (arrayList != null) {
            mVar2.mo3468a(arrayList);
            mVar2.mo3468a(mVar.values());
        }
        if (zVar != null) {
            zVar.mo604a(arrayList, mVar2);
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                String str = arrayList.get(size);
                View view2 = mVar2.get(str);
                if (view2 == null) {
                    String a2 = m411a(mVar, str);
                    if (a2 != null) {
                        mVar.remove(a2);
                    }
                } else if (!str.equals(C0469x.m1516a(view2)) && (a = m411a(mVar, str)) != null) {
                    mVar.put(a, C0469x.m1516a(view2));
                }
            }
        } else {
            m425a(mVar, mVar2);
        }
        return mVar2;
    }

    /* renamed from: a */
    private static String m411a(C0318m<String, String> mVar, String str) {
        int size = mVar.size();
        for (int i = 0; i < size; i++) {
            if (str.equals(mVar.mo4159c(i))) {
                return mVar.mo4158b(i);
            }
        }
        return null;
    }

    /* renamed from: a */
    static View m406a(C0318m<String, View> mVar, C0097a aVar, Object obj, boolean z) {
        String str;
        C0045b bVar = aVar.f287c;
        if (obj == null || mVar == null || bVar.f99r == null || bVar.f99r.isEmpty()) {
            return null;
        }
        if (z) {
            str = bVar.f99r.get(0);
        } else {
            str = bVar.f100s.get(0);
        }
        return mVar.get(str);
    }

    /* renamed from: a */
    private static void m422a(C0103r rVar, Object obj, Object obj2, C0318m<String, View> mVar, boolean z, C0045b bVar) {
        String str;
        if (bVar.f99r != null && !bVar.f99r.isEmpty()) {
            if (z) {
                str = bVar.f100s.get(0);
            } else {
                str = bVar.f99r.get(0);
            }
            View view = mVar.get(str);
            rVar.mo518a(obj, view);
            if (obj2 != null) {
                rVar.mo518a(obj2, view);
            }
        }
    }

    /* renamed from: a */
    private static void m425a(C0318m<String, String> mVar, C0318m<String, View> mVar2) {
        for (int size = mVar.size() - 1; size >= 0; size--) {
            if (!mVar2.containsKey(mVar.mo4159c(size))) {
                mVar.mo4163d(size);
            }
        }
    }

    /* renamed from: a */
    static void m417a(C0051e eVar, C0051e eVar2, boolean z, C0318m<String, View> mVar, boolean z2) {
        C0119z zVar;
        int i;
        if (z) {
            zVar = eVar2.getEnterTransitionCallback();
        } else {
            zVar = eVar.getEnterTransitionCallback();
        }
        if (zVar != null) {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            if (mVar == null) {
                i = 0;
            } else {
                i = mVar.size();
            }
            for (int i2 = 0; i2 < i; i2++) {
                arrayList2.add(mVar.mo4158b(i2));
                arrayList.add(mVar.mo4159c(i2));
            }
            if (z2) {
                zVar.mo603a(arrayList2, arrayList, (List<View>) null);
            } else {
                zVar.mo605b(arrayList2, arrayList, (List<View>) null);
            }
        }
    }

    /* renamed from: a */
    static ArrayList<View> m412a(C0103r rVar, Object obj, C0051e eVar, ArrayList<View> arrayList, View view) {
        if (obj == null) {
            return null;
        }
        ArrayList<View> arrayList2 = new ArrayList<>();
        View view2 = eVar.getView();
        if (view2 != null) {
            rVar.mo548a(arrayList2, view2);
        }
        if (arrayList != null) {
            arrayList2.removeAll(arrayList);
        }
        if (arrayList2.isEmpty()) {
            return arrayList2;
        }
        arrayList2.add(view);
        rVar.mo521a(obj, arrayList2);
        return arrayList2;
    }

    /* renamed from: a */
    static void m423a(ArrayList<View> arrayList, int i) {
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                arrayList.get(size).setVisibility(i);
            }
        }
    }

    /* renamed from: a */
    private static Object m410a(C0103r rVar, Object obj, Object obj2, Object obj3, C0051e eVar, boolean z) {
        boolean z2;
        if (obj == null || obj2 == null || eVar == null) {
            z2 = true;
        } else {
            z2 = z ? eVar.getAllowReturnTransitionOverlap() : eVar.getAllowEnterTransitionOverlap();
        }
        if (z2) {
            return rVar.mo515a(obj2, obj, obj3);
        }
        return rVar.mo525b(obj2, obj, obj3);
    }

    /* renamed from: a */
    public static void m416a(C0045b bVar, SparseArray<C0097a> sparseArray, boolean z) {
        int size = bVar.f83b.size();
        for (int i = 0; i < size; i++) {
            m415a(bVar, bVar.f83b.get(i), sparseArray, false, z);
        }
    }

    /* renamed from: b */
    public static void m430b(C0045b bVar, SparseArray<C0097a> sparseArray, boolean z) {
        if (bVar.f82a.f192n.mo290a()) {
            for (int size = bVar.f83b.size() - 1; size >= 0; size--) {
                m415a(bVar, bVar.f83b.get(size), sparseArray, true, z);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0035, code lost:
        if (r10.mAdded != false) goto L_0x008b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x006d, code lost:
        r1 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x006f, code lost:
        r1 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x007a, code lost:
        r13 = r1;
        r1 = false;
        r12 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0089, code lost:
        if (r10.mHidden == false) goto L_0x008b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x008b, code lost:
        r1 = true;
     */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x009a  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void m415a(android.support.p001v4.app.C0045b r16, android.support.p001v4.app.C0045b.C0046a r17, android.util.SparseArray<android.support.p001v4.app.C0092p.C0097a> r18, boolean r19, boolean r20) {
        /*
            r0 = r16
            r1 = r17
            r2 = r18
            r3 = r19
            android.support.v4.app.e r10 = r1.f104b
            if (r10 != 0) goto L_0x000d
            return
        L_0x000d:
            int r11 = r10.mContainerId
            if (r11 != 0) goto L_0x0012
            return
        L_0x0012:
            if (r3 == 0) goto L_0x001b
            int[] r4 = f254a
            int r1 = r1.f103a
            r1 = r4[r1]
            goto L_0x001d
        L_0x001b:
            int r1 = r1.f103a
        L_0x001d:
            r4 = 0
            r5 = 1
            if (r1 == r5) goto L_0x007e
            switch(r1) {
                case 3: goto L_0x0054;
                case 4: goto L_0x003c;
                case 5: goto L_0x0029;
                case 6: goto L_0x0054;
                case 7: goto L_0x007e;
                default: goto L_0x0024;
            }
        L_0x0024:
            r1 = r4
            r12 = r1
            r13 = r12
            goto L_0x0092
        L_0x0029:
            if (r20 == 0) goto L_0x0038
            boolean r1 = r10.mHiddenChanged
            if (r1 == 0) goto L_0x008d
            boolean r1 = r10.mHidden
            if (r1 != 0) goto L_0x008d
            boolean r1 = r10.mAdded
            if (r1 == 0) goto L_0x008d
            goto L_0x008b
        L_0x0038:
            boolean r1 = r10.mHidden
            goto L_0x008e
        L_0x003c:
            if (r20 == 0) goto L_0x004b
            boolean r1 = r10.mHiddenChanged
            if (r1 == 0) goto L_0x006f
            boolean r1 = r10.mAdded
            if (r1 == 0) goto L_0x006f
            boolean r1 = r10.mHidden
            if (r1 == 0) goto L_0x006f
        L_0x004a:
            goto L_0x006d
        L_0x004b:
            boolean r1 = r10.mAdded
            if (r1 == 0) goto L_0x006f
            boolean r1 = r10.mHidden
            if (r1 != 0) goto L_0x006f
            goto L_0x004a
        L_0x0054:
            if (r20 == 0) goto L_0x0071
            boolean r1 = r10.mAdded
            if (r1 != 0) goto L_0x006f
            android.view.View r1 = r10.mView
            if (r1 == 0) goto L_0x006f
            android.view.View r1 = r10.mView
            int r1 = r1.getVisibility()
            if (r1 != 0) goto L_0x006f
            float r1 = r10.mPostponedAlpha
            r6 = 0
            int r1 = (r1 > r6 ? 1 : (r1 == r6 ? 0 : -1))
            if (r1 < 0) goto L_0x006f
        L_0x006d:
            r1 = r5
            goto L_0x007a
        L_0x006f:
            r1 = r4
            goto L_0x007a
        L_0x0071:
            boolean r1 = r10.mAdded
            if (r1 == 0) goto L_0x006f
            boolean r1 = r10.mHidden
            if (r1 != 0) goto L_0x006f
            goto L_0x006d
        L_0x007a:
            r13 = r1
            r1 = r4
            r12 = r5
            goto L_0x0092
        L_0x007e:
            if (r20 == 0) goto L_0x0083
            boolean r1 = r10.mIsNewlyAdded
            goto L_0x008e
        L_0x0083:
            boolean r1 = r10.mAdded
            if (r1 != 0) goto L_0x008d
            boolean r1 = r10.mHidden
            if (r1 != 0) goto L_0x008d
        L_0x008b:
            r1 = r5
            goto L_0x008e
        L_0x008d:
            r1 = r4
        L_0x008e:
            r12 = r4
            r13 = r12
            r4 = r1
            r1 = r5
        L_0x0092:
            java.lang.Object r6 = r2.get(r11)
            android.support.v4.app.p$a r6 = (android.support.p001v4.app.C0092p.C0097a) r6
            if (r4 == 0) goto L_0x00a4
            android.support.v4.app.p$a r6 = m403a((android.support.p001v4.app.C0092p.C0097a) r6, (android.util.SparseArray<android.support.p001v4.app.C0092p.C0097a>) r2, (int) r11)
            r6.f285a = r10
            r6.f286b = r3
            r6.f287c = r0
        L_0x00a4:
            r14 = r6
            r9 = 0
            if (r20 != 0) goto L_0x00cc
            if (r1 == 0) goto L_0x00cc
            if (r14 == 0) goto L_0x00b2
            android.support.v4.app.e r1 = r14.f288d
            if (r1 != r10) goto L_0x00b2
            r14.f288d = r9
        L_0x00b2:
            android.support.v4.app.k r4 = r0.f82a
            int r1 = r10.mState
            if (r1 >= r5) goto L_0x00cc
            int r1 = r4.f190l
            if (r1 < r5) goto L_0x00cc
            boolean r1 = r0.f101t
            if (r1 != 0) goto L_0x00cc
            r4.mo445f(r10)
            r6 = 1
            r7 = 0
            r8 = 0
            r1 = 0
            r5 = r10
            r9 = r1
            r4.mo411a((android.support.p001v4.app.C0051e) r5, (int) r6, (int) r7, (int) r8, (boolean) r9)
        L_0x00cc:
            if (r13 == 0) goto L_0x00de
            if (r14 == 0) goto L_0x00d4
            android.support.v4.app.e r1 = r14.f288d
            if (r1 != 0) goto L_0x00de
        L_0x00d4:
            android.support.v4.app.p$a r14 = m403a((android.support.p001v4.app.C0092p.C0097a) r14, (android.util.SparseArray<android.support.p001v4.app.C0092p.C0097a>) r2, (int) r11)
            r14.f288d = r10
            r14.f289e = r3
            r14.f290f = r0
        L_0x00de:
            if (r20 != 0) goto L_0x00eb
            if (r12 == 0) goto L_0x00eb
            if (r14 == 0) goto L_0x00eb
            android.support.v4.app.e r0 = r14.f285a
            if (r0 != r10) goto L_0x00eb
            r0 = 0
            r14.f285a = r0
        L_0x00eb:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.app.C0092p.m415a(android.support.v4.app.b, android.support.v4.app.b$a, android.util.SparseArray, boolean, boolean):void");
    }

    /* renamed from: a */
    private static C0097a m403a(C0097a aVar, SparseArray<C0097a> sparseArray, int i) {
        if (aVar != null) {
            return aVar;
        }
        C0097a aVar2 = new C0097a();
        sparseArray.put(i, aVar2);
        return aVar2;
    }

    /* renamed from: android.support.v4.app.p$a */
    static class C0097a {

        /* renamed from: a */
        public C0051e f285a;

        /* renamed from: b */
        public boolean f286b;

        /* renamed from: c */
        public C0045b f287c;

        /* renamed from: d */
        public C0051e f288d;

        /* renamed from: e */
        public boolean f289e;

        /* renamed from: f */
        public C0045b f290f;

        C0097a() {
        }
    }
}
