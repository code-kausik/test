package android.support.p001v4.app;

import android.arch.lifecycle.C0012c;
import android.arch.lifecycle.C0031p;
import android.arch.lifecycle.C0032q;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.p001v4.app.C0037a;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: android.support.v4.app.f */
public class C0060f extends C0043ab implements C0032q, C0037a.C0039a, C0037a.C0041c {

    /* renamed from: a */
    final Handler f146a = new Handler() {
        public void handleMessage(Message message) {
            if (message.what != 2) {
                super.handleMessage(message);
                return;
            }
            C0060f.this.mo302a();
            C0060f.this.f147b.mo375m();
        }
    };

    /* renamed from: b */
    final C0065h f147b = C0065h.m212a((C0066i<?>) new C0062a());

    /* renamed from: c */
    boolean f148c;

    /* renamed from: d */
    boolean f149d;

    /* renamed from: e */
    boolean f150e = true;

    /* renamed from: f */
    boolean f151f;

    /* renamed from: g */
    boolean f152g;

    /* renamed from: h */
    boolean f153h;

    /* renamed from: i */
    int f154i;

    /* renamed from: j */
    C0465u<String> f155j;

    /* renamed from: k */
    private C0031p f156k;

    /* renamed from: a */
    public void mo303a(C0051e eVar) {
    }

    /* renamed from: b */
    public Object mo308b() {
        return null;
    }

    /* renamed from: android.support.v4.app.f$b */
    static final class C0063b {

        /* renamed from: a */
        Object f159a;

        /* renamed from: b */
        C0031p f160b;

        /* renamed from: c */
        C0086l f161c;

        C0063b() {
        }
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        this.f147b.mo361b();
        int i3 = i >> 16;
        if (i3 != 0) {
            int i4 = i3 - 1;
            String a = this.f155j.mo4172a(i4);
            this.f155j.mo4179c(i4);
            if (a == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
                return;
            }
            C0051e a2 = this.f147b.mo351a(a);
            if (a2 == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + a);
                return;
            }
            a2.onActivityResult(i & 65535, i2, intent);
            return;
        }
        C0037a.C0040b a3 = C0037a.m133a();
        if (a3 == null || !a3.mo89a(this, i, i2, intent)) {
            super.onActivityResult(i, i2, intent);
        }
    }

    public void onBackPressed() {
        C0067j a = this.f147b.mo352a();
        boolean d = a.mo385d();
        if (d && Build.VERSION.SDK_INT <= 25) {
            return;
        }
        if (d || !a.mo383b()) {
            super.onBackPressed();
        }
    }

    public void onMultiWindowModeChanged(boolean z) {
        this.f147b.mo357a(z);
    }

    public void onPictureInPictureModeChanged(boolean z) {
        this.f147b.mo363b(z);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f147b.mo361b();
        this.f147b.mo354a(configuration);
    }

    public C0031p getViewModelStore() {
        if (getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        }
        if (this.f156k == null) {
            C0063b bVar = (C0063b) getLastNonConfigurationInstance();
            if (bVar != null) {
                this.f156k = bVar.f160b;
            }
            if (this.f156k == null) {
                this.f156k = new C0031p();
            }
        }
        return this.f156k;
    }

    public C0012c getLifecycle() {
        return super.getLifecycle();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        C0086l lVar = null;
        this.f147b.mo356a((C0051e) null);
        super.onCreate(bundle);
        C0063b bVar = (C0063b) getLastNonConfigurationInstance();
        if (!(bVar == null || bVar.f160b == null || this.f156k != null)) {
            this.f156k = bVar.f160b;
        }
        if (bundle != null) {
            Parcelable parcelable = bundle.getParcelable("android:support:fragments");
            C0065h hVar = this.f147b;
            if (bVar != null) {
                lVar = bVar.f161c;
            }
            hVar.mo355a(parcelable, lVar);
            if (bundle.containsKey("android:support:next_request_index")) {
                this.f154i = bundle.getInt("android:support:next_request_index");
                int[] intArray = bundle.getIntArray("android:support:request_indicies");
                String[] stringArray = bundle.getStringArray("android:support:request_fragment_who");
                if (intArray == null || stringArray == null || intArray.length != stringArray.length) {
                    Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
                } else {
                    this.f155j = new C0465u<>(intArray.length);
                    for (int i = 0; i < intArray.length; i++) {
                        this.f155j.mo4177b(intArray[i], stringArray[i]);
                    }
                }
            }
        }
        if (this.f155j == null) {
            this.f155j = new C0465u<>();
            this.f154i = 0;
        }
        this.f147b.mo367e();
    }

    public boolean onCreatePanelMenu(int i, Menu menu) {
        if (i == 0) {
            return super.onCreatePanelMenu(i, menu) | this.f147b.mo359a(menu, getMenuInflater());
        }
        return super.onCreatePanelMenu(i, menu);
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View a = mo301a(view, str, context, attributeSet);
        return a == null ? super.onCreateView(view, str, context, attributeSet) : a;
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View a = mo301a((View) null, str, context, attributeSet);
        return a == null ? super.onCreateView(str, context, attributeSet) : a;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public final View mo301a(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f147b.mo353a(view, str, context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        if (this.f156k != null && !isChangingConfigurations()) {
            this.f156k.mo64a();
        }
        this.f147b.mo373k();
    }

    public void onLowMemory() {
        super.onLowMemory();
        this.f147b.mo374l();
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 0) {
            return this.f147b.mo360a(menuItem);
        }
        if (i != 6) {
            return false;
        }
        return this.f147b.mo364b(menuItem);
    }

    public void onPanelClosed(int i, Menu menu) {
        if (i == 0) {
            this.f147b.mo362b(menu);
        }
        super.onPanelClosed(i, menu);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        this.f149d = false;
        if (this.f146a.hasMessages(2)) {
            this.f146a.removeMessages(2);
            mo302a();
        }
        this.f147b.mo371i();
    }

    /* access modifiers changed from: protected */
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.f147b.mo361b();
    }

    public void onStateNotSaved() {
        this.f147b.mo361b();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        this.f146a.sendEmptyMessage(2);
        this.f149d = true;
        this.f147b.mo375m();
    }

    /* access modifiers changed from: protected */
    public void onPostResume() {
        super.onPostResume();
        this.f146a.removeMessages(2);
        mo302a();
        this.f147b.mo375m();
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo302a() {
        this.f147b.mo370h();
    }

    public boolean onPreparePanel(int i, View view, Menu menu) {
        if (i != 0 || menu == null) {
            return super.onPreparePanel(i, view, menu);
        }
        return mo307a(view, menu) | this.f147b.mo358a(menu);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public boolean mo307a(View view, Menu menu) {
        return super.onPreparePanel(0, view, menu);
    }

    public final Object onRetainNonConfigurationInstance() {
        Object b = mo308b();
        C0086l d = this.f147b.mo366d();
        if (d == null && this.f156k == null && b == null) {
            return null;
        }
        C0063b bVar = new C0063b();
        bVar.f159a = b;
        bVar.f160b = this.f156k;
        bVar.f161c = d;
        return bVar;
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        m182e();
        Parcelable c = this.f147b.mo365c();
        if (c != null) {
            bundle.putParcelable("android:support:fragments", c);
        }
        if (this.f155j.mo4175b() > 0) {
            bundle.putInt("android:support:next_request_index", this.f154i);
            int[] iArr = new int[this.f155j.mo4175b()];
            String[] strArr = new String[this.f155j.mo4175b()];
            for (int i = 0; i < this.f155j.mo4175b(); i++) {
                iArr[i] = this.f155j.mo4181d(i);
                strArr[i] = this.f155j.mo4182e(i);
            }
            bundle.putIntArray("android:support:request_indicies", iArr);
            bundle.putStringArray("android:support:request_fragment_who", strArr);
        }
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        this.f150e = false;
        if (!this.f148c) {
            this.f148c = true;
            this.f147b.mo368f();
        }
        this.f147b.mo361b();
        this.f147b.mo375m();
        this.f147b.mo369g();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        this.f150e = true;
        m182e();
        this.f147b.mo372j();
    }

    @Deprecated
    /* renamed from: c */
    public void mo309c() {
        invalidateOptionsMenu();
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str2 = str + "  ";
        printWriter.print(str2);
        printWriter.print("mCreated=");
        printWriter.print(this.f148c);
        printWriter.print(" mResumed=");
        printWriter.print(this.f149d);
        printWriter.print(" mStopped=");
        printWriter.print(this.f150e);
        if (getApplication() != null) {
            C0107s.m476a(this).mo74a(str2, fileDescriptor, printWriter, strArr);
        }
        this.f147b.mo352a().mo382a(str, fileDescriptor, printWriter, strArr);
    }

    /* renamed from: d */
    public C0067j mo310d() {
        return this.f147b.mo352a();
    }

    public void startActivityForResult(Intent intent, int i) {
        if (!this.f153h && i != -1) {
            m181b(i);
        }
        super.startActivityForResult(intent, i);
    }

    public void startActivityForResult(Intent intent, int i, Bundle bundle) {
        if (!this.f153h && i != -1) {
            m181b(i);
        }
        super.startActivityForResult(intent, i, bundle);
    }

    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4) throws IntentSender.SendIntentException {
        if (!this.f152g && i != -1) {
            m181b(i);
        }
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4);
    }

    public void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) throws IntentSender.SendIntentException {
        if (!this.f152g && i != -1) {
            m181b(i);
        }
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4, bundle);
    }

    /* renamed from: b */
    static void m181b(int i) {
        if ((i & -65536) != 0) {
            throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
        }
    }

    /* renamed from: a */
    public final void mo91a(int i) {
        if (!this.f151f && i != -1) {
            m181b(i);
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        this.f147b.mo361b();
        int i2 = (i >> 16) & 65535;
        if (i2 != 0) {
            int i3 = i2 - 1;
            String a = this.f155j.mo4172a(i3);
            this.f155j.mo4179c(i3);
            if (a == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
                return;
            }
            C0051e a2 = this.f147b.mo351a(a);
            if (a2 == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + a);
                return;
            }
            a2.onRequestPermissionsResult(i & 65535, strArr, iArr);
        }
    }

    /* renamed from: a */
    public void mo304a(C0051e eVar, Intent intent, int i, Bundle bundle) {
        this.f153h = true;
        if (i == -1) {
            try {
                C0037a.m134a(this, intent, -1, bundle);
            } finally {
                this.f153h = false;
            }
        } else {
            m181b(i);
            C0037a.m134a(this, intent, ((m180b(eVar) + 1) << 16) + (i & 65535), bundle);
            this.f153h = false;
        }
    }

    /* renamed from: a */
    public void mo305a(C0051e eVar, IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) throws IntentSender.SendIntentException {
        int i5 = i;
        this.f152g = true;
        if (i5 == -1) {
            try {
                C0037a.m135a(this, intentSender, i5, intent, i2, i3, i4, bundle);
                this.f152g = false;
            } catch (Throwable th) {
                Throwable th2 = th;
                this.f152g = false;
                throw th2;
            }
        } else {
            m181b(i5);
            C0037a.m135a(this, intentSender, ((m180b(eVar) + 1) << 16) + (65535 & i5), intent, i2, i3, i4, bundle);
            this.f152g = false;
        }
    }

    /* renamed from: b */
    private int m180b(C0051e eVar) {
        if (this.f155j.mo4175b() >= 65534) {
            throw new IllegalStateException("Too many pending Fragment activity results.");
        }
        while (this.f155j.mo4183f(this.f154i) >= 0) {
            this.f154i = (this.f154i + 1) % 65534;
        }
        int i = this.f154i;
        this.f155j.mo4177b(i, eVar.mWho);
        this.f154i = (this.f154i + 1) % 65534;
        return i;
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo306a(C0051e eVar, String[] strArr, int i) {
        if (i == -1) {
            C0037a.m136a(this, strArr, i);
            return;
        }
        m181b(i);
        try {
            this.f151f = true;
            C0037a.m136a(this, strArr, ((m180b(eVar) + 1) << 16) + (i & 65535));
            this.f151f = false;
        } catch (Throwable th) {
            this.f151f = false;
            throw th;
        }
    }

    /* renamed from: android.support.v4.app.f$a */
    class C0062a extends C0066i<C0060f> {
        public C0062a() {
            super(C0060f.this);
        }

        /* renamed from: a */
        public void mo341a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            C0060f.this.dump(str, fileDescriptor, printWriter, strArr);
        }

        /* renamed from: a */
        public boolean mo342a(C0051e eVar) {
            return !C0060f.this.isFinishing();
        }

        /* renamed from: b */
        public LayoutInflater mo344b() {
            return C0060f.this.getLayoutInflater().cloneInContext(C0060f.this);
        }

        /* renamed from: c */
        public C0060f mo350g() {
            return C0060f.this;
        }

        /* renamed from: d */
        public void mo347d() {
            C0060f.this.mo309c();
        }

        /* renamed from: a */
        public void mo338a(C0051e eVar, Intent intent, int i, Bundle bundle) {
            C0060f.this.mo304a(eVar, intent, i, bundle);
        }

        /* renamed from: a */
        public void mo339a(C0051e eVar, IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) throws IntentSender.SendIntentException {
            C0060f.this.mo305a(eVar, intentSender, i, intent, i2, i3, i4, bundle);
        }

        /* renamed from: a */
        public void mo340a(C0051e eVar, String[] strArr, int i) {
            C0060f.this.mo306a(eVar, strArr, i);
        }

        /* renamed from: a */
        public boolean mo343a(String str) {
            return C0037a.m137a(C0060f.this, str);
        }

        /* renamed from: e */
        public boolean mo348e() {
            return C0060f.this.getWindow() != null;
        }

        /* renamed from: f */
        public int mo349f() {
            Window window = C0060f.this.getWindow();
            if (window == null) {
                return 0;
            }
            return window.getAttributes().windowAnimations;
        }

        /* renamed from: b */
        public void mo345b(C0051e eVar) {
            C0060f.this.mo303a(eVar);
        }

        /* renamed from: a */
        public View mo289a(int i) {
            return C0060f.this.findViewById(i);
        }

        /* renamed from: a */
        public boolean mo290a() {
            Window window = C0060f.this.getWindow();
            return (window == null || window.peekDecorView() == null) ? false : true;
        }
    }

    /* renamed from: e */
    private void m182e() {
        do {
        } while (m179a(mo310d(), C0012c.C0014b.CREATED));
    }

    /* renamed from: a */
    private static boolean m179a(C0067j jVar, C0012c.C0014b bVar) {
        boolean z = false;
        for (C0051e next : jVar.mo384c()) {
            if (next != null) {
                if (next.getLifecycle().mo39a().mo42a(C0012c.C0014b.STARTED)) {
                    next.mLifecycleRegistry.mo45a(bVar);
                    z = true;
                }
                C0067j peekChildFragmentManager = next.peekChildFragmentManager();
                if (peekChildFragmentManager != null) {
                    z |= m179a(peekChildFragmentManager, bVar);
                }
            }
        }
        return z;
    }
}
