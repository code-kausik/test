package android.support.p001v4.app;

import android.arch.lifecycle.C0031p;
import java.util.List;

/* renamed from: android.support.v4.app.l */
public class C0086l {

    /* renamed from: a */
    private final List<C0051e> f234a;

    /* renamed from: b */
    private final List<C0086l> f235b;

    /* renamed from: c */
    private final List<C0031p> f236c;

    C0086l(List<C0051e> list, List<C0086l> list2, List<C0031p> list3) {
        this.f234a = list;
        this.f235b = list2;
        this.f236c = list3;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public List<C0051e> mo495a() {
        return this.f234a;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public List<C0086l> mo496b() {
        return this.f235b;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: c */
    public List<C0031p> mo497c() {
        return this.f236c;
    }
}
