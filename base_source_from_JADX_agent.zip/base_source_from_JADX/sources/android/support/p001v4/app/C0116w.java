package android.support.p001v4.app;

import android.app.Notification;
import android.os.Bundle;
import android.support.p001v4.app.C0110u;
import android.util.Log;
import android.util.SparseArray;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/* renamed from: android.support.v4.app.w */
class C0116w {

    /* renamed from: a */
    private static final Object f380a = new Object();

    /* renamed from: b */
    private static Field f381b;

    /* renamed from: c */
    private static boolean f382c;

    /* renamed from: d */
    private static final Object f383d = new Object();

    /* renamed from: a */
    public static SparseArray<Bundle> m531a(List<Bundle> list) {
        int size = list.size();
        SparseArray<Bundle> sparseArray = null;
        for (int i = 0; i < size; i++) {
            Bundle bundle = list.get(i);
            if (bundle != null) {
                if (sparseArray == null) {
                    sparseArray = new SparseArray<>();
                }
                sparseArray.put(i, bundle);
            }
        }
        return sparseArray;
    }

    /* renamed from: a */
    public static Bundle m528a(Notification notification) {
        synchronized (f380a) {
            if (f382c) {
                return null;
            }
            try {
                if (f381b == null) {
                    Field declaredField = Notification.class.getDeclaredField("extras");
                    if (!Bundle.class.isAssignableFrom(declaredField.getType())) {
                        Log.e("NotificationCompat", "Notification.extras field is not of type Bundle");
                        f382c = true;
                        return null;
                    }
                    declaredField.setAccessible(true);
                    f381b = declaredField;
                }
                Bundle bundle = (Bundle) f381b.get(notification);
                if (bundle == null) {
                    bundle = new Bundle();
                    f381b.set(notification, bundle);
                }
                return bundle;
            } catch (IllegalAccessException e) {
                Log.e("NotificationCompat", "Unable to access notification extras", e);
                f382c = true;
                return null;
            } catch (NoSuchFieldException e2) {
                Log.e("NotificationCompat", "Unable to access notification extras", e2);
                f382c = true;
                return null;
            }
        }
    }

    /* renamed from: a */
    public static Bundle m527a(Notification.Builder builder, C0110u.C0111a aVar) {
        builder.addAction(aVar.mo556a(), aVar.mo557b(), aVar.mo558c());
        Bundle bundle = new Bundle(aVar.mo559d());
        if (aVar.mo561f() != null) {
            bundle.putParcelableArray("android.support.remoteInputs", m532a(aVar.mo561f()));
        }
        if (aVar.mo563h() != null) {
            bundle.putParcelableArray("android.support.dataRemoteInputs", m532a(aVar.mo563h()));
        }
        bundle.putBoolean("android.support.allowGeneratedReplies", aVar.mo560e());
        return bundle;
    }

    /* renamed from: a */
    static Bundle m529a(C0110u.C0111a aVar) {
        Bundle bundle;
        Bundle bundle2 = new Bundle();
        bundle2.putInt("icon", aVar.mo556a());
        bundle2.putCharSequence("title", aVar.mo557b());
        bundle2.putParcelable("actionIntent", aVar.mo558c());
        if (aVar.mo559d() != null) {
            bundle = new Bundle(aVar.mo559d());
        } else {
            bundle = new Bundle();
        }
        bundle.putBoolean("android.support.allowGeneratedReplies", aVar.mo560e());
        bundle2.putBundle("extras", bundle);
        bundle2.putParcelableArray("remoteInputs", m532a(aVar.mo561f()));
        bundle2.putBoolean("showsUserInterface", aVar.mo564i());
        bundle2.putInt("semanticAction", aVar.mo562g());
        return bundle2;
    }

    /* renamed from: a */
    private static Bundle m530a(C0118y yVar) {
        Bundle bundle = new Bundle();
        bundle.putString("resultKey", yVar.mo597a());
        bundle.putCharSequence("label", yVar.mo598b());
        bundle.putCharSequenceArray("choices", yVar.mo599c());
        bundle.putBoolean("allowFreeFormInput", yVar.mo601e());
        bundle.putBundle("extras", yVar.mo602f());
        Set<String> d = yVar.mo600d();
        if (d != null && !d.isEmpty()) {
            ArrayList arrayList = new ArrayList(d.size());
            for (String add : d) {
                arrayList.add(add);
            }
            bundle.putStringArrayList("allowedDataTypes", arrayList);
        }
        return bundle;
    }

    /* renamed from: a */
    private static Bundle[] m532a(C0118y[] yVarArr) {
        if (yVarArr == null) {
            return null;
        }
        Bundle[] bundleArr = new Bundle[yVarArr.length];
        for (int i = 0; i < yVarArr.length; i++) {
            bundleArr[i] = m530a(yVarArr[i]);
        }
        return bundleArr;
    }
}
