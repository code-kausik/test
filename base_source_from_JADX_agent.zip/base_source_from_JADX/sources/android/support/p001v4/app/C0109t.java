package android.support.p001v4.app;

import android.app.Notification;

/* renamed from: android.support.v4.app.t */
public interface C0109t {
    /* renamed from: a */
    Notification.Builder mo555a();
}
