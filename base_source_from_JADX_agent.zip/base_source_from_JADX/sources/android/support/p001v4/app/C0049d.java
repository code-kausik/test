package android.support.p001v4.app;

import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* renamed from: android.support.v4.app.d */
public final class C0049d {

    /* renamed from: android.support.v4.app.d$a */
    static class C0050a {

        /* renamed from: a */
        private static Method f121a;

        /* renamed from: b */
        private static boolean f122b;

        /* renamed from: a */
        public static IBinder m170a(Bundle bundle, String str) {
            if (!f122b) {
                try {
                    f121a = Bundle.class.getMethod("getIBinder", new Class[]{String.class});
                    f121a.setAccessible(true);
                } catch (NoSuchMethodException e) {
                    Log.i("BundleCompatBaseImpl", "Failed to retrieve getIBinder method", e);
                }
                f122b = true;
            }
            if (f121a != null) {
                try {
                    return (IBinder) f121a.invoke(bundle, new Object[]{str});
                } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e2) {
                    Log.i("BundleCompatBaseImpl", "Failed to invoke getIBinder via reflection", e2);
                    f121a = null;
                }
            }
            return null;
        }
    }

    /* renamed from: a */
    public static IBinder m169a(Bundle bundle, String str) {
        if (Build.VERSION.SDK_INT >= 18) {
            return bundle.getBinder(str);
        }
        return C0050a.m170a(bundle, str);
    }
}
