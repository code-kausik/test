package android.support.p001v4.app;

import android.util.AndroidRuntimeException;

/* renamed from: android.support.v4.app.aa */
final class C0042aa extends AndroidRuntimeException {
    public C0042aa(String str) {
        super(str);
    }
}
