package android.support.p001v4.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

/* renamed from: android.support.v4.app.g */
public abstract class C0064g {
    /* renamed from: a */
    public abstract View mo289a(int i);

    /* renamed from: a */
    public abstract boolean mo290a();

    /* renamed from: a */
    public C0051e mo288a(Context context, String str, Bundle bundle) {
        return C0051e.instantiate(context, str, bundle);
    }
}
