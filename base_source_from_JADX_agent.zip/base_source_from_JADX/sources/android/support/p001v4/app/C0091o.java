package android.support.p001v4.app;

/* renamed from: android.support.v4.app.o */
public abstract class C0091o {
    /* renamed from: a */
    public abstract C0091o mo103a(C0051e eVar, String str);

    /* renamed from: b */
    public abstract int mo112b();
}
