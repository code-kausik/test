package android.support.p001v4.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

/* renamed from: android.support.v4.graphics.drawable.IconCompat */
public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: h */
    static final PorterDuff.Mode f393h = PorterDuff.Mode.SRC_IN;

    /* renamed from: a */
    public int f394a;

    /* renamed from: b */
    Object f395b;

    /* renamed from: c */
    public byte[] f396c;

    /* renamed from: d */
    public Parcelable f397d;

    /* renamed from: e */
    public int f398e;

    /* renamed from: f */
    public int f399f;

    /* renamed from: g */
    public ColorStateList f400g = null;

    /* renamed from: i */
    PorterDuff.Mode f401i = f393h;

    /* renamed from: j */
    public String f402j;

    /* renamed from: a */
    private static String m546a(int i) {
        switch (i) {
            case 1:
                return "BITMAP";
            case 2:
                return "RESOURCE";
            case 3:
                return "DATA";
            case 4:
                return "URI";
            case 5:
                return "BITMAP_MASKABLE";
            default:
                return "UNKNOWN";
        }
    }

    /* renamed from: a */
    public String mo606a() {
        if (this.f394a == -1 && Build.VERSION.SDK_INT >= 23) {
            return m547a((Icon) this.f395b);
        }
        if (this.f394a == 2) {
            return ((String) this.f395b).split(":", -1)[0];
        }
        throw new IllegalStateException("called getResPackage() on " + this);
    }

    /* renamed from: b */
    public int mo608b() {
        if (this.f394a == -1 && Build.VERSION.SDK_INT >= 23) {
            return m548b((Icon) this.f395b);
        }
        if (this.f394a == 2) {
            return this.f398e;
        }
        throw new IllegalStateException("called getResId() on " + this);
    }

    public String toString() {
        if (this.f394a == -1) {
            return String.valueOf(this.f395b);
        }
        StringBuilder sb = new StringBuilder("Icon(typ=");
        sb.append(m546a(this.f394a));
        switch (this.f394a) {
            case 1:
            case 5:
                sb.append(" size=");
                sb.append(((Bitmap) this.f395b).getWidth());
                sb.append("x");
                sb.append(((Bitmap) this.f395b).getHeight());
                break;
            case 2:
                sb.append(" pkg=");
                sb.append(mo606a());
                sb.append(" id=");
                sb.append(String.format("0x%08x", new Object[]{Integer.valueOf(mo608b())}));
                break;
            case 3:
                sb.append(" len=");
                sb.append(this.f398e);
                if (this.f399f != 0) {
                    sb.append(" off=");
                    sb.append(this.f399f);
                    break;
                }
                break;
            case 4:
                sb.append(" uri=");
                sb.append(this.f395b);
                break;
        }
        if (this.f400g != null) {
            sb.append(" tint=");
            sb.append(this.f400g);
        }
        if (this.f401i != f393h) {
            sb.append(" mode=");
            sb.append(this.f401i);
        }
        sb.append(")");
        return sb.toString();
    }

    /* renamed from: a */
    public void mo607a(boolean z) {
        this.f402j = this.f401i.name();
        int i = this.f394a;
        if (i != -1) {
            switch (i) {
                case 1:
                case 5:
                    if (z) {
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        ((Bitmap) this.f395b).compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
                        this.f396c = byteArrayOutputStream.toByteArray();
                        return;
                    }
                    this.f397d = (Parcelable) this.f395b;
                    return;
                case 2:
                    this.f396c = ((String) this.f395b).getBytes(Charset.forName("UTF-16"));
                    return;
                case 3:
                    this.f396c = (byte[]) this.f395b;
                    return;
                case 4:
                    this.f396c = this.f395b.toString().getBytes(Charset.forName("UTF-16"));
                    return;
                default:
                    return;
            }
        } else if (z) {
            throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
        } else {
            this.f397d = (Parcelable) this.f395b;
        }
    }

    /* renamed from: c */
    public void mo609c() {
        this.f401i = PorterDuff.Mode.valueOf(this.f402j);
        int i = this.f394a;
        if (i != -1) {
            switch (i) {
                case 1:
                case 5:
                    if (this.f397d != null) {
                        this.f395b = this.f397d;
                        return;
                    }
                    this.f395b = this.f396c;
                    this.f394a = 3;
                    this.f398e = 0;
                    this.f399f = this.f396c.length;
                    return;
                case 2:
                case 4:
                    this.f395b = new String(this.f396c, Charset.forName("UTF-16"));
                    return;
                case 3:
                    this.f395b = this.f396c;
                    return;
                default:
                    return;
            }
        } else if (this.f397d != null) {
            this.f395b = this.f397d;
        } else {
            throw new IllegalArgumentException("Invalid icon");
        }
    }

    /* renamed from: a */
    private static String m547a(Icon icon) {
        if (Build.VERSION.SDK_INT >= 28) {
            return icon.getResPackage();
        }
        try {
            return (String) icon.getClass().getMethod("getResPackage", new Class[0]).invoke(icon, new Object[0]);
        } catch (IllegalAccessException e) {
            Log.e("IconCompat", "Unable to get icon package", e);
            return null;
        } catch (InvocationTargetException e2) {
            Log.e("IconCompat", "Unable to get icon package", e2);
            return null;
        } catch (NoSuchMethodException e3) {
            Log.e("IconCompat", "Unable to get icon package", e3);
            return null;
        }
    }

    /* renamed from: b */
    private static int m548b(Icon icon) {
        if (Build.VERSION.SDK_INT >= 28) {
            return icon.getResId();
        }
        try {
            return ((Integer) icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException e) {
            Log.e("IconCompat", "Unable to get icon resource", e);
            return 0;
        } catch (InvocationTargetException e2) {
            Log.e("IconCompat", "Unable to get icon resource", e2);
            return 0;
        } catch (NoSuchMethodException e3) {
            Log.e("IconCompat", "Unable to get icon resource", e3);
            return 0;
        }
    }
}
