package android.support.p001v4.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.p001v4.media.C0131d;
import android.support.p001v4.media.C0133e;
import android.text.TextUtils;

/* renamed from: android.support.v4.media.MediaDescriptionCompat */
public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new Parcelable.Creator<MediaDescriptionCompat>() {
        /* renamed from: a */
        public MediaDescriptionCompat createFromParcel(Parcel parcel) {
            if (Build.VERSION.SDK_INT < 21) {
                return new MediaDescriptionCompat(parcel);
            }
            return MediaDescriptionCompat.m567a(C0131d.m589a(parcel));
        }

        /* renamed from: a */
        public MediaDescriptionCompat[] newArray(int i) {
            return new MediaDescriptionCompat[i];
        }
    };

    /* renamed from: a */
    private final String f417a;

    /* renamed from: b */
    private final CharSequence f418b;

    /* renamed from: c */
    private final CharSequence f419c;

    /* renamed from: d */
    private final CharSequence f420d;

    /* renamed from: e */
    private final Bitmap f421e;

    /* renamed from: f */
    private final Uri f422f;

    /* renamed from: g */
    private final Bundle f423g;

    /* renamed from: h */
    private final Uri f424h;

    /* renamed from: i */
    private Object f425i;

    public int describeContents() {
        return 0;
    }

    MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.f417a = str;
        this.f418b = charSequence;
        this.f419c = charSequence2;
        this.f420d = charSequence3;
        this.f421e = bitmap;
        this.f422f = uri;
        this.f423g = bundle;
        this.f424h = uri2;
    }

    MediaDescriptionCompat(Parcel parcel) {
        this.f417a = parcel.readString();
        this.f418b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f419c = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f420d = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        ClassLoader classLoader = getClass().getClassLoader();
        this.f421e = (Bitmap) parcel.readParcelable(classLoader);
        this.f422f = (Uri) parcel.readParcelable(classLoader);
        this.f423g = parcel.readBundle(classLoader);
        this.f424h = (Uri) parcel.readParcelable(classLoader);
    }

    public void writeToParcel(Parcel parcel, int i) {
        if (Build.VERSION.SDK_INT < 21) {
            parcel.writeString(this.f417a);
            TextUtils.writeToParcel(this.f418b, parcel, i);
            TextUtils.writeToParcel(this.f419c, parcel, i);
            TextUtils.writeToParcel(this.f420d, parcel, i);
            parcel.writeParcelable(this.f421e, i);
            parcel.writeParcelable(this.f422f, i);
            parcel.writeBundle(this.f423g);
            parcel.writeParcelable(this.f424h, i);
            return;
        }
        C0131d.m591a(mo629a(), parcel, i);
    }

    public String toString() {
        return this.f418b + ", " + this.f419c + ", " + this.f420d;
    }

    /* renamed from: a */
    public Object mo629a() {
        if (this.f425i != null || Build.VERSION.SDK_INT < 21) {
            return this.f425i;
        }
        Object a = C0131d.C0132a.m598a();
        C0131d.C0132a.m604a(a, this.f417a);
        C0131d.C0132a.m603a(a, this.f418b);
        C0131d.C0132a.m605b(a, this.f419c);
        C0131d.C0132a.m606c(a, this.f420d);
        C0131d.C0132a.m600a(a, this.f421e);
        C0131d.C0132a.m601a(a, this.f422f);
        Bundle bundle = this.f423g;
        if (Build.VERSION.SDK_INT < 23 && this.f424h != null) {
            if (bundle == null) {
                bundle = new Bundle();
                bundle.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
            }
            bundle.putParcelable("android.support.v4.media.description.MEDIA_URI", this.f424h);
        }
        C0131d.C0132a.m602a(a, bundle);
        if (Build.VERSION.SDK_INT >= 23) {
            C0133e.C0134a.m608a(a, this.f424h);
        }
        this.f425i = C0131d.C0132a.m599a(a);
        return this.f425i;
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x006d  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0071  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.support.p001v4.media.MediaDescriptionCompat m567a(java.lang.Object r6) {
        /*
            r0 = 0
            if (r6 == 0) goto L_0x0085
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 21
            if (r1 < r2) goto L_0x0085
            android.support.v4.media.MediaDescriptionCompat$a r1 = new android.support.v4.media.MediaDescriptionCompat$a
            r1.<init>()
            java.lang.String r2 = android.support.p001v4.media.C0131d.m590a((java.lang.Object) r6)
            r1.mo641a((java.lang.String) r2)
            java.lang.CharSequence r2 = android.support.p001v4.media.C0131d.m592b(r6)
            r1.mo640a((java.lang.CharSequence) r2)
            java.lang.CharSequence r2 = android.support.p001v4.media.C0131d.m593c(r6)
            r1.mo644b((java.lang.CharSequence) r2)
            java.lang.CharSequence r2 = android.support.p001v4.media.C0131d.m594d(r6)
            r1.mo645c(r2)
            android.graphics.Bitmap r2 = android.support.p001v4.media.C0131d.m595e(r6)
            r1.mo637a((android.graphics.Bitmap) r2)
            android.net.Uri r2 = android.support.p001v4.media.C0131d.m596f(r6)
            r1.mo638a((android.net.Uri) r2)
            android.os.Bundle r2 = android.support.p001v4.media.C0131d.m597g(r6)
            if (r2 == 0) goto L_0x004a
            android.support.p001v4.media.session.MediaSessionCompat.m651a(r2)
            java.lang.String r3 = "android.support.v4.media.description.MEDIA_URI"
            android.os.Parcelable r3 = r2.getParcelable(r3)
            android.net.Uri r3 = (android.net.Uri) r3
            goto L_0x004b
        L_0x004a:
            r3 = r0
        L_0x004b:
            if (r3 == 0) goto L_0x0067
            java.lang.String r4 = "android.support.v4.media.description.NULL_BUNDLE_FLAG"
            boolean r4 = r2.containsKey(r4)
            if (r4 == 0) goto L_0x005d
            int r4 = r2.size()
            r5 = 2
            if (r4 != r5) goto L_0x005d
            goto L_0x0068
        L_0x005d:
            java.lang.String r0 = "android.support.v4.media.description.MEDIA_URI"
            r2.remove(r0)
            java.lang.String r0 = "android.support.v4.media.description.NULL_BUNDLE_FLAG"
            r2.remove(r0)
        L_0x0067:
            r0 = r2
        L_0x0068:
            r1.mo639a((android.os.Bundle) r0)
            if (r3 == 0) goto L_0x0071
            r1.mo643b((android.net.Uri) r3)
            goto L_0x007e
        L_0x0071:
            int r0 = android.os.Build.VERSION.SDK_INT
            r2 = 23
            if (r0 < r2) goto L_0x007e
            android.net.Uri r0 = android.support.p001v4.media.C0133e.m607a(r6)
            r1.mo643b((android.net.Uri) r0)
        L_0x007e:
            android.support.v4.media.MediaDescriptionCompat r0 = r1.mo642a()
            r0.f425i = r6
            return r0
        L_0x0085:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.media.MediaDescriptionCompat.m567a(java.lang.Object):android.support.v4.media.MediaDescriptionCompat");
    }

    /* renamed from: android.support.v4.media.MediaDescriptionCompat$a */
    public static final class C0125a {

        /* renamed from: a */
        private String f426a;

        /* renamed from: b */
        private CharSequence f427b;

        /* renamed from: c */
        private CharSequence f428c;

        /* renamed from: d */
        private CharSequence f429d;

        /* renamed from: e */
        private Bitmap f430e;

        /* renamed from: f */
        private Uri f431f;

        /* renamed from: g */
        private Bundle f432g;

        /* renamed from: h */
        private Uri f433h;

        /* renamed from: a */
        public C0125a mo641a(String str) {
            this.f426a = str;
            return this;
        }

        /* renamed from: a */
        public C0125a mo640a(CharSequence charSequence) {
            this.f427b = charSequence;
            return this;
        }

        /* renamed from: b */
        public C0125a mo644b(CharSequence charSequence) {
            this.f428c = charSequence;
            return this;
        }

        /* renamed from: c */
        public C0125a mo645c(CharSequence charSequence) {
            this.f429d = charSequence;
            return this;
        }

        /* renamed from: a */
        public C0125a mo637a(Bitmap bitmap) {
            this.f430e = bitmap;
            return this;
        }

        /* renamed from: a */
        public C0125a mo638a(Uri uri) {
            this.f431f = uri;
            return this;
        }

        /* renamed from: a */
        public C0125a mo639a(Bundle bundle) {
            this.f432g = bundle;
            return this;
        }

        /* renamed from: b */
        public C0125a mo643b(Uri uri) {
            this.f433h = uri;
            return this;
        }

        /* renamed from: a */
        public MediaDescriptionCompat mo642a() {
            return new MediaDescriptionCompat(this.f426a, this.f427b, this.f428c, this.f429d, this.f430e, this.f431f, this.f432g, this.f433h);
        }
    }
}
