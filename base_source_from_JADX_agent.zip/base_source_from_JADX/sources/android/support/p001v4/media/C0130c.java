package android.support.p001v4.media;

import java.util.Arrays;

/* renamed from: android.support.v4.media.c */
class C0130c implements C0128a {

    /* renamed from: a */
    int f444a = 0;

    /* renamed from: b */
    int f445b = 0;

    /* renamed from: c */
    int f446c = 0;

    /* renamed from: d */
    int f447d = -1;

    C0130c() {
    }

    /* renamed from: a */
    public int mo662a() {
        if (this.f447d != -1) {
            return this.f447d;
        }
        return AudioAttributesCompat.m553a(false, this.f446c, this.f444a);
    }

    /* renamed from: b */
    public int mo663b() {
        return this.f445b;
    }

    /* renamed from: c */
    public int mo664c() {
        return this.f444a;
    }

    /* renamed from: d */
    public int mo665d() {
        int i = this.f446c;
        int a = mo662a();
        if (a == 6) {
            i |= 4;
        } else if (a == 7) {
            i |= 1;
        }
        return i & 273;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f445b), Integer.valueOf(this.f446c), Integer.valueOf(this.f444a), Integer.valueOf(this.f447d)});
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0130c)) {
            return false;
        }
        C0130c cVar = (C0130c) obj;
        if (this.f445b == cVar.mo663b() && this.f446c == cVar.mo665d() && this.f444a == cVar.mo664c() && this.f447d == cVar.f447d) {
            return true;
        }
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("AudioAttributesCompat:");
        if (this.f447d != -1) {
            sb.append(" stream=");
            sb.append(this.f447d);
            sb.append(" derived");
        }
        sb.append(" usage=");
        sb.append(AudioAttributesCompat.m554a(this.f444a));
        sb.append(" content=");
        sb.append(this.f445b);
        sb.append(" flags=0x");
        sb.append(Integer.toHexString(this.f446c).toUpperCase());
        return sb.toString();
    }
}
