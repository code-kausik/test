package android.support.p001v4.media;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.p001v4.media.session.MediaSessionCompat;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

/* renamed from: android.support.v4.media.MediaBrowserCompat */
public final class MediaBrowserCompat {

    /* renamed from: a */
    static final boolean f406a = Log.isLoggable("MediaBrowserCompat", 3);

    /* renamed from: android.support.v4.media.MediaBrowserCompat$a */
    public static abstract class C0121a {
        /* renamed from: a */
        public void mo622a(String str, Bundle bundle, Bundle bundle2) {
        }

        /* renamed from: b */
        public void mo623b(String str, Bundle bundle, Bundle bundle2) {
        }

        /* renamed from: c */
        public void mo624c(String str, Bundle bundle, Bundle bundle2) {
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$b */
    public static abstract class C0122b {
        /* renamed from: a */
        public void mo625a(MediaItem mediaItem) {
        }

        /* renamed from: a */
        public void mo626a(String str) {
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$c */
    public static abstract class C0123c {
        /* renamed from: a */
        public void mo627a(String str, Bundle bundle) {
        }

        /* renamed from: a */
        public void mo628a(String str, Bundle bundle, List<MediaItem> list) {
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$MediaItem */
    public static class MediaItem implements Parcelable {
        public static final Parcelable.Creator<MediaItem> CREATOR = new Parcelable.Creator<MediaItem>() {
            /* renamed from: a */
            public MediaItem createFromParcel(Parcel parcel) {
                return new MediaItem(parcel);
            }

            /* renamed from: a */
            public MediaItem[] newArray(int i) {
                return new MediaItem[i];
            }
        };

        /* renamed from: a */
        private final int f412a;

        /* renamed from: b */
        private final MediaDescriptionCompat f413b;

        public int describeContents() {
            return 0;
        }

        MediaItem(Parcel parcel) {
            this.f412a = parcel.readInt();
            this.f413b = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f412a);
            this.f413b.writeToParcel(parcel, i);
        }

        public String toString() {
            return "MediaItem{" + "mFlags=" + this.f412a + ", mDescription=" + this.f413b + '}';
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$ItemReceiver */
    private static class ItemReceiver extends C0314l {

        /* renamed from: d */
        private final String f410d;

        /* renamed from: e */
        private final C0122b f411e;

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo614a(int i, Bundle bundle) {
            MediaSessionCompat.m651a(bundle);
            if (i != 0 || bundle == null || !bundle.containsKey("media_item")) {
                this.f411e.mo626a(this.f410d);
                return;
            }
            Parcelable parcelable = bundle.getParcelable("media_item");
            if (parcelable == null || (parcelable instanceof MediaItem)) {
                this.f411e.mo625a((MediaItem) parcelable);
            } else {
                this.f411e.mo626a(this.f410d);
            }
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$SearchResultReceiver */
    private static class SearchResultReceiver extends C0314l {

        /* renamed from: d */
        private final String f414d;

        /* renamed from: e */
        private final Bundle f415e;

        /* renamed from: f */
        private final C0123c f416f;

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo614a(int i, Bundle bundle) {
            MediaSessionCompat.m651a(bundle);
            if (i != 0 || bundle == null || !bundle.containsKey("search_results")) {
                this.f416f.mo627a(this.f414d, this.f415e);
                return;
            }
            Parcelable[] parcelableArray = bundle.getParcelableArray("search_results");
            ArrayList arrayList = null;
            if (parcelableArray != null) {
                arrayList = new ArrayList();
                for (Parcelable parcelable : parcelableArray) {
                    arrayList.add((MediaItem) parcelable);
                }
            }
            this.f416f.mo628a(this.f414d, this.f415e, arrayList);
        }
    }

    /* renamed from: android.support.v4.media.MediaBrowserCompat$CustomActionResultReceiver */
    private static class CustomActionResultReceiver extends C0314l {

        /* renamed from: d */
        private final String f407d;

        /* renamed from: e */
        private final Bundle f408e;

        /* renamed from: f */
        private final C0121a f409f;

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void mo614a(int i, Bundle bundle) {
            if (this.f409f != null) {
                MediaSessionCompat.m651a(bundle);
                switch (i) {
                    case -1:
                        this.f409f.mo624c(this.f407d, this.f408e, bundle);
                        return;
                    case 0:
                        this.f409f.mo623b(this.f407d, this.f408e, bundle);
                        return;
                    case 1:
                        this.f409f.mo622a(this.f407d, this.f408e, bundle);
                        return;
                    default:
                        Log.w("MediaBrowserCompat", "Unknown result code: " + i + " (extras=" + this.f408e + ", resultData=" + bundle + ")");
                        return;
                }
            }
        }
    }
}
