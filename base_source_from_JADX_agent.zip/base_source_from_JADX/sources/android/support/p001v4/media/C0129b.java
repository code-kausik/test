package android.support.p001v4.media;

import android.annotation.TargetApi;
import android.media.AudioAttributes;

@TargetApi(21)
/* renamed from: android.support.v4.media.b */
class C0129b implements C0128a {

    /* renamed from: a */
    AudioAttributes f442a;

    /* renamed from: b */
    int f443b = -1;

    C0129b() {
    }

    public int hashCode() {
        return this.f442a.hashCode();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0129b)) {
            return false;
        }
        return this.f442a.equals(((C0129b) obj).f442a);
    }

    public String toString() {
        return "AudioAttributesCompat: audioattributes=" + this.f442a;
    }
}
