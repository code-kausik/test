package android.support.p001v4.media.session;

import android.media.session.MediaSession;

/* renamed from: android.support.v4.media.session.d */
class C0158d {

    /* renamed from: android.support.v4.media.session.d$a */
    static class C0159a {
        /* renamed from: a */
        public static Object m809a(Object obj) {
            return ((MediaSession.QueueItem) obj).getDescription();
        }

        /* renamed from: b */
        public static long m810b(Object obj) {
            return ((MediaSession.QueueItem) obj).getQueueId();
        }
    }
}
