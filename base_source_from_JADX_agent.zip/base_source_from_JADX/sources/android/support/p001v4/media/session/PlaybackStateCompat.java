package android.support.p001v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.p001v4.media.session.C0160e;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;

/* renamed from: android.support.v4.media.session.PlaybackStateCompat */
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new Parcelable.Creator<PlaybackStateCompat>() {
        /* renamed from: a */
        public PlaybackStateCompat createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        /* renamed from: a */
        public PlaybackStateCompat[] newArray(int i) {
            return new PlaybackStateCompat[i];
        }
    };

    /* renamed from: a */
    final int f477a;

    /* renamed from: b */
    final long f478b;

    /* renamed from: c */
    final long f479c;

    /* renamed from: d */
    final float f480d;

    /* renamed from: e */
    final long f481e;

    /* renamed from: f */
    final int f482f;

    /* renamed from: g */
    final CharSequence f483g;

    /* renamed from: h */
    final long f484h;

    /* renamed from: i */
    List<CustomAction> f485i;

    /* renamed from: j */
    final long f486j;

    /* renamed from: k */
    final Bundle f487k;

    /* renamed from: l */
    private Object f488l;

    public int describeContents() {
        return 0;
    }

    PlaybackStateCompat(int i, long j, long j2, float f, long j3, int i2, CharSequence charSequence, long j4, List<CustomAction> list, long j5, Bundle bundle) {
        this.f477a = i;
        this.f478b = j;
        this.f479c = j2;
        this.f480d = f;
        this.f481e = j3;
        this.f482f = i2;
        this.f483g = charSequence;
        this.f484h = j4;
        this.f485i = new ArrayList(list);
        this.f486j = j5;
        this.f487k = bundle;
    }

    PlaybackStateCompat(Parcel parcel) {
        this.f477a = parcel.readInt();
        this.f478b = parcel.readLong();
        this.f480d = parcel.readFloat();
        this.f484h = parcel.readLong();
        this.f479c = parcel.readLong();
        this.f481e = parcel.readLong();
        this.f483g = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f485i = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f486j = parcel.readLong();
        this.f487k = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        this.f482f = parcel.readInt();
    }

    public String toString() {
        return "PlaybackState {" + "state=" + this.f477a + ", position=" + this.f478b + ", buffered position=" + this.f479c + ", speed=" + this.f480d + ", updated=" + this.f484h + ", actions=" + this.f481e + ", error code=" + this.f482f + ", error message=" + this.f483g + ", custom actions=" + this.f485i + ", active item id=" + this.f486j + "}";
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f477a);
        parcel.writeLong(this.f478b);
        parcel.writeFloat(this.f480d);
        parcel.writeLong(this.f484h);
        parcel.writeLong(this.f479c);
        parcel.writeLong(this.f481e);
        TextUtils.writeToParcel(this.f483g, parcel, i);
        parcel.writeTypedList(this.f485i);
        parcel.writeLong(this.f486j);
        parcel.writeBundle(this.f487k);
        parcel.writeInt(this.f482f);
    }

    /* renamed from: a */
    public static PlaybackStateCompat m665a(Object obj) {
        ArrayList arrayList;
        Object obj2 = obj;
        Bundle bundle = null;
        if (obj2 == null || Build.VERSION.SDK_INT < 21) {
            return null;
        }
        List<Object> h = C0160e.m818h(obj);
        if (h != null) {
            ArrayList arrayList2 = new ArrayList(h.size());
            for (Object a : h) {
                arrayList2.add(CustomAction.m668a(a));
            }
            arrayList = arrayList2;
        } else {
            arrayList = null;
        }
        if (Build.VERSION.SDK_INT >= 22) {
            bundle = C0162f.m824a(obj);
        }
        PlaybackStateCompat playbackStateCompat = new PlaybackStateCompat(C0160e.m811a(obj), C0160e.m812b(obj), C0160e.m813c(obj), C0160e.m814d(obj), C0160e.m815e(obj), 0, C0160e.m816f(obj), C0160e.m817g(obj), arrayList, C0160e.m819i(obj), bundle);
        playbackStateCompat.f488l = obj2;
        return playbackStateCompat;
    }

    /* renamed from: android.support.v4.media.session.PlaybackStateCompat$CustomAction */
    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new Parcelable.Creator<CustomAction>() {
            /* renamed from: a */
            public CustomAction createFromParcel(Parcel parcel) {
                return new CustomAction(parcel);
            }

            /* renamed from: a */
            public CustomAction[] newArray(int i) {
                return new CustomAction[i];
            }
        };

        /* renamed from: a */
        private final String f489a;

        /* renamed from: b */
        private final CharSequence f490b;

        /* renamed from: c */
        private final int f491c;

        /* renamed from: d */
        private final Bundle f492d;

        /* renamed from: e */
        private Object f493e;

        public int describeContents() {
            return 0;
        }

        CustomAction(String str, CharSequence charSequence, int i, Bundle bundle) {
            this.f489a = str;
            this.f490b = charSequence;
            this.f491c = i;
            this.f492d = bundle;
        }

        CustomAction(Parcel parcel) {
            this.f489a = parcel.readString();
            this.f490b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f491c = parcel.readInt();
            this.f492d = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(this.f489a);
            TextUtils.writeToParcel(this.f490b, parcel, i);
            parcel.writeInt(this.f491c);
            parcel.writeBundle(this.f492d);
        }

        /* renamed from: a */
        public static CustomAction m668a(Object obj) {
            if (obj == null || Build.VERSION.SDK_INT < 21) {
                return null;
            }
            CustomAction customAction = new CustomAction(C0160e.C0161a.m820a(obj), C0160e.C0161a.m821b(obj), C0160e.C0161a.m822c(obj), C0160e.C0161a.m823d(obj));
            customAction.f493e = obj;
            return customAction;
        }

        public String toString() {
            return "Action:mName='" + this.f490b + ", mIcon=" + this.f491c + ", mExtras=" + this.f492d;
        }
    }
}
