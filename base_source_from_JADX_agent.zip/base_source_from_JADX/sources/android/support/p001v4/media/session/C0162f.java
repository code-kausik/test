package android.support.p001v4.media.session;

import android.media.session.PlaybackState;
import android.os.Bundle;

/* renamed from: android.support.v4.media.session.f */
class C0162f {
    /* renamed from: a */
    public static Bundle m824a(Object obj) {
        return ((PlaybackState) obj).getExtras();
    }
}
