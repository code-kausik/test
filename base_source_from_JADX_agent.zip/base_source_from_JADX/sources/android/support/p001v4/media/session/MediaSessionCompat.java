package android.support.p001v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.p001v4.media.MediaDescriptionCompat;
import android.support.p001v4.media.session.C0158d;
import java.util.ArrayList;
import java.util.List;

/* renamed from: android.support.v4.media.session.MediaSessionCompat */
public class MediaSessionCompat {
    /* renamed from: a */
    public static void m651a(Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(MediaSessionCompat.class.getClassLoader());
        }
    }

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$Token */
    public static final class Token implements Parcelable {
        public static final Parcelable.Creator<Token> CREATOR = new Parcelable.Creator<Token>() {
            /* renamed from: a */
            public Token createFromParcel(Parcel parcel) {
                Object obj;
                if (Build.VERSION.SDK_INT >= 21) {
                    obj = parcel.readParcelable((ClassLoader) null);
                } else {
                    obj = parcel.readStrongBinder();
                }
                return new Token(obj);
            }

            /* renamed from: a */
            public Token[] newArray(int i) {
                return new Token[i];
            }
        };

        /* renamed from: a */
        private final Object f469a;

        /* renamed from: b */
        private C0151b f470b;

        /* renamed from: c */
        private Bundle f471c;

        public int describeContents() {
            return 0;
        }

        Token(Object obj) {
            this(obj, (C0151b) null, (Bundle) null);
        }

        Token(Object obj, C0151b bVar, Bundle bundle) {
            this.f469a = obj;
            this.f470b = bVar;
            this.f471c = bundle;
        }

        public void writeToParcel(Parcel parcel, int i) {
            if (Build.VERSION.SDK_INT >= 21) {
                parcel.writeParcelable((Parcelable) this.f469a, i);
            } else {
                parcel.writeStrongBinder((IBinder) this.f469a);
            }
        }

        public int hashCode() {
            if (this.f469a == null) {
                return 0;
            }
            return this.f469a.hashCode();
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Token)) {
                return false;
            }
            Token token = (Token) obj;
            if (this.f469a == null) {
                if (token.f469a == null) {
                    return true;
                }
                return false;
            } else if (token.f469a == null) {
                return false;
            } else {
                return this.f469a.equals(token.f469a);
            }
        }

        /* renamed from: a */
        public C0151b mo719a() {
            return this.f470b;
        }

        /* renamed from: a */
        public void mo721a(C0151b bVar) {
            this.f470b = bVar;
        }

        /* renamed from: a */
        public void mo720a(Bundle bundle) {
            this.f471c = bundle;
        }
    }

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$QueueItem */
    public static final class QueueItem implements Parcelable {
        public static final Parcelable.Creator<QueueItem> CREATOR = new Parcelable.Creator<QueueItem>() {
            /* renamed from: a */
            public QueueItem createFromParcel(Parcel parcel) {
                return new QueueItem(parcel);
            }

            /* renamed from: a */
            public QueueItem[] newArray(int i) {
                return new QueueItem[i];
            }
        };

        /* renamed from: a */
        private final MediaDescriptionCompat f465a;

        /* renamed from: b */
        private final long f466b;

        /* renamed from: c */
        private Object f467c;

        public int describeContents() {
            return 0;
        }

        private QueueItem(Object obj, MediaDescriptionCompat mediaDescriptionCompat, long j) {
            if (mediaDescriptionCompat == null) {
                throw new IllegalArgumentException("Description cannot be null.");
            } else if (j == -1) {
                throw new IllegalArgumentException("Id cannot be QueueItem.UNKNOWN_ID");
            } else {
                this.f465a = mediaDescriptionCompat;
                this.f466b = j;
                this.f467c = obj;
            }
        }

        QueueItem(Parcel parcel) {
            this.f465a = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
            this.f466b = parcel.readLong();
        }

        public void writeToParcel(Parcel parcel, int i) {
            this.f465a.writeToParcel(parcel, i);
            parcel.writeLong(this.f466b);
        }

        /* renamed from: a */
        public static QueueItem m652a(Object obj) {
            if (obj == null || Build.VERSION.SDK_INT < 21) {
                return null;
            }
            return new QueueItem(obj, MediaDescriptionCompat.m567a(C0158d.C0159a.m809a(obj)), C0158d.C0159a.m810b(obj));
        }

        /* renamed from: a */
        public static List<QueueItem> m653a(List<?> list) {
            if (list == null || Build.VERSION.SDK_INT < 21) {
                return null;
            }
            ArrayList arrayList = new ArrayList();
            for (Object a : list) {
                arrayList.add(m652a((Object) a));
            }
            return arrayList;
        }

        public String toString() {
            return "MediaSession.QueueItem {Description=" + this.f465a + ", Id=" + this.f466b + " }";
        }
    }

    /* renamed from: android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper */
    public static final class ResultReceiverWrapper implements Parcelable {
        public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new Parcelable.Creator<ResultReceiverWrapper>() {
            /* renamed from: a */
            public ResultReceiverWrapper createFromParcel(Parcel parcel) {
                return new ResultReceiverWrapper(parcel);
            }

            /* renamed from: a */
            public ResultReceiverWrapper[] newArray(int i) {
                return new ResultReceiverWrapper[i];
            }
        };

        /* renamed from: a */
        ResultReceiver f468a;

        public int describeContents() {
            return 0;
        }

        ResultReceiverWrapper(Parcel parcel) {
            this.f468a = (ResultReceiver) ResultReceiver.CREATOR.createFromParcel(parcel);
        }

        public void writeToParcel(Parcel parcel, int i) {
            this.f468a.writeToParcel(parcel, i);
        }
    }
}
