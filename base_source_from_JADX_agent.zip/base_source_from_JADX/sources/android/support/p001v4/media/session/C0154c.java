package android.support.p001v4.media.session;

import android.media.AudioAttributes;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import java.util.List;

/* renamed from: android.support.v4.media.session.c */
class C0154c {

    /* renamed from: android.support.v4.media.session.c$a */
    public interface C0155a {
        /* renamed from: a */
        void mo691a();

        /* renamed from: a */
        void mo692a(int i, int i2, int i3, int i4, int i5);

        /* renamed from: a */
        void mo693a(Bundle bundle);

        /* renamed from: a */
        void mo694a(CharSequence charSequence);

        /* renamed from: a */
        void mo695a(Object obj);

        /* renamed from: a */
        void mo696a(String str, Bundle bundle);

        /* renamed from: a */
        void mo697a(List<?> list);

        /* renamed from: b */
        void mo698b(Object obj);
    }

    /* renamed from: a */
    public static Object m797a(C0155a aVar) {
        return new C0156b(aVar);
    }

    /* renamed from: android.support.v4.media.session.c$c */
    public static class C0157c {
        /* renamed from: a */
        public static AudioAttributes m807a(Object obj) {
            return ((MediaController.PlaybackInfo) obj).getAudioAttributes();
        }

        /* renamed from: b */
        public static int m808b(Object obj) {
            return m806a(m807a(obj));
        }

        /* renamed from: a */
        private static int m806a(AudioAttributes audioAttributes) {
            if ((audioAttributes.getFlags() & 1) == 1) {
                return 7;
            }
            if ((audioAttributes.getFlags() & 4) == 4) {
                return 6;
            }
            switch (audioAttributes.getUsage()) {
                case 1:
                case ConnectionResult.LICENSE_CHECK_FAILED /*11*/:
                case 12:
                case 14:
                    return 3;
                case 2:
                    return 0;
                case 3:
                    return 8;
                case 4:
                    return 4;
                case 5:
                case 7:
                case 8:
                case 9:
                case 10:
                    return 5;
                case 6:
                    return 2;
                case 13:
                    return 1;
                default:
                    return 3;
            }
        }
    }

    /* renamed from: android.support.v4.media.session.c$b */
    static class C0156b<T extends C0155a> extends MediaController.Callback {

        /* renamed from: a */
        protected final T f496a;

        public C0156b(T t) {
            this.f496a = t;
        }

        public void onSessionDestroyed() {
            this.f496a.mo691a();
        }

        public void onSessionEvent(String str, Bundle bundle) {
            MediaSessionCompat.m651a(bundle);
            this.f496a.mo696a(str, bundle);
        }

        public void onPlaybackStateChanged(PlaybackState playbackState) {
            this.f496a.mo695a((Object) playbackState);
        }

        public void onMetadataChanged(MediaMetadata mediaMetadata) {
            this.f496a.mo698b(mediaMetadata);
        }

        public void onQueueChanged(List<MediaSession.QueueItem> list) {
            this.f496a.mo697a((List<?>) list);
        }

        public void onQueueTitleChanged(CharSequence charSequence) {
            this.f496a.mo694a(charSequence);
        }

        public void onExtrasChanged(Bundle bundle) {
            MediaSessionCompat.m651a(bundle);
            this.f496a.mo693a(bundle);
        }

        public void onAudioInfoChanged(MediaController.PlaybackInfo playbackInfo) {
            this.f496a.mo692a(playbackInfo.getPlaybackType(), C0157c.m808b(playbackInfo), playbackInfo.getVolumeControl(), playbackInfo.getMaxVolume(), playbackInfo.getCurrentVolume());
        }
    }
}
