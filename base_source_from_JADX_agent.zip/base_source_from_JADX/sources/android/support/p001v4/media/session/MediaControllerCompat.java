package android.support.p001v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.p001v4.app.C0049d;
import android.support.p001v4.media.MediaMetadataCompat;
import android.support.p001v4.media.session.C0148a;
import android.support.p001v4.media.session.C0151b;
import android.support.p001v4.media.session.C0154c;
import android.support.p001v4.media.session.MediaSessionCompat;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.List;

/* renamed from: android.support.v4.media.session.MediaControllerCompat */
public final class MediaControllerCompat {

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$a */
    public static abstract class C0137a implements IBinder.DeathRecipient {

        /* renamed from: a */
        final Object f453a;

        /* renamed from: b */
        C0138a f454b;

        /* renamed from: c */
        C0148a f455c;

        /* renamed from: a */
        public void mo677a() {
        }

        /* renamed from: a */
        public void mo678a(int i) {
        }

        /* renamed from: a */
        public void mo680a(Bundle bundle) {
        }

        /* renamed from: a */
        public void mo681a(MediaMetadataCompat mediaMetadataCompat) {
        }

        /* renamed from: a */
        public void mo682a(C0141b bVar) {
        }

        /* renamed from: a */
        public void mo683a(PlaybackStateCompat playbackStateCompat) {
        }

        /* renamed from: a */
        public void mo684a(CharSequence charSequence) {
        }

        /* renamed from: a */
        public void mo685a(String str, Bundle bundle) {
        }

        /* renamed from: a */
        public void mo686a(List<MediaSessionCompat.QueueItem> list) {
        }

        /* renamed from: a */
        public void mo687a(boolean z) {
        }

        /* renamed from: b */
        public void mo688b() {
        }

        /* renamed from: b */
        public void mo689b(int i) {
        }

        public C0137a() {
            if (Build.VERSION.SDK_INT >= 21) {
                this.f453a = C0154c.m797a(new C0139b(this));
                return;
            }
            C0140c cVar = new C0140c(this);
            this.f455c = cVar;
            this.f453a = cVar;
        }

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo679a(int i, Object obj, Bundle bundle) {
            if (this.f454b != null) {
                Message obtainMessage = this.f454b.obtainMessage(i, obj);
                obtainMessage.setData(bundle);
                obtainMessage.sendToTarget();
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$a$b */
        private static class C0139b implements C0154c.C0155a {

            /* renamed from: a */
            private final WeakReference<C0137a> f458a;

            C0139b(C0137a aVar) {
                this.f458a = new WeakReference<>(aVar);
            }

            /* renamed from: a */
            public void mo691a() {
                C0137a aVar = (C0137a) this.f458a.get();
                if (aVar != null) {
                    aVar.mo688b();
                }
            }

            /* renamed from: a */
            public void mo696a(String str, Bundle bundle) {
                C0137a aVar = (C0137a) this.f458a.get();
                if (aVar == null) {
                    return;
                }
                if (aVar.f455c == null || Build.VERSION.SDK_INT >= 23) {
                    aVar.mo685a(str, bundle);
                }
            }

            /* renamed from: a */
            public void mo695a(Object obj) {
                C0137a aVar = (C0137a) this.f458a.get();
                if (aVar != null && aVar.f455c == null) {
                    aVar.mo683a(PlaybackStateCompat.m665a(obj));
                }
            }

            /* renamed from: b */
            public void mo698b(Object obj) {
                C0137a aVar = (C0137a) this.f458a.get();
                if (aVar != null) {
                    aVar.mo681a(MediaMetadataCompat.m580a(obj));
                }
            }

            /* renamed from: a */
            public void mo697a(List<?> list) {
                C0137a aVar = (C0137a) this.f458a.get();
                if (aVar != null) {
                    aVar.mo686a(MediaSessionCompat.QueueItem.m653a(list));
                }
            }

            /* renamed from: a */
            public void mo694a(CharSequence charSequence) {
                C0137a aVar = (C0137a) this.f458a.get();
                if (aVar != null) {
                    aVar.mo684a(charSequence);
                }
            }

            /* renamed from: a */
            public void mo693a(Bundle bundle) {
                C0137a aVar = (C0137a) this.f458a.get();
                if (aVar != null) {
                    aVar.mo680a(bundle);
                }
            }

            /* renamed from: a */
            public void mo692a(int i, int i2, int i3, int i4, int i5) {
                C0137a aVar = (C0137a) this.f458a.get();
                if (aVar != null) {
                    aVar.mo682a(new C0141b(i, i2, i3, i4, i5));
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$a$c */
        private static class C0140c extends C0148a.C0149a {

            /* renamed from: a */
            private final WeakReference<C0137a> f459a;

            /* renamed from: a */
            public void mo702a(boolean z) throws RemoteException {
            }

            C0140c(C0137a aVar) {
                this.f459a = new WeakReference<>(aVar);
            }

            /* renamed from: a */
            public void mo701a(String str, Bundle bundle) throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(1, str, bundle);
                }
            }

            /* renamed from: a */
            public void mo671a() throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(8, (Object) null, (Bundle) null);
                }
            }

            /* renamed from: a */
            public void mo700a(PlaybackStateCompat playbackStateCompat) throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(2, playbackStateCompat, (Bundle) null);
                }
            }

            /* renamed from: a */
            public void mo673a(MediaMetadataCompat mediaMetadataCompat) throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(3, mediaMetadataCompat, (Bundle) null);
                }
            }

            /* renamed from: a */
            public void mo676a(List<MediaSessionCompat.QueueItem> list) throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(5, list, (Bundle) null);
                }
            }

            /* renamed from: a */
            public void mo675a(CharSequence charSequence) throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(6, charSequence, (Bundle) null);
                }
            }

            /* renamed from: b */
            public void mo705b(boolean z) throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(11, Boolean.valueOf(z), (Bundle) null);
                }
            }

            /* renamed from: a */
            public void mo699a(int i) throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(9, Integer.valueOf(i), (Bundle) null);
                }
            }

            /* renamed from: b */
            public void mo704b(int i) throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(12, Integer.valueOf(i), (Bundle) null);
                }
            }

            /* renamed from: a */
            public void mo672a(Bundle bundle) throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(7, bundle, (Bundle) null);
                }
            }

            /* renamed from: a */
            public void mo674a(ParcelableVolumeInfo parcelableVolumeInfo) throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(4, parcelableVolumeInfo != null ? new C0141b(parcelableVolumeInfo.f472a, parcelableVolumeInfo.f473b, parcelableVolumeInfo.f474c, parcelableVolumeInfo.f475d, parcelableVolumeInfo.f476e) : null, (Bundle) null);
                }
            }

            /* renamed from: b */
            public void mo703b() throws RemoteException {
                C0137a aVar = (C0137a) this.f459a.get();
                if (aVar != null) {
                    aVar.mo679a(13, (Object) null, (Bundle) null);
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$a$a */
        private class C0138a extends Handler {

            /* renamed from: a */
            boolean f456a;

            /* renamed from: b */
            final /* synthetic */ C0137a f457b;

            public void handleMessage(Message message) {
                if (this.f456a) {
                    switch (message.what) {
                        case 1:
                            Bundle data = message.getData();
                            MediaSessionCompat.m651a(data);
                            this.f457b.mo685a((String) message.obj, data);
                            return;
                        case 2:
                            this.f457b.mo683a((PlaybackStateCompat) message.obj);
                            return;
                        case 3:
                            this.f457b.mo681a((MediaMetadataCompat) message.obj);
                            return;
                        case 4:
                            this.f457b.mo682a((C0141b) message.obj);
                            return;
                        case 5:
                            this.f457b.mo686a((List<MediaSessionCompat.QueueItem>) (List) message.obj);
                            return;
                        case 6:
                            this.f457b.mo684a((CharSequence) message.obj);
                            return;
                        case 7:
                            Bundle bundle = (Bundle) message.obj;
                            MediaSessionCompat.m651a(bundle);
                            this.f457b.mo680a(bundle);
                            return;
                        case 8:
                            this.f457b.mo688b();
                            return;
                        case 9:
                            this.f457b.mo678a(((Integer) message.obj).intValue());
                            return;
                        case ConnectionResult.LICENSE_CHECK_FAILED /*11*/:
                            this.f457b.mo687a(((Boolean) message.obj).booleanValue());
                            return;
                        case 12:
                            this.f457b.mo689b(((Integer) message.obj).intValue());
                            return;
                        case 13:
                            this.f457b.mo677a();
                            return;
                        default:
                            return;
                    }
                }
            }
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$b */
    public static final class C0141b {

        /* renamed from: a */
        private final int f460a;

        /* renamed from: b */
        private final int f461b;

        /* renamed from: c */
        private final int f462c;

        /* renamed from: d */
        private final int f463d;

        /* renamed from: e */
        private final int f464e;

        C0141b(int i, int i2, int i3, int i4, int i5) {
            this.f460a = i;
            this.f461b = i2;
            this.f462c = i3;
            this.f463d = i4;
            this.f464e = i5;
        }
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21 */
    static class MediaControllerImplApi21 {

        /* renamed from: a */
        final Object f448a;

        /* renamed from: b */
        final MediaSessionCompat.Token f449b;

        /* renamed from: c */
        private final List<C0137a> f450c;

        /* renamed from: d */
        private HashMap<C0137a, C0136a> f451d;

        /* access modifiers changed from: package-private */
        /* renamed from: a */
        public void mo669a() {
            if (this.f449b.mo719a() != null) {
                for (C0137a next : this.f450c) {
                    C0136a aVar = new C0136a(next);
                    this.f451d.put(next, aVar);
                    next.f455c = aVar;
                    try {
                        this.f449b.mo719a().mo761a((C0148a) aVar);
                        next.mo679a(13, (Object) null, (Bundle) null);
                    } catch (RemoteException e) {
                        Log.e("MediaControllerCompat", "Dead object in registerCallback.", e);
                    }
                }
                this.f450c.clear();
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver */
        private static class ExtraBinderRequestResultReceiver extends ResultReceiver {

            /* renamed from: a */
            private WeakReference<MediaControllerImplApi21> f452a;

            /* access modifiers changed from: protected */
            public void onReceiveResult(int i, Bundle bundle) {
                MediaControllerImplApi21 mediaControllerImplApi21 = (MediaControllerImplApi21) this.f452a.get();
                if (mediaControllerImplApi21 != null && bundle != null) {
                    synchronized (mediaControllerImplApi21.f448a) {
                        mediaControllerImplApi21.f449b.mo721a(C0151b.C0152a.m747a(C0049d.m169a(bundle, "android.support.v4.media.session.EXTRA_BINDER")));
                        mediaControllerImplApi21.f449b.mo720a(bundle.getBundle("android.support.v4.media.session.SESSION_TOKEN2_BUNDLE"));
                        mediaControllerImplApi21.mo669a();
                    }
                }
            }
        }

        /* renamed from: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21$a */
        private static class C0136a extends C0137a.C0140c {
            C0136a(C0137a aVar) {
                super(aVar);
            }

            /* renamed from: a */
            public void mo671a() throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: a */
            public void mo673a(MediaMetadataCompat mediaMetadataCompat) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: a */
            public void mo676a(List<MediaSessionCompat.QueueItem> list) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: a */
            public void mo675a(CharSequence charSequence) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: a */
            public void mo672a(Bundle bundle) throws RemoteException {
                throw new AssertionError();
            }

            /* renamed from: a */
            public void mo674a(ParcelableVolumeInfo parcelableVolumeInfo) throws RemoteException {
                throw new AssertionError();
            }
        }
    }
}
