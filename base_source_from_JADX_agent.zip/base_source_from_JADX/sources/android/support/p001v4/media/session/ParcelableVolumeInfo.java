package android.support.p001v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: android.support.v4.media.session.ParcelableVolumeInfo */
public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new Parcelable.Creator<ParcelableVolumeInfo>() {
        /* renamed from: a */
        public ParcelableVolumeInfo createFromParcel(Parcel parcel) {
            return new ParcelableVolumeInfo(parcel);
        }

        /* renamed from: a */
        public ParcelableVolumeInfo[] newArray(int i) {
            return new ParcelableVolumeInfo[i];
        }
    };

    /* renamed from: a */
    public int f472a;

    /* renamed from: b */
    public int f473b;

    /* renamed from: c */
    public int f474c;

    /* renamed from: d */
    public int f475d;

    /* renamed from: e */
    public int f476e;

    public int describeContents() {
        return 0;
    }

    public ParcelableVolumeInfo(Parcel parcel) {
        this.f472a = parcel.readInt();
        this.f474c = parcel.readInt();
        this.f475d = parcel.readInt();
        this.f476e = parcel.readInt();
        this.f473b = parcel.readInt();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f472a);
        parcel.writeInt(this.f474c);
        parcel.writeInt(this.f475d);
        parcel.writeInt(this.f476e);
        parcel.writeInt(this.f473b);
    }
}
