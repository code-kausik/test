package android.support.p001v4.media;

import androidx.versionedparcelable.C0166c;

/* renamed from: android.support.v4.media.a */
interface C0128a extends C0166c {
}
