cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "cordova-plugin-recaptcha.recaptcha",
      "file": "plugins/cordova-plugin-recaptcha/www/recaptcha.js",
      "pluginId": "cordova-plugin-recaptcha",
      "clobbers": [
        "plugins.recaptcha"
      ]
    }
  ];
  module.exports.metadata = {
    "cordova-plugin-whitelist": "1.3.4",
    "cordova-plugin-recaptcha": "1.0.2"
  };
});