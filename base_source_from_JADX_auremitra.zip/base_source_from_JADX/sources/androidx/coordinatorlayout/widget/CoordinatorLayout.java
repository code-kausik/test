package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import p000a.p002b.p003k.C0049r;
import p000a.p023g.C0297c;
import p000a.p023g.p024d.C0298a;
import p000a.p023g.p024d.C0299b;
import p000a.p025h.p027e.C0316a;
import p000a.p025h.p036k.C0375c;
import p000a.p025h.p036k.C0376d;
import p000a.p025h.p037l.C0385f;
import p000a.p025h.p037l.C0386g;
import p000a.p025h.p037l.C0387h;
import p000a.p025h.p037l.C0388i;
import p000a.p025h.p037l.C0390k;
import p000a.p025h.p037l.C0405t;
import p000a.p042j.p043a.C0429a;
import p062b.p078b.p079a.p080a.C1011a;

public class CoordinatorLayout extends ViewGroup implements C0385f, C0386g {

    /* renamed from: v */
    public static final String f2722v;

    /* renamed from: w */
    public static final Class<?>[] f2723w = {Context.class, AttributeSet.class};

    /* renamed from: x */
    public static final ThreadLocal<Map<String, Constructor<C0733c>>> f2724x = new ThreadLocal<>();

    /* renamed from: y */
    public static final Comparator<View> f2725y = new C0740i();

    /* renamed from: z */
    public static final C0375c<Rect> f2726z = new C0376d(12);

    /* renamed from: b */
    public final List<View> f2727b = new ArrayList();

    /* renamed from: c */
    public final C0298a<View> f2728c = new C0298a<>();

    /* renamed from: d */
    public final List<View> f2729d = new ArrayList();

    /* renamed from: e */
    public final List<View> f2730e = new ArrayList();

    /* renamed from: f */
    public Paint f2731f;

    /* renamed from: g */
    public final int[] f2732g = new int[2];

    /* renamed from: h */
    public final int[] f2733h = new int[2];

    /* renamed from: i */
    public boolean f2734i;

    /* renamed from: j */
    public boolean f2735j;

    /* renamed from: k */
    public int[] f2736k;

    /* renamed from: l */
    public View f2737l;

    /* renamed from: m */
    public View f2738m;

    /* renamed from: n */
    public C0737g f2739n;

    /* renamed from: o */
    public boolean f2740o;

    /* renamed from: p */
    public C0405t f2741p;

    /* renamed from: q */
    public boolean f2742q;

    /* renamed from: r */
    public Drawable f2743r;

    /* renamed from: s */
    public ViewGroup.OnHierarchyChangeListener f2744s;

    /* renamed from: t */
    public C0388i f2745t;

    /* renamed from: u */
    public final C0387h f2746u = new C0387h();

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$a */
    public class C0731a implements C0388i {
        public C0731a() {
        }

        /* renamed from: a */
        public C0405t mo137a(View view, C0405t tVar) {
            C0733c cVar;
            CoordinatorLayout coordinatorLayout = CoordinatorLayout.this;
            if (!Objects.equals(coordinatorLayout.f2741p, tVar)) {
                coordinatorLayout.f2741p = tVar;
                boolean z = true;
                boolean z2 = tVar.mo1594d() > 0;
                coordinatorLayout.f2742q = z2;
                if (z2 || coordinatorLayout.getBackground() != null) {
                    z = false;
                }
                coordinatorLayout.setWillNotDraw(z);
                if (!((WindowInsets) tVar.f1483a).isConsumed()) {
                    int childCount = coordinatorLayout.getChildCount();
                    for (int i = 0; i < childCount; i++) {
                        View childAt = coordinatorLayout.getChildAt(i);
                        if (C0390k.m1240m(childAt) && (cVar = ((C0736f) childAt.getLayoutParams()).f2749a) != null) {
                            tVar = cVar.mo2862e(tVar);
                            if (((WindowInsets) tVar.f1483a).isConsumed()) {
                                break;
                            }
                        }
                    }
                }
                coordinatorLayout.requestLayout();
            }
            return tVar;
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$b */
    public interface C0732b {
        C0733c getBehavior();
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$c */
    public static abstract class C0733c<V extends View> {
        public C0733c() {
        }

        public C0733c(Context context, AttributeSet attributeSet) {
        }

        /* renamed from: A */
        public boolean mo2857A(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }

        /* renamed from: a */
        public boolean mo2858a(CoordinatorLayout coordinatorLayout, V v, Rect rect) {
            return false;
        }

        /* renamed from: b */
        public int mo2859b() {
            return -16777216;
        }

        /* renamed from: c */
        public float mo2860c() {
            return 0.0f;
        }

        /* renamed from: d */
        public boolean mo2861d(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        /* renamed from: e */
        public C0405t mo2862e(C0405t tVar) {
            return tVar;
        }

        /* renamed from: f */
        public void mo2863f(C0736f fVar) {
        }

        /* renamed from: g */
        public boolean mo2864g(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        /* renamed from: h */
        public void mo2865h(CoordinatorLayout coordinatorLayout, V v, View view) {
        }

        /* renamed from: i */
        public void mo2866i() {
        }

        /* renamed from: j */
        public boolean mo2867j(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }

        /* renamed from: k */
        public boolean mo2868k(CoordinatorLayout coordinatorLayout, V v, int i) {
            return false;
        }

        /* renamed from: l */
        public boolean mo2869l(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3, int i4) {
            return false;
        }

        /* renamed from: m */
        public boolean mo2870m() {
            return false;
        }

        /* renamed from: n */
        public boolean mo2871n(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
            return false;
        }

        @Deprecated
        /* renamed from: o */
        public void mo2872o() {
        }

        /* renamed from: p */
        public void mo2873p(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr, int i3) {
            if (i3 == 0) {
                mo2872o();
            }
        }

        @Deprecated
        /* renamed from: q */
        public void mo2874q() {
        }

        /* renamed from: r */
        public void mo2875r(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
            iArr[0] = iArr[0] + i3;
            iArr[1] = iArr[1] + i4;
            if (i5 == 0) {
                mo2874q();
            }
        }

        @Deprecated
        /* renamed from: s */
        public void mo2876s() {
        }

        /* renamed from: t */
        public boolean mo2877t(CoordinatorLayout coordinatorLayout, V v, Rect rect, boolean z) {
            return false;
        }

        /* renamed from: u */
        public void mo2878u(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        }

        /* renamed from: v */
        public Parcelable mo2879v(CoordinatorLayout coordinatorLayout, V v) {
            return View.BaseSavedState.EMPTY_STATE;
        }

        @Deprecated
        /* renamed from: w */
        public boolean mo2880w() {
            return false;
        }

        /* renamed from: x */
        public boolean mo2881x(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i, int i2) {
            if (i2 == 0) {
                return mo2880w();
            }
            return false;
        }

        @Deprecated
        /* renamed from: y */
        public void mo2882y() {
        }

        /* renamed from: z */
        public void mo2883z(CoordinatorLayout coordinatorLayout, V v, View view, int i) {
            if (i == 0) {
                mo2882y();
            }
        }
    }

    @Deprecated
    @Retention(RetentionPolicy.RUNTIME)
    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$d */
    public @interface C0734d {
        Class<? extends C0733c> value();
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$e */
    public class C0735e implements ViewGroup.OnHierarchyChangeListener {
        public C0735e() {
        }

        public void onChildViewAdded(View view, View view2) {
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f2744s;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        public void onChildViewRemoved(View view, View view2) {
            CoordinatorLayout.this.mo2838p(2);
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f2744s;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$f */
    public static class C0736f extends ViewGroup.MarginLayoutParams {

        /* renamed from: a */
        public C0733c f2749a;

        /* renamed from: b */
        public boolean f2750b = false;

        /* renamed from: c */
        public int f2751c = 0;

        /* renamed from: d */
        public int f2752d = 0;

        /* renamed from: e */
        public int f2753e = -1;

        /* renamed from: f */
        public int f2754f = -1;

        /* renamed from: g */
        public int f2755g = 0;

        /* renamed from: h */
        public int f2756h = 0;

        /* renamed from: i */
        public int f2757i;

        /* renamed from: j */
        public int f2758j;

        /* renamed from: k */
        public View f2759k;

        /* renamed from: l */
        public View f2760l;

        /* renamed from: m */
        public boolean f2761m;

        /* renamed from: n */
        public boolean f2762n;

        /* renamed from: o */
        public boolean f2763o;

        /* renamed from: p */
        public boolean f2764p;

        /* renamed from: q */
        public final Rect f2765q = new Rect();

        public C0736f(int i, int i2) {
            super(i, i2);
        }

        public C0736f(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0297c.CoordinatorLayout_Layout);
            this.f2751c = obtainStyledAttributes.getInteger(C0297c.CoordinatorLayout_Layout_android_layout_gravity, 0);
            this.f2754f = obtainStyledAttributes.getResourceId(C0297c.CoordinatorLayout_Layout_layout_anchor, -1);
            this.f2752d = obtainStyledAttributes.getInteger(C0297c.CoordinatorLayout_Layout_layout_anchorGravity, 0);
            this.f2753e = obtainStyledAttributes.getInteger(C0297c.CoordinatorLayout_Layout_layout_keyline, -1);
            this.f2755g = obtainStyledAttributes.getInt(C0297c.CoordinatorLayout_Layout_layout_insetEdge, 0);
            this.f2756h = obtainStyledAttributes.getInt(C0297c.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
            boolean hasValue = obtainStyledAttributes.hasValue(C0297c.CoordinatorLayout_Layout_layout_behavior);
            this.f2750b = hasValue;
            if (hasValue) {
                this.f2749a = CoordinatorLayout.m2115s(context, attributeSet, obtainStyledAttributes.getString(C0297c.CoordinatorLayout_Layout_layout_behavior));
            }
            obtainStyledAttributes.recycle();
            C0733c cVar = this.f2749a;
            if (cVar != null) {
                cVar.mo2863f(this);
            }
        }

        public C0736f(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0736f(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0736f(C0736f fVar) {
            super(fVar);
        }

        /* renamed from: a */
        public boolean mo2887a(int i) {
            if (i == 0) {
                return this.f2762n;
            }
            if (i != 1) {
                return false;
            }
            return this.f2763o;
        }

        /* renamed from: b */
        public void mo2888b(int i, boolean z) {
            if (i == 0) {
                this.f2762n = z;
            } else if (i == 1) {
                this.f2763o = z;
            }
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$g */
    public class C0737g implements ViewTreeObserver.OnPreDrawListener {
        public C0737g() {
        }

        public boolean onPreDraw() {
            CoordinatorLayout.this.mo2838p(0);
            return true;
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$h */
    public static class C0738h extends C0429a {
        public static final Parcelable.Creator<C0738h> CREATOR = new C0739a();

        /* renamed from: d */
        public SparseArray<Parcelable> f2767d;

        /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$h$a */
        public static class C0739a implements Parcelable.ClassLoaderCreator<C0738h> {
            public Object createFromParcel(Parcel parcel) {
                return new C0738h(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0738h[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0738h(parcel, classLoader);
            }
        }

        public C0738h(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            int readInt = parcel.readInt();
            int[] iArr = new int[readInt];
            parcel.readIntArray(iArr);
            Parcelable[] readParcelableArray = parcel.readParcelableArray(classLoader);
            this.f2767d = new SparseArray<>(readInt);
            for (int i = 0; i < readInt; i++) {
                this.f2767d.append(iArr[i], readParcelableArray[i]);
            }
        }

        public C0738h(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f1559b, i);
            SparseArray<Parcelable> sparseArray = this.f2767d;
            int size = sparseArray != null ? sparseArray.size() : 0;
            parcel.writeInt(size);
            int[] iArr = new int[size];
            Parcelable[] parcelableArr = new Parcelable[size];
            for (int i2 = 0; i2 < size; i2++) {
                iArr[i2] = this.f2767d.keyAt(i2);
                parcelableArr[i2] = this.f2767d.valueAt(i2);
            }
            parcel.writeIntArray(iArr);
            parcel.writeParcelableArray(parcelableArr, i);
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$i */
    public static class C0740i implements Comparator<View> {
        public int compare(Object obj, Object obj2) {
            float w = C0390k.m1250w((View) obj);
            float z = ((View) obj2).getZ();
            if (w > z) {
                return -1;
            }
            return w < z ? 1 : 0;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v5, resolved type: java.lang.Class<?>[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            java.lang.Class<androidx.coordinatorlayout.widget.CoordinatorLayout> r0 = androidx.coordinatorlayout.widget.CoordinatorLayout.class
            java.lang.Package r0 = r0.getPackage()
            if (r0 == 0) goto L_0x000d
            java.lang.String r0 = r0.getName()
            goto L_0x000e
        L_0x000d:
            r0 = 0
        L_0x000e:
            f2722v = r0
            androidx.coordinatorlayout.widget.CoordinatorLayout$i r0 = new androidx.coordinatorlayout.widget.CoordinatorLayout$i
            r0.<init>()
            f2725y = r0
            r0 = 2
            java.lang.Class[] r0 = new java.lang.Class[r0]
            r1 = 0
            java.lang.Class<android.content.Context> r2 = android.content.Context.class
            r0[r1] = r2
            r1 = 1
            java.lang.Class<android.util.AttributeSet> r2 = android.util.AttributeSet.class
            r0[r1] = r2
            f2723w = r0
            java.lang.ThreadLocal r0 = new java.lang.ThreadLocal
            r0.<init>()
            f2724x = r0
            a.h.k.d r0 = new a.h.k.d
            r1 = 12
            r0.<init>(r1)
            f2726z = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.<clinit>():void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public CoordinatorLayout(android.content.Context r10, android.util.AttributeSet r11) {
        /*
            r9 = this;
            int r5 = p000a.p023g.C0295a.coordinatorLayoutStyle
            r9.<init>(r10, r11, r5)
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r9.f2727b = r0
            a.g.d.a r0 = new a.g.d.a
            r0.<init>()
            r9.f2728c = r0
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r9.f2729d = r0
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r9.f2730e = r0
            r0 = 2
            int[] r1 = new int[r0]
            r9.f2732g = r1
            int[] r0 = new int[r0]
            r9.f2733h = r0
            a.h.l.h r0 = new a.h.l.h
            r0.<init>()
            r9.f2746u = r0
            r7 = 0
            int[] r0 = p000a.p023g.C0297c.CoordinatorLayout
            if (r5 != 0) goto L_0x003d
            int r1 = p000a.p023g.C0296b.Widget_Support_CoordinatorLayout
            android.content.res.TypedArray r0 = r10.obtainStyledAttributes(r11, r0, r7, r1)
            goto L_0x0041
        L_0x003d:
            android.content.res.TypedArray r0 = r10.obtainStyledAttributes(r11, r0, r5, r7)
        L_0x0041:
            r8 = r0
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 29
            if (r0 < r1) goto L_0x005f
            int[] r2 = p000a.p023g.C0297c.CoordinatorLayout
            if (r5 != 0) goto L_0x0057
            r5 = 0
            int r6 = p000a.p023g.C0296b.Widget_Support_CoordinatorLayout
            r0 = r9
            r1 = r10
            r3 = r11
            r4 = r8
            r0.saveAttributeDataForStyleable(r1, r2, r3, r4, r5, r6)
            goto L_0x005f
        L_0x0057:
            r6 = 0
            r0 = r9
            r1 = r10
            r3 = r11
            r4 = r8
            r0.saveAttributeDataForStyleable(r1, r2, r3, r4, r5, r6)
        L_0x005f:
            int r0 = p000a.p023g.C0297c.CoordinatorLayout_keylines
            int r0 = r8.getResourceId(r0, r7)
            if (r0 == 0) goto L_0x0089
            android.content.res.Resources r1 = r10.getResources()
            int[] r0 = r1.getIntArray(r0)
            r9.f2736k = r0
            android.util.DisplayMetrics r0 = r1.getDisplayMetrics()
            float r0 = r0.density
            int[] r1 = r9.f2736k
            int r1 = r1.length
        L_0x007a:
            if (r7 >= r1) goto L_0x0089
            int[] r2 = r9.f2736k
            r3 = r2[r7]
            float r3 = (float) r3
            float r3 = r3 * r0
            int r3 = (int) r3
            r2[r7] = r3
            int r7 = r7 + 1
            goto L_0x007a
        L_0x0089:
            int r0 = p000a.p023g.C0297c.CoordinatorLayout_statusBarBackground
            android.graphics.drawable.Drawable r0 = r8.getDrawable(r0)
            r9.f2743r = r0
            r8.recycle()
            r9.mo2855y()
            androidx.coordinatorlayout.widget.CoordinatorLayout$e r0 = new androidx.coordinatorlayout.widget.CoordinatorLayout$e
            r0.<init>()
            super.setOnHierarchyChangeListener(r0)
            int r0 = r9.getImportantForAccessibility()
            if (r0 != 0) goto L_0x00a9
            r0 = 1
            r9.setImportantForAccessibility(r0)
        L_0x00a9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    /* renamed from: a */
    public static Rect m2114a() {
        Rect a = f2726z.mo1530a();
        return a == null ? new Rect() : a;
    }

    /* renamed from: s */
    public static C0733c m2115s(Context context, AttributeSet attributeSet, String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        if (str.startsWith(".")) {
            str = context.getPackageName() + str;
        } else if (str.indexOf(46) < 0 && !TextUtils.isEmpty(f2722v)) {
            str = f2722v + '.' + str;
        }
        try {
            Map map = f2724x.get();
            if (map == null) {
                map = new HashMap();
                f2724x.set(map);
            }
            Constructor<?> constructor = (Constructor) map.get(str);
            if (constructor == null) {
                constructor = Class.forName(str, false, context.getClassLoader()).getConstructor(f2723w);
                constructor.setAccessible(true);
                map.put(str, constructor);
            }
            return (C0733c) constructor.newInstance(new Object[]{context, attributeSet});
        } catch (Exception e) {
            throw new RuntimeException(C1011a.m3161i("Could not inflate Behavior subclass ", str), e);
        }
    }

    /* renamed from: b */
    public final void mo2802b(C0736f fVar, Rect rect, int i, int i2) {
        int width = getWidth();
        int height = getHeight();
        int max = Math.max(getPaddingLeft() + fVar.leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i) - fVar.rightMargin));
        int max2 = Math.max(getPaddingTop() + fVar.topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i2) - fVar.bottomMargin));
        rect.set(max, max2, i + max, i2 + max2);
    }

    /* renamed from: c */
    public void mo2803c(View view, boolean z, Rect rect) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z) {
            C0299b.m1046a(this, view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof C0736f) && super.checkLayoutParams(layoutParams);
    }

    /* renamed from: d */
    public List<View> mo2805d(View view) {
        C0298a<View> aVar = this.f2728c;
        int i = aVar.f1279b.f940d;
        ArrayList arrayList = null;
        for (int i2 = 0; i2 < i; i2++) {
            ArrayList k = aVar.f1279b.mo1240k(i2);
            if (k != null && k.contains(view)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(aVar.f1279b.mo1235h(i2));
            }
        }
        this.f2730e.clear();
        if (arrayList != null) {
            this.f2730e.addAll(arrayList);
        }
        return this.f2730e;
    }

    public boolean drawChild(Canvas canvas, View view, long j) {
        C0736f fVar = (C0736f) view.getLayoutParams();
        C0733c cVar = fVar.f2749a;
        if (cVar != null) {
            float c = cVar.mo2860c();
            if (c > 0.0f) {
                if (this.f2731f == null) {
                    this.f2731f = new Paint();
                }
                this.f2731f.setColor(fVar.f2749a.mo2859b());
                Paint paint = this.f2731f;
                int round = Math.round(c * 255.0f);
                if (round < 0) {
                    round = 0;
                } else if (round > 255) {
                    round = 255;
                }
                paint.setAlpha(round);
                int save = canvas.save();
                if (view.isOpaque()) {
                    canvas.clipRect((float) view.getLeft(), (float) view.getTop(), (float) view.getRight(), (float) view.getBottom(), Region.Op.DIFFERENCE);
                }
                canvas.drawRect((float) getPaddingLeft(), (float) getPaddingTop(), (float) (getWidth() - getPaddingRight()), (float) (getHeight() - getPaddingBottom()), this.f2731f);
                canvas.restoreToCount(save);
            }
        }
        return super.drawChild(canvas, view, j);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f2743r;
        boolean z = false;
        if (drawable != null && drawable.isStateful()) {
            z = false | drawable.setState(drawableState);
        }
        if (z) {
            invalidate();
        }
    }

    /* renamed from: e */
    public List<View> mo2808e(View view) {
        List orDefault = this.f2728c.f1279b.getOrDefault(view, null);
        this.f2730e.clear();
        if (orDefault != null) {
            this.f2730e.addAll(orDefault);
        }
        return this.f2730e;
    }

    /* renamed from: f */
    public final void mo2809f(int i, Rect rect, Rect rect2, C0736f fVar, int i2, int i3) {
        int i4 = fVar.f2751c;
        if (i4 == 0) {
            i4 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i4, i);
        int i5 = fVar.f2752d;
        if ((i5 & 7) == 0) {
            i5 |= 8388611;
        }
        if ((i5 & 112) == 0) {
            i5 |= 48;
        }
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i5, i);
        int i6 = absoluteGravity & 7;
        int i7 = absoluteGravity & 112;
        int i8 = absoluteGravity2 & 7;
        int i9 = absoluteGravity2 & 112;
        int width = i8 != 1 ? i8 != 5 ? rect.left : rect.right : rect.left + (rect.width() / 2);
        int height = i9 != 16 ? i9 != 80 ? rect.top : rect.bottom : rect.top + (rect.height() / 2);
        if (i6 == 1) {
            width -= i2 / 2;
        } else if (i6 != 5) {
            width -= i2;
        }
        if (i7 == 16) {
            height -= i3 / 2;
        } else if (i7 != 80) {
            height -= i3;
        }
        rect2.set(width, height, i2 + width, i3 + height);
    }

    /* renamed from: g */
    public final int mo2810g(int i) {
        StringBuilder sb;
        int[] iArr = this.f2736k;
        if (iArr == null) {
            sb = new StringBuilder();
            sb.append("No keylines defined for ");
            sb.append(this);
            sb.append(" - attempted index lookup ");
            sb.append(i);
        } else if (i >= 0 && i < iArr.length) {
            return iArr[i];
        } else {
            sb = new StringBuilder();
            sb.append("Keyline index ");
            sb.append(i);
            sb.append(" out of range for ");
            sb.append(this);
        }
        Log.e("CoordinatorLayout", sb.toString());
        return 0;
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0736f(-2, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0736f(getContext(), attributeSet);
    }

    public final List<View> getDependencySortedChildren() {
        mo2850u();
        return Collections.unmodifiableList(this.f2727b);
    }

    public final C0405t getLastWindowInsets() {
        return this.f2741p;
    }

    public int getNestedScrollAxes() {
        return this.f2746u.mo1566a();
    }

    public Drawable getStatusBarBackground() {
        return this.f2743r;
    }

    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    /* renamed from: h */
    public C0736f mo2820h(View view) {
        C0736f fVar = (C0736f) view.getLayoutParams();
        if (!fVar.f2750b) {
            if (view instanceof C0732b) {
                C0733c behavior = ((C0732b) view).getBehavior();
                if (behavior == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                C0733c cVar = fVar.f2749a;
                if (cVar != behavior) {
                    if (cVar != null) {
                        cVar.mo2866i();
                    }
                    fVar.f2749a = behavior;
                    fVar.f2750b = true;
                    if (behavior != null) {
                        behavior.mo2863f(fVar);
                    }
                }
            } else {
                C0734d dVar = null;
                for (Class cls = view.getClass(); cls != null; cls = cls.getSuperclass()) {
                    dVar = (C0734d) cls.getAnnotation(C0734d.class);
                    if (dVar != null) {
                        break;
                    }
                }
                if (dVar != null) {
                    try {
                        C0733c cVar2 = (C0733c) dVar.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                        C0733c cVar3 = fVar.f2749a;
                        if (cVar3 != cVar2) {
                            if (cVar3 != null) {
                                cVar3.mo2866i();
                            }
                            fVar.f2749a = cVar2;
                            fVar.f2750b = true;
                            if (cVar2 != null) {
                                cVar2.mo2863f(fVar);
                            }
                        }
                    } catch (Exception e) {
                        StringBuilder l = C1011a.m3164l("Default behavior class ");
                        l.append(dVar.value().getName());
                        l.append(" could not be instantiated. Did you forget a default constructor?");
                        Log.e("CoordinatorLayout", l.toString(), e);
                    }
                }
            }
            fVar.f2750b = true;
        }
        return fVar;
    }

    /* renamed from: i */
    public void mo1560i(View view, View view2, int i, int i2) {
        C0733c cVar;
        C0387h hVar = this.f2746u;
        if (i2 == 1) {
            hVar.f1458b = i;
        } else {
            hVar.f1457a = i;
        }
        this.f2738m = view2;
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            C0736f fVar = (C0736f) getChildAt(i3).getLayoutParams();
            if (fVar.mo2887a(i2) && (cVar = fVar.f2749a) != null && i2 == 0) {
                cVar.mo2876s();
            }
        }
    }

    /* renamed from: j */
    public boolean mo2821j(View view, int i, int i2) {
        Rect a = m2114a();
        C0299b.m1046a(this, view, a);
        try {
            return a.contains(i, i2);
        } finally {
            a.setEmpty();
            f2726z.mo1531b(a);
        }
    }

    /* renamed from: k */
    public void mo1565k(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        C0733c cVar;
        int childCount = getChildCount();
        boolean z = false;
        int i6 = 0;
        int i7 = 0;
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                C0736f fVar = (C0736f) childAt.getLayoutParams();
                if (fVar.mo2887a(i5) && (cVar = fVar.f2749a) != null) {
                    int[] iArr2 = this.f2732g;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    cVar.mo2875r(this, childAt, view, i, i2, i3, i4, i5, iArr2);
                    int[] iArr3 = this.f2732g;
                    i6 = i3 > 0 ? Math.max(i6, iArr3[0]) : Math.min(i6, iArr3[0]);
                    i7 = i4 > 0 ? Math.max(i7, this.f2732g[1]) : Math.min(i7, this.f2732g[1]);
                    z = true;
                }
            }
        }
        iArr[0] = iArr[0] + i6;
        iArr[1] = iArr[1] + i7;
        if (z) {
            mo2838p(1);
        }
    }

    /* renamed from: l */
    public void mo1561l(View view, int i, int i2, int i3, int i4, int i5) {
        mo1565k(view, i, i2, i3, i4, 0, this.f2733h);
    }

    /* renamed from: m */
    public void mo1562m(View view, int i) {
        C0387h hVar = this.f2746u;
        if (i == 1) {
            hVar.f1458b = 0;
        } else {
            hVar.f1457a = 0;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            C0736f fVar = (C0736f) childAt.getLayoutParams();
            if (fVar.mo2887a(i)) {
                C0733c cVar = fVar.f2749a;
                if (cVar != null) {
                    cVar.mo2883z(this, childAt, view, i);
                }
                fVar.mo2888b(i, false);
                fVar.f2764p = false;
            }
        }
        this.f2738m = null;
    }

    /* renamed from: n */
    public void mo1563n(View view, int i, int i2, int[] iArr, int i3) {
        C0733c cVar;
        int childCount = getChildCount();
        boolean z = false;
        int i4 = 0;
        int i5 = 0;
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() == 8) {
                int i7 = i3;
            } else {
                C0736f fVar = (C0736f) childAt.getLayoutParams();
                if (fVar.mo2887a(i3) && (cVar = fVar.f2749a) != null) {
                    int[] iArr2 = this.f2732g;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    cVar.mo2873p(this, childAt, view, i, i2, iArr2, i3);
                    int[] iArr3 = this.f2732g;
                    i4 = i > 0 ? Math.max(i4, iArr3[0]) : Math.min(i4, iArr3[0]);
                    int[] iArr4 = this.f2732g;
                    i5 = i2 > 0 ? Math.max(i5, iArr4[1]) : Math.min(i5, iArr4[1]);
                    z = true;
                }
            }
        }
        iArr[0] = i4;
        iArr[1] = i5;
        if (z) {
            mo2838p(1);
        }
    }

    /* renamed from: o */
    public boolean mo1564o(View view, View view2, int i, int i2) {
        int i3 = i2;
        int childCount = getChildCount();
        int i4 = 0;
        boolean z = false;
        while (true) {
            if (i4 >= childCount) {
                return z;
            }
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                C0736f fVar = (C0736f) childAt.getLayoutParams();
                C0733c cVar = fVar.f2749a;
                if (cVar != null) {
                    boolean x = cVar.mo2881x(this, childAt, view, view2, i, i2);
                    z |= x;
                    fVar.mo2888b(i3, x);
                } else {
                    fVar.mo2888b(i3, false);
                }
            }
            i4++;
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        mo2851v(false);
        if (this.f2740o) {
            if (this.f2739n == null) {
                this.f2739n = new C0737g();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f2739n);
        }
        if (this.f2741p == null && C0390k.m1240m(this)) {
            requestApplyInsets();
        }
        this.f2735j = true;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mo2851v(false);
        if (this.f2740o && this.f2739n != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f2739n);
        }
        View view = this.f2738m;
        if (view != null) {
            onStopNestedScroll(view);
        }
        this.f2735j = false;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f2742q && this.f2743r != null) {
            C0405t tVar = this.f2741p;
            int d = tVar != null ? tVar.mo1594d() : 0;
            if (d > 0) {
                this.f2743r.setBounds(0, 0, getWidth(), d);
                this.f2743r.draw(canvas);
            }
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            mo2851v(true);
        }
        boolean t = mo2849t(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            mo2851v(true);
        }
        return t;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        C0733c cVar;
        int p = C0390k.m1243p(this);
        int size = this.f2727b.size();
        for (int i5 = 0; i5 < size; i5++) {
            View view = this.f2727b.get(i5);
            if (view.getVisibility() != 8 && ((cVar = ((C0736f) view.getLayoutParams()).f2749a) == null || !cVar.mo2868k(this, view, p))) {
                mo2839q(view, p);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:77:0x017e, code lost:
        if (r0.mo2869l(r30, r20, r8, r21, r23, 0) == false) goto L_0x018e;
     */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x012d  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x0157  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x015f  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x0181  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r31, int r32) {
        /*
            r30 = this;
            r7 = r30
            r30.mo2850u()
            int r0 = r30.getChildCount()
            r8 = 0
            r1 = 0
        L_0x000b:
            r2 = 1
            if (r1 >= r0) goto L_0x0038
            android.view.View r3 = r7.getChildAt(r1)
            a.g.d.a<android.view.View> r4 = r7.f2728c
            a.e.h<T, java.util.ArrayList<T>> r5 = r4.f1279b
            int r5 = r5.f940d
            r6 = 0
        L_0x0019:
            if (r6 >= r5) goto L_0x0030
            a.e.h<T, java.util.ArrayList<T>> r9 = r4.f1279b
            java.lang.Object r9 = r9.mo1240k(r6)
            java.util.ArrayList r9 = (java.util.ArrayList) r9
            if (r9 == 0) goto L_0x002d
            boolean r9 = r9.contains(r3)
            if (r9 == 0) goto L_0x002d
            r3 = 1
            goto L_0x0031
        L_0x002d:
            int r6 = r6 + 1
            goto L_0x0019
        L_0x0030:
            r3 = 0
        L_0x0031:
            if (r3 == 0) goto L_0x0035
            r0 = 1
            goto L_0x0039
        L_0x0035:
            int r1 = r1 + 1
            goto L_0x000b
        L_0x0038:
            r0 = 0
        L_0x0039:
            boolean r1 = r7.f2740o
            if (r0 == r1) goto L_0x006d
            if (r0 == 0) goto L_0x005a
            boolean r0 = r7.f2735j
            if (r0 == 0) goto L_0x0057
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r0 = r7.f2739n
            if (r0 != 0) goto L_0x004e
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r0 = new androidx.coordinatorlayout.widget.CoordinatorLayout$g
            r0.<init>()
            r7.f2739n = r0
        L_0x004e:
            android.view.ViewTreeObserver r0 = r30.getViewTreeObserver()
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r1 = r7.f2739n
            r0.addOnPreDrawListener(r1)
        L_0x0057:
            r7.f2740o = r2
            goto L_0x006d
        L_0x005a:
            boolean r0 = r7.f2735j
            if (r0 == 0) goto L_0x006b
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r0 = r7.f2739n
            if (r0 == 0) goto L_0x006b
            android.view.ViewTreeObserver r0 = r30.getViewTreeObserver()
            androidx.coordinatorlayout.widget.CoordinatorLayout$g r1 = r7.f2739n
            r0.removeOnPreDrawListener(r1)
        L_0x006b:
            r7.f2740o = r8
        L_0x006d:
            int r9 = r30.getPaddingLeft()
            int r0 = r30.getPaddingTop()
            int r10 = r30.getPaddingRight()
            int r1 = r30.getPaddingBottom()
            int r11 = p000a.p025h.p037l.C0390k.m1243p(r30)
            if (r11 != r2) goto L_0x0085
            r12 = 1
            goto L_0x0086
        L_0x0085:
            r12 = 0
        L_0x0086:
            int r13 = android.view.View.MeasureSpec.getMode(r31)
            int r14 = android.view.View.MeasureSpec.getSize(r31)
            int r15 = android.view.View.MeasureSpec.getMode(r32)
            int r16 = android.view.View.MeasureSpec.getSize(r32)
            int r17 = r9 + r10
            int r18 = r0 + r1
            int r0 = r30.getSuggestedMinimumWidth()
            int r1 = r30.getSuggestedMinimumHeight()
            a.h.l.t r3 = r7.f2741p
            if (r3 == 0) goto L_0x00af
            boolean r3 = r30.getFitsSystemWindows()
            if (r3 == 0) goto L_0x00af
            r19 = 1
            goto L_0x00b1
        L_0x00af:
            r19 = 0
        L_0x00b1:
            java.util.List<android.view.View> r2 = r7.f2727b
            int r6 = r2.size()
            r5 = r0
            r4 = r1
            r2 = 0
            r3 = 0
        L_0x00bb:
            if (r3 >= r6) goto L_0x01d4
            java.util.List<android.view.View> r0 = r7.f2727b
            java.lang.Object r0 = r0.get(r3)
            r20 = r0
            android.view.View r20 = (android.view.View) r20
            int r0 = r20.getVisibility()
            r1 = 8
            if (r0 != r1) goto L_0x00d7
            r22 = r3
            r29 = r6
            r28 = r9
            goto L_0x01cb
        L_0x00d7:
            android.view.ViewGroup$LayoutParams r0 = r20.getLayoutParams()
            r1 = r0
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r1 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0736f) r1
            int r0 = r1.f2753e
            if (r0 < 0) goto L_0x0121
            if (r13 == 0) goto L_0x0121
            int r0 = r7.mo2810g(r0)
            int r8 = r1.f2751c
            if (r8 != 0) goto L_0x00ef
            r8 = 8388661(0x800035, float:1.1755018E-38)
        L_0x00ef:
            int r8 = android.view.Gravity.getAbsoluteGravity(r8, r11)
            r8 = r8 & 7
            r22 = r2
            r2 = 3
            if (r8 != r2) goto L_0x00fc
            if (r12 == 0) goto L_0x0101
        L_0x00fc:
            r2 = 5
            if (r8 != r2) goto L_0x010d
            if (r12 == 0) goto L_0x010d
        L_0x0101:
            int r2 = r14 - r10
            int r2 = r2 - r0
            r0 = 0
            int r2 = java.lang.Math.max(r0, r2)
            r21 = r2
            r8 = 0
            goto L_0x0125
        L_0x010d:
            if (r8 != r2) goto L_0x0111
            if (r12 == 0) goto L_0x0116
        L_0x0111:
            r2 = 3
            if (r8 != r2) goto L_0x011f
            if (r12 == 0) goto L_0x011f
        L_0x0116:
            int r0 = r0 - r9
            r8 = 0
            int r0 = java.lang.Math.max(r8, r0)
            r21 = r0
            goto L_0x0125
        L_0x011f:
            r8 = 0
            goto L_0x0123
        L_0x0121:
            r22 = r2
        L_0x0123:
            r21 = 0
        L_0x0125:
            if (r19 == 0) goto L_0x0157
            boolean r0 = r20.getFitsSystemWindows()
            if (r0 != 0) goto L_0x0157
            a.h.l.t r0 = r7.f2741p
            int r0 = r0.mo1592b()
            a.h.l.t r2 = r7.f2741p
            int r2 = r2.mo1593c()
            int r2 = r2 + r0
            a.h.l.t r0 = r7.f2741p
            int r0 = r0.mo1594d()
            a.h.l.t r8 = r7.f2741p
            int r8 = r8.mo1591a()
            int r8 = r8 + r0
            int r0 = r14 - r2
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r13)
            int r2 = r16 - r8
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r15)
            r8 = r0
            r23 = r2
            goto L_0x015b
        L_0x0157:
            r8 = r31
            r23 = r32
        L_0x015b:
            androidx.coordinatorlayout.widget.CoordinatorLayout$c r0 = r1.f2749a
            if (r0 == 0) goto L_0x0181
            r24 = 0
            r2 = r1
            r1 = r30
            r26 = r2
            r25 = r22
            r2 = r20
            r22 = r3
            r3 = r8
            r27 = r4
            r4 = r21
            r28 = r9
            r9 = r5
            r5 = r23
            r29 = r6
            r6 = r24
            boolean r0 = r0.mo2869l(r1, r2, r3, r4, r5, r6)
            if (r0 != 0) goto L_0x019b
            goto L_0x018e
        L_0x0181:
            r26 = r1
            r27 = r4
            r29 = r6
            r28 = r9
            r25 = r22
            r22 = r3
            r9 = r5
        L_0x018e:
            r5 = 0
            r0 = r30
            r1 = r20
            r2 = r8
            r3 = r21
            r4 = r23
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
        L_0x019b:
            int r0 = r20.getMeasuredWidth()
            int r0 = r0 + r17
            r1 = r26
            int r2 = r1.leftMargin
            int r0 = r0 + r2
            int r2 = r1.rightMargin
            int r0 = r0 + r2
            int r0 = java.lang.Math.max(r9, r0)
            int r2 = r20.getMeasuredHeight()
            int r2 = r2 + r18
            int r3 = r1.topMargin
            int r2 = r2 + r3
            int r1 = r1.bottomMargin
            int r2 = r2 + r1
            r1 = r27
            int r1 = java.lang.Math.max(r1, r2)
            int r2 = r20.getMeasuredState()
            r8 = r25
            int r2 = android.view.View.combineMeasuredStates(r8, r2)
            r5 = r0
            r4 = r1
        L_0x01cb:
            int r3 = r22 + 1
            r9 = r28
            r6 = r29
            r8 = 0
            goto L_0x00bb
        L_0x01d4:
            r8 = r2
            r1 = r4
            r9 = r5
            r0 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r0 = r0 & r8
            r2 = r31
            int r0 = android.view.View.resolveSizeAndState(r9, r2, r0)
            int r2 = r8 << 16
            r3 = r32
            int r1 = android.view.View.resolveSizeAndState(r1, r3, r2)
            r7.setMeasuredDimension(r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onMeasure(int, int):void");
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        C0733c cVar;
        int childCount = getChildCount();
        boolean z2 = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                C0736f fVar = (C0736f) childAt.getLayoutParams();
                if (fVar.mo2887a(0) && (cVar = fVar.f2749a) != null) {
                    z2 |= cVar.mo2870m();
                }
            }
        }
        if (z2) {
            mo2838p(1);
        }
        return z2;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        C0733c cVar;
        int childCount = getChildCount();
        boolean z = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                C0736f fVar = (C0736f) childAt.getLayoutParams();
                if (fVar.mo2887a(0) && (cVar = fVar.f2749a) != null) {
                    z |= cVar.mo2871n(this, childAt, view, f, f2);
                }
            }
        }
        return z;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        mo1563n(view, i, i2, iArr, 0);
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        mo1565k(view, i, i2, i3, i4, 0, this.f2733h);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        mo1560i(view, view2, i, 0);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof C0738h)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0738h hVar = (C0738h) parcelable;
        super.onRestoreInstanceState(hVar.f1559b);
        SparseArray<Parcelable> sparseArray = hVar.f2767d;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            C0733c cVar = mo2820h(childAt).f2749a;
            if (!(id == -1 || cVar == null || (parcelable2 = sparseArray.get(id)) == null)) {
                cVar.mo2878u(this, childAt, parcelable2);
            }
        }
    }

    public Parcelable onSaveInstanceState() {
        Parcelable v;
        C0738h hVar = new C0738h(super.onSaveInstanceState());
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            C0733c cVar = ((C0736f) childAt.getLayoutParams()).f2749a;
            if (!(id == -1 || cVar == null || (v = cVar.mo2879v(this, childAt)) == null)) {
                sparseArray.append(id, v);
            }
        }
        hVar.f2767d = sparseArray;
        return hVar;
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return mo1564o(view, view2, i, 0);
    }

    public void onStopNestedScroll(View view) {
        mo1562m(view, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0012, code lost:
        if (r3 != false) goto L_0x0016;
     */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x004a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            int r2 = r18.getActionMasked()
            android.view.View r3 = r0.f2737l
            r4 = 1
            r5 = 0
            if (r3 != 0) goto L_0x0015
            boolean r3 = r0.mo2849t(r1, r4)
            if (r3 == 0) goto L_0x0029
            goto L_0x0016
        L_0x0015:
            r3 = 0
        L_0x0016:
            android.view.View r6 = r0.f2737l
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r6 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0736f) r6
            androidx.coordinatorlayout.widget.CoordinatorLayout$c r6 = r6.f2749a
            if (r6 == 0) goto L_0x0029
            android.view.View r7 = r0.f2737l
            boolean r6 = r6.mo2857A(r0, r7, r1)
            goto L_0x002a
        L_0x0029:
            r6 = 0
        L_0x002a:
            android.view.View r7 = r0.f2737l
            r8 = 0
            if (r7 != 0) goto L_0x0035
            boolean r1 = super.onTouchEvent(r18)
            r6 = r6 | r1
            goto L_0x0048
        L_0x0035:
            if (r3 == 0) goto L_0x0048
            long r11 = android.os.SystemClock.uptimeMillis()
            r13 = 3
            r14 = 0
            r15 = 0
            r16 = 0
            r9 = r11
            android.view.MotionEvent r8 = android.view.MotionEvent.obtain(r9, r11, r13, r14, r15, r16)
            super.onTouchEvent(r8)
        L_0x0048:
            if (r8 == 0) goto L_0x004d
            r8.recycle()
        L_0x004d:
            if (r2 == r4) goto L_0x0052
            r1 = 3
            if (r2 != r1) goto L_0x0055
        L_0x0052:
            r0.mo2851v(r5)
        L_0x0055:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* renamed from: p */
    public final void mo2838p(int i) {
        int i2;
        Rect rect;
        int i3;
        boolean z;
        boolean z2;
        boolean z3;
        int width;
        int i4;
        int i5;
        int i6;
        int height;
        int i7;
        int i8;
        int i9;
        Rect rect2;
        int i10;
        int i11;
        int i12;
        C0736f fVar;
        C0733c cVar;
        int i13 = i;
        int p = C0390k.m1243p(this);
        int size = this.f2727b.size();
        Rect a = m2114a();
        Rect a2 = m2114a();
        Rect a3 = m2114a();
        int i14 = 0;
        while (i14 < size) {
            View view = this.f2727b.get(i14);
            C0736f fVar2 = (C0736f) view.getLayoutParams();
            if (i13 == 0 && view.getVisibility() == 8) {
                i3 = size;
                rect = a3;
                i2 = i14;
            } else {
                int i15 = 0;
                while (i15 < i14) {
                    if (fVar2.f2760l == this.f2727b.get(i15)) {
                        C0736f fVar3 = (C0736f) view.getLayoutParams();
                        if (fVar3.f2759k != null) {
                            Rect a4 = m2114a();
                            Rect a5 = m2114a();
                            Rect a6 = m2114a();
                            C0299b.m1046a(this, fVar3.f2759k, a4);
                            mo2803c(view, false, a5);
                            int measuredWidth = view.getMeasuredWidth();
                            i12 = size;
                            int measuredHeight = view.getMeasuredHeight();
                            int i16 = measuredWidth;
                            Rect rect3 = a6;
                            i11 = i14;
                            Rect rect4 = a5;
                            Rect rect5 = a4;
                            C0736f fVar4 = fVar3;
                            i10 = i15;
                            rect2 = a3;
                            fVar = fVar2;
                            mo2809f(p, a4, rect3, fVar3, i16, measuredHeight);
                            Rect rect6 = rect3;
                            boolean z4 = (rect6.left == rect4.left && rect6.top == rect4.top) ? false : true;
                            C0736f fVar5 = fVar4;
                            mo2802b(fVar5, rect6, i16, measuredHeight);
                            int i17 = rect6.left - rect4.left;
                            int i18 = rect6.top - rect4.top;
                            if (i17 != 0) {
                                C0390k.m1200G(view, i17);
                            }
                            if (i18 != 0) {
                                C0390k.m1201H(view, i18);
                            }
                            if (z4 && (cVar = fVar5.f2749a) != null) {
                                cVar.mo2864g(this, view, fVar5.f2759k);
                            }
                            rect5.setEmpty();
                            f2726z.mo1531b(rect5);
                            rect4.setEmpty();
                            f2726z.mo1531b(rect4);
                            rect6.setEmpty();
                            f2726z.mo1531b(rect6);
                            i15 = i10 + 1;
                            fVar2 = fVar;
                            size = i12;
                            i14 = i11;
                            a3 = rect2;
                        }
                    }
                    i10 = i15;
                    i12 = size;
                    rect2 = a3;
                    i11 = i14;
                    fVar = fVar2;
                    i15 = i10 + 1;
                    fVar2 = fVar;
                    size = i12;
                    i14 = i11;
                    a3 = rect2;
                }
                int i19 = size;
                Rect rect7 = a3;
                i2 = i14;
                C0736f fVar6 = fVar2;
                mo2803c(view, true, a2);
                if (fVar6.f2755g != 0 && !a2.isEmpty()) {
                    int absoluteGravity = Gravity.getAbsoluteGravity(fVar6.f2755g, p);
                    int i20 = absoluteGravity & 112;
                    if (i20 == 48) {
                        a.top = Math.max(a.top, a2.bottom);
                    } else if (i20 == 80) {
                        a.bottom = Math.max(a.bottom, getHeight() - a2.top);
                    }
                    int i21 = absoluteGravity & 7;
                    if (i21 == 3) {
                        a.left = Math.max(a.left, a2.right);
                    } else if (i21 == 5) {
                        a.right = Math.max(a.right, getWidth() - a2.left);
                    }
                }
                if (fVar6.f2756h != 0 && view.getVisibility() == 0 && view.isLaidOut() && view.getWidth() > 0 && view.getHeight() > 0) {
                    C0736f fVar7 = (C0736f) view.getLayoutParams();
                    C0733c cVar2 = fVar7.f2749a;
                    Rect a7 = m2114a();
                    Rect a8 = m2114a();
                    a8.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
                    if (cVar2 == null || !cVar2.mo2858a(this, view, a7)) {
                        a7.set(a8);
                    } else if (!a8.contains(a7)) {
                        StringBuilder l = C1011a.m3164l("Rect should be within the child's bounds. Rect:");
                        l.append(a7.toShortString());
                        l.append(" | Bounds:");
                        l.append(a8.toShortString());
                        throw new IllegalArgumentException(l.toString());
                    }
                    a8.setEmpty();
                    f2726z.mo1531b(a8);
                    if (!a7.isEmpty()) {
                        int absoluteGravity2 = Gravity.getAbsoluteGravity(fVar7.f2756h, p);
                        if ((absoluteGravity2 & 48) != 48 || (i8 = (a7.top - fVar7.topMargin) - fVar7.f2758j) >= (i9 = a.top)) {
                            z2 = false;
                        } else {
                            mo2854x(view, i9 - i8);
                            z2 = true;
                        }
                        if ((absoluteGravity2 & 80) == 80 && (height = ((getHeight() - a7.bottom) - fVar7.bottomMargin) + fVar7.f2758j) < (i7 = a.bottom)) {
                            mo2854x(view, height - i7);
                            z2 = true;
                        }
                        if (!z2) {
                            mo2854x(view, 0);
                        }
                        if ((absoluteGravity2 & 3) != 3 || (i5 = (a7.left - fVar7.leftMargin) - fVar7.f2757i) >= (i6 = a.left)) {
                            z3 = false;
                        } else {
                            mo2853w(view, i6 - i5);
                            z3 = true;
                        }
                        if ((absoluteGravity2 & 5) == 5 && (width = ((getWidth() - a7.right) - fVar7.rightMargin) + fVar7.f2757i) < (i4 = a.right)) {
                            mo2853w(view, width - i4);
                            z3 = true;
                        }
                        if (!z3) {
                            mo2853w(view, 0);
                        }
                    }
                    a7.setEmpty();
                    f2726z.mo1531b(a7);
                }
                if (i13 != 2) {
                    rect = rect7;
                    rect.set(((C0736f) view.getLayoutParams()).f2765q);
                    if (rect.equals(a2)) {
                        i3 = i19;
                    } else {
                        ((C0736f) view.getLayoutParams()).f2765q.set(a2);
                    }
                } else {
                    rect = rect7;
                }
                i3 = i19;
                for (int i22 = i2 + 1; i22 < i3; i22++) {
                    View view2 = this.f2727b.get(i22);
                    C0736f fVar8 = (C0736f) view2.getLayoutParams();
                    C0733c cVar3 = fVar8.f2749a;
                    if (cVar3 != null && cVar3.mo2861d(this, view2, view)) {
                        if (i13 != 0 || !fVar8.f2764p) {
                            if (i13 != 2) {
                                z = cVar3.mo2864g(this, view2, view);
                            } else {
                                cVar3.mo2865h(this, view2, view);
                                z = true;
                            }
                            if (i13 == 1) {
                                fVar8.f2764p = z;
                            }
                        } else {
                            fVar8.f2764p = false;
                        }
                    }
                }
            }
            i14 = i2 + 1;
            size = i3;
            a3 = rect;
        }
        Rect rect8 = a3;
        a.setEmpty();
        f2726z.mo1531b(a);
        a2.setEmpty();
        f2726z.mo1531b(a2);
        rect8.setEmpty();
        f2726z.mo1531b(rect8);
    }

    /* renamed from: q */
    public void mo2839q(View view, int i) {
        C0736f fVar = (C0736f) view.getLayoutParams();
        int i2 = 0;
        if (!(fVar.f2759k == null && fVar.f2754f != -1)) {
            View view2 = fVar.f2759k;
            if (view2 != null) {
                Rect a = m2114a();
                Rect a2 = m2114a();
                try {
                    C0299b.m1046a(this, view2, a);
                    C0736f fVar2 = (C0736f) view.getLayoutParams();
                    int measuredWidth = view.getMeasuredWidth();
                    int measuredHeight = view.getMeasuredHeight();
                    mo2809f(i, a, a2, fVar2, measuredWidth, measuredHeight);
                    mo2802b(fVar2, a2, measuredWidth, measuredHeight);
                    view.layout(a2.left, a2.top, a2.right, a2.bottom);
                } finally {
                    a.setEmpty();
                    f2726z.mo1531b(a);
                    a2.setEmpty();
                    f2726z.mo1531b(a2);
                }
            } else {
                int i3 = fVar.f2753e;
                if (i3 >= 0) {
                    C0736f fVar3 = (C0736f) view.getLayoutParams();
                    int i4 = fVar3.f2751c;
                    if (i4 == 0) {
                        i4 = 8388661;
                    }
                    int absoluteGravity = Gravity.getAbsoluteGravity(i4, i);
                    int i5 = absoluteGravity & 7;
                    int i6 = absoluteGravity & 112;
                    int width = getWidth();
                    int height = getHeight();
                    int measuredWidth2 = view.getMeasuredWidth();
                    int measuredHeight2 = view.getMeasuredHeight();
                    if (i == 1) {
                        i3 = width - i3;
                    }
                    int g = mo2810g(i3) - measuredWidth2;
                    if (i5 == 1) {
                        g += measuredWidth2 / 2;
                    } else if (i5 == 5) {
                        g += measuredWidth2;
                    }
                    if (i6 == 16) {
                        i2 = 0 + (measuredHeight2 / 2);
                    } else if (i6 == 80) {
                        i2 = measuredHeight2 + 0;
                    }
                    int max = Math.max(getPaddingLeft() + fVar3.leftMargin, Math.min(g, ((width - getPaddingRight()) - measuredWidth2) - fVar3.rightMargin));
                    int max2 = Math.max(getPaddingTop() + fVar3.topMargin, Math.min(i2, ((height - getPaddingBottom()) - measuredHeight2) - fVar3.bottomMargin));
                    view.layout(max, max2, measuredWidth2 + max, measuredHeight2 + max2);
                    return;
                }
                C0736f fVar4 = (C0736f) view.getLayoutParams();
                Rect a3 = m2114a();
                a3.set(getPaddingLeft() + fVar4.leftMargin, getPaddingTop() + fVar4.topMargin, (getWidth() - getPaddingRight()) - fVar4.rightMargin, (getHeight() - getPaddingBottom()) - fVar4.bottomMargin);
                if (this.f2741p != null && C0390k.m1240m(this) && !view.getFitsSystemWindows()) {
                    a3.left = this.f2741p.mo1592b() + a3.left;
                    a3.top = this.f2741p.mo1594d() + a3.top;
                    a3.right -= this.f2741p.mo1593c();
                    a3.bottom -= this.f2741p.mo1591a();
                }
                Rect a4 = m2114a();
                int i7 = fVar4.f2751c;
                if ((i7 & 7) == 0) {
                    i7 |= 8388611;
                }
                if ((i7 & 112) == 0) {
                    i7 |= 48;
                }
                Gravity.apply(i7, view.getMeasuredWidth(), view.getMeasuredHeight(), a3, a4, i);
                view.layout(a4.left, a4.top, a4.right, a4.bottom);
                a3.setEmpty();
                f2726z.mo1531b(a3);
                a4.setEmpty();
                f2726z.mo1531b(a4);
            }
        } else {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
    }

    /* renamed from: r */
    public void mo2840r(View view, int i, int i2, int i3, int i4) {
        measureChildWithMargins(view, i, i2, i3, i4);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        C0733c cVar = ((C0736f) view.getLayoutParams()).f2749a;
        if (cVar == null || !cVar.mo2877t(this, view, rect, z)) {
            return super.requestChildRectangleOnScreen(view, rect, z);
        }
        return true;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        if (z && !this.f2734i) {
            mo2851v(false);
            this.f2734i = true;
        }
    }

    public void setFitsSystemWindows(boolean z) {
        super.setFitsSystemWindows(z);
        mo2855y();
    }

    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f2744s = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f2743r;
        if (drawable2 != drawable) {
            Drawable drawable3 = null;
            if (drawable2 != null) {
                drawable2.setCallback((Drawable.Callback) null);
            }
            if (drawable != null) {
                drawable3 = drawable.mutate();
            }
            this.f2743r = drawable3;
            if (drawable3 != null) {
                if (drawable3.isStateful()) {
                    this.f2743r.setState(getDrawableState());
                }
                C0049r.m198h1(this.f2743r, C0390k.m1243p(this));
                this.f2743r.setVisible(getVisibility() == 0, false);
                this.f2743r.setCallback(this);
            }
            C0390k.m1205L(this);
        }
    }

    public void setStatusBarBackgroundColor(int i) {
        setStatusBarBackground(new ColorDrawable(i));
    }

    public void setStatusBarBackgroundResource(int i) {
        setStatusBarBackground(i != 0 ? C0316a.m1061d(getContext(), i) : null);
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.f2743r;
        if (drawable != null && drawable.isVisible() != z) {
            this.f2743r.setVisible(z, false);
        }
    }

    /* renamed from: t */
    public final boolean mo2849t(MotionEvent motionEvent, int i) {
        boolean z;
        MotionEvent motionEvent2 = motionEvent;
        int i2 = i;
        int actionMasked = motionEvent.getActionMasked();
        List<View> list = this.f2729d;
        list.clear();
        boolean isChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i3 = childCount - 1; i3 >= 0; i3--) {
            list.add(getChildAt(isChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i3) : i3));
        }
        Comparator<View> comparator = f2725y;
        if (comparator != null) {
            Collections.sort(list, comparator);
        }
        int size = list.size();
        MotionEvent motionEvent3 = null;
        boolean z2 = false;
        boolean z3 = false;
        for (int i4 = 0; i4 < size; i4++) {
            View view = list.get(i4);
            C0736f fVar = (C0736f) view.getLayoutParams();
            C0733c cVar = fVar.f2749a;
            if ((!z2 && !z3) || actionMasked == 0) {
                if (!z2 && cVar != null) {
                    if (i2 == 0) {
                        z2 = cVar.mo2867j(this, view, motionEvent2);
                    } else if (i2 == 1) {
                        z2 = cVar.mo2857A(this, view, motionEvent2);
                    }
                    if (z2) {
                        this.f2737l = view;
                    }
                }
                if (fVar.f2749a == null) {
                    fVar.f2761m = false;
                }
                boolean z4 = fVar.f2761m;
                if (z4) {
                    z = true;
                } else {
                    C0733c cVar2 = fVar.f2749a;
                    z = (cVar2 != null && cVar2.mo2860c() > 0.0f) | z4;
                    fVar.f2761m = z;
                }
                z3 = z && !z4;
                if (z && !z3) {
                    break;
                }
            } else if (cVar != null) {
                if (motionEvent3 == null) {
                    long uptimeMillis = SystemClock.uptimeMillis();
                    motionEvent3 = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                }
                if (i2 == 0) {
                    cVar.mo2867j(this, view, motionEvent3);
                } else if (i2 == 1) {
                    cVar.mo2857A(this, view, motionEvent3);
                }
            }
        }
        list.clear();
        return z2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0073, code lost:
        if (r5 != false) goto L_0x00c2;
     */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0160 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x0106  */
    /* renamed from: u */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2850u() {
        /*
            r11 = this;
            java.util.List<android.view.View> r0 = r11.f2727b
            r0.clear()
            a.g.d.a<android.view.View> r0 = r11.f2728c
            a.e.h<T, java.util.ArrayList<T>> r1 = r0.f1279b
            int r1 = r1.f940d
            r2 = 0
            r3 = 0
        L_0x000d:
            if (r3 >= r1) goto L_0x0024
            a.e.h<T, java.util.ArrayList<T>> r4 = r0.f1279b
            java.lang.Object r4 = r4.mo1240k(r3)
            java.util.ArrayList r4 = (java.util.ArrayList) r4
            if (r4 == 0) goto L_0x0021
            r4.clear()
            a.h.k.c<java.util.ArrayList<T>> r5 = r0.f1278a
            r5.mo1531b(r4)
        L_0x0021:
            int r3 = r3 + 1
            goto L_0x000d
        L_0x0024:
            a.e.h<T, java.util.ArrayList<T>> r0 = r0.f1279b
            r0.clear()
            int r0 = r11.getChildCount()
            r1 = 0
        L_0x002e:
            if (r1 >= r0) goto L_0x018d
            android.view.View r3 = r11.getChildAt(r1)
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r4 = r11.mo2820h(r3)
            int r5 = r4.f2754f
            r6 = -1
            r7 = 0
            if (r5 != r6) goto L_0x0044
            r4.f2760l = r7
            r4.f2759k = r7
            goto L_0x00c2
        L_0x0044:
            android.view.View r5 = r4.f2759k
            if (r5 == 0) goto L_0x0075
            int r5 = r5.getId()
            int r6 = r4.f2754f
            if (r5 == r6) goto L_0x0051
            goto L_0x006e
        L_0x0051:
            android.view.View r5 = r4.f2759k
            android.view.ViewParent r6 = r5.getParent()
        L_0x0057:
            if (r6 == r11) goto L_0x0070
            if (r6 == 0) goto L_0x006a
            if (r6 != r3) goto L_0x005e
            goto L_0x006a
        L_0x005e:
            boolean r8 = r6 instanceof android.view.View
            if (r8 == 0) goto L_0x0065
            r5 = r6
            android.view.View r5 = (android.view.View) r5
        L_0x0065:
            android.view.ViewParent r6 = r6.getParent()
            goto L_0x0057
        L_0x006a:
            r4.f2760l = r7
            r4.f2759k = r7
        L_0x006e:
            r5 = 0
            goto L_0x0073
        L_0x0070:
            r4.f2760l = r5
            r5 = 1
        L_0x0073:
            if (r5 != 0) goto L_0x00c2
        L_0x0075:
            int r5 = r4.f2754f
            android.view.View r5 = r11.findViewById(r5)
            r4.f2759k = r5
            if (r5 == 0) goto L_0x00b8
            if (r5 != r11) goto L_0x0090
            boolean r5 = r11.isInEditMode()
            if (r5 == 0) goto L_0x0088
            goto L_0x00be
        L_0x0088:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "View can not be anchored to the the parent CoordinatorLayout"
            r0.<init>(r1)
            throw r0
        L_0x0090:
            android.view.ViewParent r6 = r5.getParent()
        L_0x0094:
            if (r6 == r11) goto L_0x00b5
            if (r6 == 0) goto L_0x00b5
            if (r6 != r3) goto L_0x00a9
            boolean r5 = r11.isInEditMode()
            if (r5 == 0) goto L_0x00a1
            goto L_0x00be
        L_0x00a1:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Anchor must not be a descendant of the anchored view"
            r0.<init>(r1)
            throw r0
        L_0x00a9:
            boolean r8 = r6 instanceof android.view.View
            if (r8 == 0) goto L_0x00b0
            r5 = r6
            android.view.View r5 = (android.view.View) r5
        L_0x00b0:
            android.view.ViewParent r6 = r6.getParent()
            goto L_0x0094
        L_0x00b5:
            r4.f2760l = r5
            goto L_0x00c2
        L_0x00b8:
            boolean r5 = r11.isInEditMode()
            if (r5 == 0) goto L_0x0168
        L_0x00be:
            r4.f2760l = r7
            r4.f2759k = r7
        L_0x00c2:
            a.g.d.a<android.view.View> r5 = r11.f2728c
            r5.mo1406a(r3)
            r5 = 0
        L_0x00c8:
            if (r5 >= r0) goto L_0x0164
            if (r5 != r1) goto L_0x00ce
            goto L_0x0160
        L_0x00ce:
            android.view.View r6 = r11.getChildAt(r5)
            android.view.View r8 = r4.f2760l
            if (r6 == r8) goto L_0x0103
            int r8 = p000a.p025h.p037l.C0390k.m1243p(r11)
            android.view.ViewGroup$LayoutParams r9 = r6.getLayoutParams()
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r9 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0736f) r9
            int r9 = r9.f2755g
            int r9 = android.view.Gravity.getAbsoluteGravity(r9, r8)
            if (r9 == 0) goto L_0x00f3
            int r10 = r4.f2756h
            int r8 = android.view.Gravity.getAbsoluteGravity(r10, r8)
            r8 = r8 & r9
            if (r8 != r9) goto L_0x00f3
            r8 = 1
            goto L_0x00f4
        L_0x00f3:
            r8 = 0
        L_0x00f4:
            if (r8 != 0) goto L_0x0103
            androidx.coordinatorlayout.widget.CoordinatorLayout$c r8 = r4.f2749a
            if (r8 == 0) goto L_0x0101
            boolean r8 = r8.mo2861d(r11, r3, r6)
            if (r8 == 0) goto L_0x0101
            goto L_0x0103
        L_0x0101:
            r8 = 0
            goto L_0x0104
        L_0x0103:
            r8 = 1
        L_0x0104:
            if (r8 == 0) goto L_0x0160
            a.g.d.a<android.view.View> r8 = r11.f2728c
            a.e.h<T, java.util.ArrayList<T>> r8 = r8.f1279b
            int r8 = r8.mo1229e(r6)
            if (r8 < 0) goto L_0x0112
            r8 = 1
            goto L_0x0113
        L_0x0112:
            r8 = 0
        L_0x0113:
            if (r8 != 0) goto L_0x011a
            a.g.d.a<android.view.View> r8 = r11.f2728c
            r8.mo1406a(r6)
        L_0x011a:
            a.g.d.a<android.view.View> r8 = r11.f2728c
            a.e.h<T, java.util.ArrayList<T>> r9 = r8.f1279b
            int r9 = r9.mo1229e(r6)
            if (r9 < 0) goto L_0x0126
            r9 = 1
            goto L_0x0127
        L_0x0126:
            r9 = 0
        L_0x0127:
            if (r9 == 0) goto L_0x0158
            a.e.h<T, java.util.ArrayList<T>> r9 = r8.f1279b
            int r9 = r9.mo1229e(r3)
            if (r9 < 0) goto L_0x0133
            r9 = 1
            goto L_0x0134
        L_0x0133:
            r9 = 0
        L_0x0134:
            if (r9 == 0) goto L_0x0158
            a.e.h<T, java.util.ArrayList<T>> r9 = r8.f1279b
            java.lang.Object r9 = r9.getOrDefault(r6, r7)
            java.util.ArrayList r9 = (java.util.ArrayList) r9
            if (r9 != 0) goto L_0x0154
            a.h.k.c<java.util.ArrayList<T>> r9 = r8.f1278a
            java.lang.Object r9 = r9.mo1530a()
            java.util.ArrayList r9 = (java.util.ArrayList) r9
            if (r9 != 0) goto L_0x014f
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
        L_0x014f:
            a.e.h<T, java.util.ArrayList<T>> r8 = r8.f1279b
            r8.put(r6, r9)
        L_0x0154:
            r9.add(r3)
            goto L_0x0160
        L_0x0158:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "All nodes must be present in the graph before being added as an edge"
            r0.<init>(r1)
            throw r0
        L_0x0160:
            int r5 = r5 + 1
            goto L_0x00c8
        L_0x0164:
            int r1 = r1 + 1
            goto L_0x002e
        L_0x0168:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Could not find CoordinatorLayout descendant view with id "
            java.lang.StringBuilder r1 = p062b.p078b.p079a.p080a.C1011a.m3164l(r1)
            android.content.res.Resources r2 = r11.getResources()
            int r4 = r4.f2754f
            java.lang.String r2 = r2.getResourceName(r4)
            r1.append(r2)
            java.lang.String r2 = " to anchor view "
            r1.append(r2)
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x018d:
            java.util.List<android.view.View> r0 = r11.f2727b
            a.g.d.a<android.view.View> r1 = r11.f2728c
            java.util.ArrayList<T> r3 = r1.f1280c
            r3.clear()
            java.util.HashSet<T> r3 = r1.f1281d
            r3.clear()
            a.e.h<T, java.util.ArrayList<T>> r3 = r1.f1279b
            int r3 = r3.f940d
        L_0x019f:
            if (r2 >= r3) goto L_0x01b1
            a.e.h<T, java.util.ArrayList<T>> r4 = r1.f1279b
            java.lang.Object r4 = r4.mo1235h(r2)
            java.util.ArrayList<T> r5 = r1.f1280c
            java.util.HashSet<T> r6 = r1.f1281d
            r1.mo1407b(r4, r5, r6)
            int r2 = r2 + 1
            goto L_0x019f
        L_0x01b1:
            java.util.ArrayList<T> r1 = r1.f1280c
            r0.addAll(r1)
            java.util.List<android.view.View> r0 = r11.f2727b
            java.util.Collections.reverse(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.mo2850u():void");
    }

    /* renamed from: v */
    public final void mo2851v(boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            C0733c cVar = ((C0736f) childAt.getLayoutParams()).f2749a;
            if (cVar != null) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z) {
                    cVar.mo2867j(this, childAt, obtain);
                } else {
                    cVar.mo2857A(this, childAt, obtain);
                }
                obtain.recycle();
            }
        }
        for (int i2 = 0; i2 < childCount; i2++) {
            ((C0736f) getChildAt(i2).getLayoutParams()).f2761m = false;
        }
        this.f2737l = null;
        this.f2734i = false;
    }

    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f2743r;
    }

    /* renamed from: w */
    public final void mo2853w(View view, int i) {
        C0736f fVar = (C0736f) view.getLayoutParams();
        int i2 = fVar.f2757i;
        if (i2 != i) {
            C0390k.m1200G(view, i - i2);
            fVar.f2757i = i;
        }
    }

    /* renamed from: x */
    public final void mo2854x(View view, int i) {
        C0736f fVar = (C0736f) view.getLayoutParams();
        int i2 = fVar.f2758j;
        if (i2 != i) {
            C0390k.m1201H(view, i - i2);
            fVar.f2758j = i;
        }
    }

    /* renamed from: y */
    public final void mo2855y() {
        if (C0390k.m1240m(this)) {
            if (this.f2745t == null) {
                this.f2745t = new C0731a();
            }
            C0390k.m1225c0(this, this.f2745t);
            setSystemUiVisibility(1280);
            return;
        }
        C0390k.m1225c0(this, (C0388i) null);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof C0736f) {
            return new C0736f((C0736f) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0736f((ViewGroup.MarginLayoutParams) layoutParams) : new C0736f(layoutParams);
    }
}
